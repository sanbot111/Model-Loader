module.exports = [
"[externals]/perf_hooks [external] (perf_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("perf_hooks", () => require("perf_hooks"));

module.exports = mod;
}),
"[externals]/node:perf_hooks [external] (node:perf_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:perf_hooks", () => require("node:perf_hooks"));

module.exports = mod;
}),
"[externals]/express [external] (express, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("express", () => require("express"));

module.exports = mod;
}),
"[externals]/fs/promises [external] (fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs/promises", () => require("fs/promises"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/process [external] (process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[externals]/async_hooks [external] (async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("async_hooks", () => require("async_hooks"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[externals]/require-in-the-middle [external] (require-in-the-middle, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("require-in-the-middle", () => require("require-in-the-middle"));

module.exports = mod;
}),
"[externals]/import-in-the-middle [external] (import-in-the-middle, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("import-in-the-middle", () => require("import-in-the-middle"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/dns [external] (dns, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("dns", () => require("dns"));

module.exports = mod;
}),
"[externals]/dgram [external] (dgram, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("dgram", () => require("dgram"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/vm [external] (vm, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("vm", () => require("vm"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/punycode [external] (punycode, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}),
"[externals]/querystring [external] (querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}),
"[externals]/node:events [external] (node:events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:events", () => require("node:events"));

module.exports = mod;
}),
"[externals]/node:process [external] (node:process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:process", () => require("node:process"));

module.exports = mod;
}),
"[externals]/node:util [external] (node:util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:util", () => require("node:util"));

module.exports = mod;
}),
"[project]/src/ai/genkit.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ai",
    ()=>ai
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/genkit/lib/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$genkit$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/genkit/lib/genkit.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$genkit$2d$ai$2f$google$2d$genai$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@genkit-ai/google-genai/lib/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$genkit$2d$ai$2f$google$2d$genai$2f$lib$2f$googleai$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@genkit-ai/google-genai/lib/googleai/index.js [app-rsc] (ecmascript)");
;
;
const ai = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$genkit$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["genkit"])({
    plugins: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$genkit$2d$ai$2f$google$2d$genai$2f$lib$2f$googleai$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["googleAI"])()
    ],
    model: 'googleai/gemini-2.5-pro'
});
}),
"[project]/src/ai/gemini-safety-settings.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** Shared Gemini safety thresholds for commercial casting / catalog generation. */ __turbopack_context__.s([
    "GEMINI_SAFETY_SETTINGS",
    ()=>GEMINI_SAFETY_SETTINGS
]);
const GEMINI_SAFETY_SETTINGS = [
    {
        category: 'HARM_CATEGORY_HATE_SPEECH',
        threshold: 'BLOCK_ONLY_HIGH'
    },
    {
        category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
        threshold: 'BLOCK_ONLY_HIGH'
    },
    {
        category: 'HARM_CATEGORY_HARASSMENT',
        threshold: 'BLOCK_ONLY_HIGH'
    },
    {
        category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
        threshold: 'BLOCK_ONLY_HIGH'
    }
];
}),
"[project]/src/ai/flows/generate-model-turnaround-prompts.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd":"generateModelTurnaroundPrompts"},"",""] */ __turbopack_context__.s([
    "generateModelTurnaroundPrompts",
    ()=>generateModelTurnaroundPrompts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
/**
 * @fileOverview A Genkit flow to construct detailed 3-angle image generation prompts based on user-selected model characteristics.
 *
 * - generateModelTurnaroundPrompts - A function that handles the prompt generation process.
 * - GenerateModelTurnaroundPromptsInput - The input type for the generateModelTurnaroundPrompts function.
 * - GenerateModelTurnaroundPromptsOutput - The return type for the generateModelTurnaroundPrompts function.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/genkit.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$gemini$2d$safety$2d$settings$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/gemini-safety-settings.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/genkit/lib/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/genkit/lib/common.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
const GenerateModelTurnaroundPromptsInputSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].object({
    gender: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Female / Woman or Male / Man.'),
    ageGroup: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Age group with approximate age range.'),
    regionEthnicity: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Parent region/ethnicity category key.'),
    subGroup: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Specific demographic sub-group phenotype string.'),
    skinTone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Fitzpatrick skin tone Type 1–6 with description.'),
    hairStyle: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Gender-appropriate hair style from the UI.'),
    hairColor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Hair color (shared male/female list, e.g., Jet Black, Auburn / Ginger).'),
    marketingArchetype: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Gender-appropriate marketing archetype / vibe.'),
    bodyType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('Gender-appropriate body type from the UI.'),
    facialHair: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().optional().nullable().describe('Male only: facial hair style. Omitted or null for female models.')
});
const GenerateModelTurnaroundPromptsOutputSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].object({
    straightPrompt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('3/4 body portrait prompt: front-facing, head to mid-thigh.'),
    leftPrompt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('3/4 body portrait prompt: left profile, head to mid-thigh.'),
    rightPrompt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('3/4 body portrait prompt: right profile, head to mid-thigh.')
});
async function generateModelTurnaroundPrompts(input) {
    return generateModelTurnaroundPromptsFlow(input);
}
const prompt = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ai"].definePrompt({
    name: 'generateModelTurnaroundPromptsPrompt',
    input: {
        schema: GenerateModelTurnaroundPromptsInputSchema
    },
    output: {
        schema: GenerateModelTurnaroundPromptsOutputSchema
    },
    config: {
        safetySettings: [
            ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$gemini$2d$safety$2d$settings$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["GEMINI_SAFETY_SETTINGS"]
        ]
    },
    prompt: `You are acting as a precise, algorithmic Technical Art Director for Kotoor, specialized in generating consistent, professional 3-angle model turnaround catalogs for fashion and apparel visualization.

Your core objective is to output three highly descriptive image generation prompts—"straightPrompt", "leftPrompt", and "rightPrompt"—that describe the EXACT same fictional human model from three distinct, strictly locked camera angles. The straight profile is generated first as a master reference; left and right profiles are generated sequentially using that reference image, so identity, wardrobe, and camera metrics must remain absolutely locked across all three prompt strings.

### 1. INPUT TRAIT REGISTRY
Extract these exact parameter strings and map them directly into your generated outputs:
- **Gender / Sex Profile:** {{{gender}}}
- **Age Grouping:** {{{ageGroup}}}
- **Regional Category:** {{{regionEthnicity}}}
- **Specific Demographic Phenotype:** {{{subGroup}}}
- **Skin Tone & Undertone Depth:** {{{skinTone}}}
- **Hair Style & Texture Cut:** {{{hairStyle}}}
- **Hair Color Value:** {{{hairColor}}}
- **Body Silhouette Type:** {{{bodyType}}}
- **Marketing Expression / Vibe:** {{{marketingArchetype}}}
- **Facial Hair Style (Males Only):** {{{facialHair}}}

### 2. IMMUTABLE IDENTITY ANCHOR (Apply to ALL 3 Prompts)
To lock the generation model's weights on a singular identity, you must create a uniform "Identity Anchor Block" at the beginning of every prompt string. Generate a fictional, ethnically accurate name for this person (e.g., "Ananya" or "Rahul") to serve as an internal token anchor. 
Describe the face using unvarying, structural terms:
- Facial geometry must be explicitly linked to the chosen Specific Demographic Phenotype ({{{subGroup}}}).
- **CRITICAL ANTI-RACE-DRIFT GUARDRAIL:** If the model phenotype is South Asian (North/South Indian) and combined with a deep skin tone or curly hair, you MUST explicitly mandate "South Asian Indian facial morphology, distinct South Asian bone structure, sharp warm bronze features." Do NOT allow the image generation engines to drift into African/Black or Caucasian features.
- **EAST ASIAN FACIAL MORPHOLOGY & STYLING GUARDRAIL:** When the Regional Category or Specific Demographic Phenotype indicates East Asian (Chinese, Japanese, Korean, Taiwanese), you MUST mandate authentic East Asian facial morphology: monolids or epicanthic folds as appropriate, softer mid-face flatness, and jawline geometry distinct from Southeast or South Asian profiles. Do NOT allow high-fashion editorial prompts to default to Caucasian-influenced double eyelids or Westernized eye shapes. Render the Hair Style & Texture Cut ({{{hairStyle}}}) with strict regional accuracy—East Asian editorial cuts (e.g., blunt bangs, hime cut, two-block undercut, comma hair) must be described precisely and must reinforce the identity anchor rather than generic Western styling.
- Describe the apparel identically: "Wearing a black half-sleeve top and full-length black bottoms. The fabric has no patterns, logos, textures, or branding."
- **GROOMING & FACIAL HAIR CONSTRAINT:** If the Gender profile is "Male / Man" and a Facial Hair Style is provided, describe that exact facial hair asset (e.g., "sharp groomed mustache only" or "evenly trimmed short beard") with absolute descriptive uniformity across all three prompt outputs. If the Gender profile is "Female / Woman", completely ignore the facial hair trait and ensure the face is completely clean with smooth jawlines.

### 3. MANDATORY CAMERA & LENS MATRIX (Apply to ALL 3 Prompts)
To prevent framing variations (close-ups vs. distant shots), use this exact camera specification block verbatim in all three prompts:
"Commercial studio fashion photography, captured on a high-end medium format camera, 100mm portrait lens, f/5.6 aperture, sharp focus on the skin texture, crisp clean rendering. Uniform studio setting, even soft 3-point clamshell lighting, seamless solid neutral mid-grey background color, no shadows cast on the backdrop."

### 4. CRITICAL CANVAS FRAMING (Apply to ALL 3 Prompts)
"Framing is a strict 3/4 body portrait vector composition. Vertical framing rules: The top of the head is positioned exactly 5% below the top edge of the frame canvas. The bottom edge of the image canvas cuts cleanly across the mid-thigh area, with the full hand visible. You must maintain the exact same spatial scale, pixel magnification, camera zoom, and physical distance from the lens to the model across all shots. The model must occupy the exact same vertical and horizontal volume within the canvas as seen in the straight profile."

### 5. ANGLE-SPECIFIC POSING CONSTRAINTS
Modify ONLY the pose, facial rotation, and occlusion parameters between the three output strings using these absolute coordinate terms:

#### straightPrompt Constraints:
- Append: "Full front-facing view, 0-degree orientation. The model's chest, torso, and shoulders are perfectly square to the lens camera plane. Both eyes are tracking directly forward into the camera lens. Perfect facial symmetry."
- Map the Expression: Integrate the Expression/Vibe parameter here as a natural, controlled facial look (e.g., Lifestyle = approachable subtle smile; Editorial = neutral, calm, poised commercial expression).

#### leftPrompt Constraints:
- Append: "Strict 90-degree left profile view. The model has rotated their entire body and head to their right, so their face, nose, and chest point directly toward the left edge of the image canvas. The shoulders and torso are perfectly perpendicular to the camera lens plane. Only the left side of the profile is visible."

#### rightPrompt Constraints:
- Append: "Strict 90-degree right profile view. The model has rotated their entire body and head to their left, so their face, nose, and chest point directly toward the right edge of the image canvas. This must be a perfect mirror image of the left profile. The shoulders and torso are perfectly perpendicular to the camera lens plane. Only the right side of the profile is visible."

### 6. HIGH-END AGENCY MODEL AESTHETIC PROTOCOLS (MANDATORY)
- **Casting Grade:** The generated individual must resemble a signed professional fashion agency model. They must display symmetric, striking facial geometries, pristine facial lines, and crisp, clean bone structures.
- **Visual Presentation:** Avoid an amateur, candid look, or an unpolished "everyday civilian" appearance. The output must mimic a high-fashion editorial digital portfolio.
- **Pose & Composure:** The subject must exhibit absolute physical composure. Expressions should remain controlled, highly poised, and intentional. The physical carriage should reflect high-end commercial apparel casting standards.
- **Skin Finish Rendering:** Render high-fidelity skin textures. Maintain realistic features like subtle pores and natural highlights under pristine, soft, three-point studio lights. Avoid over-smoothed, artificial wax-like or plastic looking skin textures.
- **Negative Enforcement:** Do not generate casual everyday phone snapshots, unpolished low-contrast lighting conditions, cluttered home or street backdrops, or awkward non-professional body postures.

### 7. NEGATIVE GUARDRAILS (Append to ALL 3 Prompts)
"No side-glancing eyes, no twisted neck, no partial 45-degree or 3/4 face angles, no asymmetrical shoulder lines, no background gradients, no jewelry, no clothing modifications, no multi-panel split screens, no variations in scale or aspect formatting."

Adhere strictly to these rules. Return a valid JSON object matching the requested schema with highly detailed, fully descriptive English paragraphs that combine all these constraints seamlessly.`
});
const generateModelTurnaroundPromptsFlow = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ai"].defineFlow({
    name: 'generateModelTurnaroundPromptsFlow',
    inputSchema: GenerateModelTurnaroundPromptsInputSchema,
    outputSchema: GenerateModelTurnaroundPromptsOutputSchema
}, async (input)=>{
    try {
        const { output } = await prompt(input, {
            config: {
                safetySettings: [
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$gemini$2d$safety$2d$settings$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["GEMINI_SAFETY_SETTINGS"]
                ]
            }
        });
        if (!output) {
            throw new Error('Failed to generate model turnaround prompts.');
        }
        return output;
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (message.includes('Generation blocked') || message.includes('FAILED_PRECONDITION')) {
            throw new Error('Prompt generation was blocked by content safety filters. Try a different age group or simplify regional ancestry selections, then retry.');
        }
        throw error;
    }
});
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    generateModelTurnaroundPrompts
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(generateModelTurnaroundPrompts, "4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd", null);
}),
"[project]/src/ai/flows/generate-model-images.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"400ba0d60ef0c89afda251d7a988bfb25bf1808dbf":"generateStraightImage","40b9646aad140ea8735d04d831acacf2d24be0bc92":"generateModelImages","60a5896f6e306e1b38784e0b2d65c6ba88970975e9":"generateProfileImage"},"",""] */ __turbopack_context__.s([
    "generateModelImages",
    ()=>generateModelImages,
    "generateProfileImage",
    ()=>generateProfileImage,
    "generateStraightImage",
    ()=>generateStraightImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
/**
 * @fileOverview Sequential 3-angle generation via gemini-3-pro-image with hero-image reference.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/genkit.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
const IMAGE_MODEL = 'googleai/gemini-3-pro-image';
/** Gemini native image models use imageConfig, not Imagen's top-level aspectRatio. */ const GEMINI_IMAGE_CONFIG = {
    responseModalities: [
        'TEXT',
        'IMAGE'
    ],
    imageConfig: {
        aspectRatio: '3:4'
    }
};
function extractImageDataUri(result) {
    if (result.media?.url) {
        return result.media.url;
    }
    const content = result.message?.content;
    if (Array.isArray(content)) {
        for (const part of content){
            if (part && typeof part === 'object' && 'media' in part && part.media && typeof part.media === 'object' && 'url' in part.media && typeof part.media.url === 'string') {
                return part.media.url;
            }
        }
    }
    if (result.text?.startsWith('data:image')) {
        return result.text;
    }
    return undefined;
}
function referenceImageContentType(dataUri) {
    const match = dataUri.match(/^data:([^;]+);/);
    return match?.[1] ?? 'image/png';
}
async function generateWithReference(promptText, referenceDataUri) {
    const contentType = referenceImageContentType(referenceDataUri);
    return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ai"].generate({
        model: IMAGE_MODEL,
        output: {
            format: 'media'
        },
        prompt: [
            {
                media: {
                    url: referenceDataUri,
                    contentType
                }
            },
            {
                text: `${promptText}\n\nUse the attached reference image as the strict identity anchor. Generate a new image that preserves the same person, clothing, and studio setup while applying only the new camera angle described above.`
            }
        ],
        config: GEMINI_IMAGE_CONFIG
    });
}
async function generateStraightImageInternal(straightPrompt) {
    const straightResponse = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ai"].generate({
        model: IMAGE_MODEL,
        output: {
            format: 'media'
        },
        prompt: straightPrompt,
        config: GEMINI_IMAGE_CONFIG
    });
    const straightImageB64 = extractImageDataUri(straightResponse);
    if (!straightImageB64) {
        throw new Error('Failed to generate the Master Reference image.');
    }
    return straightImageB64;
}
async function generateStraightImage(straightPrompt) {
    return generateStraightImageInternal(straightPrompt);
}
async function generateProfileImage(promptText, referenceDataUri) {
    const response = await generateWithReference(promptText, referenceDataUri);
    const image = extractImageDataUri(response);
    if (!image) {
        throw new Error('Failed to generate profile reference image. The model may have returned text instead of an image—retry generation.');
    }
    return image;
}
async function generateModelImages(input) {
    const { straightPrompt, leftPrompt, rightPrompt } = input.prompts;
    const straightImageB64 = await generateStraightImageInternal(straightPrompt);
    const [left, right] = await Promise.all([
        generateProfileImage(leftPrompt, straightImageB64),
        generateProfileImage(rightPrompt, straightImageB64)
    ]);
    return {
        imagen: {
            straight: straightImageB64,
            left,
            right
        }
    };
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    generateStraightImage,
    generateProfileImage,
    generateModelImages
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(generateStraightImage, "400ba0d60ef0c89afda251d7a988bfb25bf1808dbf", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(generateProfileImage, "60a5896f6e306e1b38784e0b2d65c6ba88970975e9", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(generateModelImages, "40b9646aad140ea8735d04d831acacf2d24be0bc92", null);
}),
"[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/ai/flows/generate-model-turnaround-prompts.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/src/ai/flows/generate-model-images.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$turnaround$2d$prompts$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/flows/generate-model-turnaround-prompts.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$images$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/flows/generate-model-images.ts [app-rsc] (ecmascript)");
;
;
;
;
}),
"[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/ai/flows/generate-model-turnaround-prompts.ts [app-rsc] (ecmascript)\", ACTIONS_MODULE1 => \"[project]/src/ai/flows/generate-model-images.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$turnaround$2d$prompts$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["generateModelTurnaroundPrompts"],
    "400ba0d60ef0c89afda251d7a988bfb25bf1808dbf",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$images$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["generateStraightImage"],
    "40b9646aad140ea8735d04d831acacf2d24be0bc92",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$images$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["generateModelImages"],
    "60a5896f6e306e1b38784e0b2d65c6ba88970975e9",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$images$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["generateProfileImage"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$turnaround$2d$prompts$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29222c$__ACTIONS_MODULE1__$3d3e$__$225b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$images$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => "[project]/src/ai/flows/generate-model-turnaround-prompts.ts [app-rsc] (ecmascript)", ACTIONS_MODULE1 => "[project]/src/ai/flows/generate-model-images.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$turnaround$2d$prompts$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/flows/generate-model-turnaround-prompts.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$generate$2d$model$2d$images$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/flows/generate-model-images.ts [app-rsc] (ecmascript)");
}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/src/app/page.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/app/page.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/app/page.tsx <module evaluation>", "default");
}),
"[project]/src/app/page.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/app/page.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/app/page.tsx", "default");
}),
"[project]/src/app/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$page$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/app/page.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$page$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/src/app/page.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$page$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/src/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/page.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__84fcaccc._.js.map
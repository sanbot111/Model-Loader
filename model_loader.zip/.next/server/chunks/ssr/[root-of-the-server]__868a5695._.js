module.exports = [
"[project]/src/lib/types.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ENGINE_LABELS",
    ()=>ENGINE_LABELS,
    "getActiveEngineKeys",
    ()=>getActiveEngineKeys,
    "hasMultipleEngines",
    ()=>hasMultipleEngines
]);
const ENGINE_LABELS = {
    imagen: "Imagen 4",
    openai: "GPT Image 2"
};
function getActiveEngineKeys(results) {
    const keys = [];
    if (results.imagen) keys.push("imagen");
    if (results.openai) keys.push("openai");
    return keys;
}
function hasMultipleEngines(results) {
    return getActiveEngineKeys(results).length > 1;
}
}),
"[project]/src/lib/constants.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AGE_GROUPS",
    ()=>AGE_GROUPS,
    "DEFAULT_ENGINES",
    ()=>DEFAULT_ENGINES,
    "DEFAULT_FORM_DATA_FEMALE",
    ()=>DEFAULT_FORM_DATA_FEMALE,
    "DEFAULT_FORM_DATA_MALE",
    ()=>DEFAULT_FORM_DATA_MALE,
    "FEMALE_ARCHETYPES",
    ()=>FEMALE_ARCHETYPES,
    "FEMALE_BODY_TYPES",
    ()=>FEMALE_BODY_TYPES,
    "FEMALE_GENDER",
    ()=>FEMALE_GENDER,
    "FEMALE_HAIR_STYLES",
    ()=>FEMALE_HAIR_STYLES,
    "GENDERS",
    ()=>GENDERS,
    "HAIR_COLORS",
    ()=>HAIR_COLORS,
    "MALE_ARCHETYPES",
    ()=>MALE_ARCHETYPES,
    "MALE_BODY_TYPES",
    ()=>MALE_BODY_TYPES,
    "MALE_FACIAL_HAIR",
    ()=>MALE_FACIAL_HAIR,
    "MALE_GENDER",
    ()=>MALE_GENDER,
    "MALE_HAIR_STYLES",
    ()=>MALE_HAIR_STYLES,
    "REGIONS",
    ()=>REGIONS,
    "SKIN_TONES",
    ()=>SKIN_TONES,
    "femaleHairStyleOptions",
    ()=>femaleHairStyleOptions,
    "getArchetypes",
    ()=>getArchetypes,
    "getBodyTypes",
    ()=>getBodyTypes,
    "getDefaultSubGroup",
    ()=>getDefaultSubGroup,
    "getGenderSpecificDefaults",
    ()=>getGenderSpecificDefaults,
    "getHairStyles",
    ()=>getHairStyles,
    "getRegionLabel",
    ()=>getRegionLabel,
    "getSubGroupsForRegion",
    ()=>getSubGroupsForRegion,
    "hairColorOptions",
    ()=>hairColorOptions,
    "hasAtLeastOneEngine",
    ()=>hasAtLeastOneEngine,
    "isMaleGender",
    ()=>isMaleGender,
    "maleHairStyleOptions",
    ()=>maleHairStyleOptions,
    "regionEthnicityOptions",
    ()=>regionEthnicityOptions,
    "skinToneOptions",
    ()=>skinToneOptions,
    "subGroupOptionsMap",
    ()=>subGroupOptionsMap,
    "toConfigurationTraits",
    ()=>toConfigurationTraits,
    "toPromptInput",
    ()=>toPromptInput
]);
const FEMALE_GENDER = "Female / Woman";
const MALE_GENDER = "Male / Man";
const GENDERS = [
    FEMALE_GENDER,
    MALE_GENDER
];
const AGE_GROUPS = [
    "Child (4–12 years)",
    "Teen (13–19 years)",
    "Young Adult (20–29 years)",
    "Adult (30–45 years)",
    "Middle-Aged (46–60 years)",
    "Senior / Mature (60+ years)"
];
const regionEthnicityOptions = [
    {
        label: "African / Black",
        value: "african_black"
    },
    {
        label: "East Asian",
        value: "east_asian"
    },
    {
        label: "South Asian",
        value: "south_asian"
    },
    {
        label: "Southeast Asian",
        value: "southeast_asian"
    },
    {
        label: "Middle Eastern / North African (MENA)",
        value: "mena"
    },
    {
        label: "Caucasian / White",
        value: "caucasian_white"
    },
    {
        label: "Hispanic / Latin American",
        value: "hispanic_latin"
    },
    {
        label: "Indigenous / First Nations",
        value: "indigenous"
    },
    {
        label: "Mixed / Multiracial",
        value: "mixed_multiracial"
    }
];
const subGroupOptionsMap = {
    african_black: [
        {
            label: "West African (e.g., Nigerian, Ghanaian)",
            value: "west african phenotype"
        },
        {
            label: "East African (e.g., Ethiopian, Somali)",
            value: "east african phenotype"
        },
        {
            label: "Afro-Caribbean",
            value: "afro-caribbean phenotype"
        },
        {
            label: "African-American",
            value: "african-american phenotype"
        }
    ],
    east_asian: [
        {
            label: "Chinese",
            value: "chinese phenotype"
        },
        {
            label: "Japanese",
            value: "japanese phenotype"
        },
        {
            label: "Korean",
            value: "korean phenotype"
        },
        {
            label: "Taiwanese",
            value: "taiwanese phenotype"
        }
    ],
    south_asian: [
        {
            label: "South Asian (North Indian)",
            value: "south asian, north indian phenotype"
        },
        {
            label: "South Asian (South Indian)",
            value: "south asian, south indian phenotype"
        },
        {
            label: "Pakistani",
            value: "pakistani phenotype"
        },
        {
            label: "Bangladeshi",
            value: "bangladeshi phenotype"
        },
        {
            label: "Sri Lankan",
            value: "sri lankan phenotype"
        }
    ],
    southeast_asian: [
        {
            label: "Thai",
            value: "thai phenotype"
        },
        {
            label: "Vietnamese",
            value: "vietnamese phenotype"
        },
        {
            label: "Filipino",
            value: "filipino phenotype"
        },
        {
            label: "Indonesian / Malaysian",
            value: "indonesian malaysian phenotype"
        }
    ],
    mena: [
        {
            label: "Egyptian",
            value: "egyptian phenotype"
        },
        {
            label: "Levantine (e.g., Lebanese, Syrian)",
            value: "levantine arab phenotype"
        },
        {
            label: "Persian / Iranian",
            value: "persian iranian phenotype"
        },
        {
            label: "North African Maghrebi",
            value: "maghrebi arab phenotype"
        }
    ],
    caucasian_white: [
        {
            label: "Northern European / Nordic",
            value: "northern european nordic phenotype"
        },
        {
            label: "Southern European / Mediterranean",
            value: "southern european mediterranean phenotype"
        },
        {
            label: "Eastern European / Slavic",
            value: "eastern european slavic phenotype"
        },
        {
            label: "Celtic / Anglo-Saxon",
            value: "celtic anglo-saxon phenotype"
        }
    ],
    hispanic_latin: [
        {
            label: "Mexican / Central American",
            value: "mexican central american phenotype"
        },
        {
            label: "South American (Andean / Mestizo)",
            value: "andean mestizo phenotype"
        },
        {
            label: "Afro-Latino",
            value: "afro-latino phenotype"
        },
        {
            label: "Caribbean Hispanic",
            value: "caribbean hispanic phenotype"
        }
    ],
    indigenous: [
        {
            label: "Native American / First Nations",
            value: "native american first nations phenotype"
        },
        {
            label: "Māori / Pacific Islander",
            value: "maori pacific islander phenotype"
        },
        {
            label: "Aboriginal Australian",
            value: "aboriginal australian phenotype"
        }
    ],
    mixed_multiracial: [
        {
            label: "Eurasian (East Asian + White)",
            value: "eurasian mixed phenotype"
        },
        {
            label: "Afro-Asian (Blasian)",
            value: "afro-asian mixed phenotype"
        },
        {
            label: "Multiracial South Asian",
            value: "multiracial south asian phenotype"
        }
    ]
};
const REGIONS = regionEthnicityOptions;
function getSubGroupsForRegion(regionKey) {
    return subGroupOptionsMap[regionKey] ?? [];
}
function getDefaultSubGroup(regionKey) {
    return getSubGroupsForRegion(regionKey)[0]?.value ?? "";
}
function getRegionLabel(regionKey) {
    return regionEthnicityOptions.find((r)=>r.value === regionKey)?.label ?? regionKey;
}
const skinToneOptions = [
    {
        label: "Type 1: Very light, pale, or porcelain",
        value: "type 1 very light pale porcelain"
    },
    {
        label: "Type 2: Light or fair",
        value: "type 2 light fair"
    },
    {
        label: "Type 3: Medium, wheatish to light olive",
        value: "type 3 medium wheatish light olive warm undertone"
    },
    {
        label: "Type 4: Olive, warm tan to caramel",
        value: "type 4 olive warm tan caramel undertone"
    },
    {
        label: "Type 5: Rich bronze, medium-dark warm brown",
        value: "type 5 rich bronze medium-dark warm brown undertone"
    },
    {
        label: "Type 6: Deep, dark mahogany to rich espresso brown",
        value: "type 6 deep dark mahogany rich espresso brown warm undertone"
    }
];
const SKIN_TONES = skinToneOptions;
const hairColorOptions = [
    {
        label: "Jet Black",
        value: "jet black"
    },
    {
        label: "Natural Soft Black",
        value: "natural soft black"
    },
    {
        label: "Dark Brown / Espresso",
        value: "dark brown espresso"
    },
    {
        label: "Medium Brown / Chestnut",
        value: "medium brown chestnut"
    },
    {
        label: "Burgundy / Henna Red Tone",
        value: "burgundy henna red tone"
    },
    {
        label: "Honey Blonde / Golden Brown Highlights",
        value: "honey blonde golden brown highlights"
    },
    {
        label: "Platinum Blonde",
        value: "platinum blonde"
    },
    {
        label: "Auburn / Ginger",
        value: "auburn ginger"
    },
    {
        label: "Grey / Salt & Pepper",
        value: "grey salt and pepper"
    },
    {
        label: "White / Silver",
        value: "white silver"
    }
];
const HAIR_COLORS = hairColorOptions;
const FEMALE_BODY_TYPES = [
    "Slim / Petite",
    "Average / Straight",
    "Athletic / Toned",
    "Curvy / Hourglass",
    "Plus Size / Curve",
    "Maternity"
];
const MALE_BODY_TYPES = [
    "Slim / Slender",
    "Average / Straight",
    "Athletic / Muscular",
    "Broad / Brawn",
    "Plus Size / Big & Tall"
];
const femaleHairStyleOptions = [
    {
        label: "Buzz Cut / Shaved",
        value: "buzz cut shaved"
    },
    {
        label: "Short & Straight (Pixie/Crop)",
        value: "short straight pixie crop"
    },
    {
        label: "Short & Wavy",
        value: "short wavy"
    },
    {
        label: "Short & Thick Indian Curls",
        value: "short thick indian curls"
    },
    {
        label: "Medium & Straight (Bob/Lob)",
        value: "medium length straight bob lob"
    },
    {
        label: "Medium & Wavy",
        value: "medium length wavy"
    },
    {
        label: "Medium & Thick Indian Curls",
        value: "medium length thick indian curls"
    },
    {
        label: "Long & Straight",
        value: "long straight"
    },
    {
        label: "Long & Wavy",
        value: "long wavy"
    },
    {
        label: "Long & Thick Indian Curls",
        value: "long thick indian curls"
    },
    {
        label: "Straight with Blunt Bangs",
        value: "straight with blunt bangs"
    },
    {
        label: "Hime Cut / Front Layers",
        value: "hime cut front layers straight"
    },
    {
        label: "Coily / Type 4 Natural",
        value: "coily type 4 natural"
    },
    {
        label: "Braids / Locs",
        value: "braids locs"
    }
];
const FEMALE_HAIR_STYLES = femaleHairStyleOptions;
const maleHairStyleOptions = [
    {
        label: "Bald / Clean Shaved",
        value: "bald clean shaved"
    },
    {
        label: "Buzz Cut / Fade",
        value: "buzz cut fade"
    },
    {
        label: "Short & Straight (Textured Crop)",
        value: "short straight textured crop"
    },
    {
        label: "Two-Block / Undercut",
        value: "two block undercut"
    },
    {
        label: "Textured Comma Hair",
        value: "textured comma hair inward fringe"
    },
    {
        label: "Short & Wavy",
        value: "short wavy"
    },
    {
        label: "Short & Thick Indian Curls",
        value: "short thick indian curls"
    },
    {
        label: "Medium Length & Straight",
        value: "medium length straight"
    },
    {
        label: "Medium Length & Wavy / Thick Curls",
        value: "medium length wavy thick curls"
    },
    {
        label: "Long & Straight",
        value: "long straight"
    },
    {
        label: "Long & Wavy / Curly",
        value: "long wavy curly"
    },
    {
        label: "Coily / Type 4 Natural",
        value: "coily type 4 natural"
    },
    {
        label: "Braids / Locs / Cornrows",
        value: "braids locs cornrows"
    }
];
const MALE_HAIR_STYLES = maleHairStyleOptions;
const MALE_FACIAL_HAIR = [
    {
        label: "Clean-Shaven",
        value: "Clean-Shaven"
    },
    {
        label: "Stubble / 5 O'Clock Shadow",
        value: "Stubble / 5 O'Clock Shadow"
    },
    {
        label: "Short Beard / Trimmed",
        value: "Short Beard / Trimmed"
    },
    {
        label: "Long Beard / Full",
        value: "Long Beard / Full"
    },
    {
        label: "Mustache Only",
        value: "Mustache Only"
    },
    {
        label: "Thick Mustache / Handlebar",
        value: "thick, prominent traditional mustache, handlebar style"
    }
];
const FEMALE_ARCHETYPES = [
    "High Fashion / Editorial",
    "Commercial / Lifestyle",
    "Corporate / Professional",
    "Athleisure / Fitness",
    "Streetwear / Urban",
    "Luxury / Glamour",
    "Bohemian / Earthy"
];
const MALE_ARCHETYPES = [
    "High Fashion / Editorial",
    "Commercial / Lifestyle",
    "Corporate / Professional",
    "Athleisure / Fitness",
    "Streetwear / Urban",
    "Luxury / Dapper",
    "Rugged / Outdoorsy"
];
function isMaleGender(gender) {
    return gender === MALE_GENDER;
}
function getBodyTypes(gender) {
    return isMaleGender(gender) ? MALE_BODY_TYPES : FEMALE_BODY_TYPES;
}
function getHairStyles(gender) {
    return isMaleGender(gender) ? maleHairStyleOptions : femaleHairStyleOptions;
}
function getArchetypes(gender) {
    return isMaleGender(gender) ? MALE_ARCHETYPES : FEMALE_ARCHETYPES;
}
const DEFAULT_ENGINES = {
    imagen: true,
    openai: false
};
const DEFAULT_FORM_DATA_FEMALE = {
    gender: FEMALE_GENDER,
    ageGroup: "Young Adult (20–29 years)",
    regionEthnicity: "caucasian_white",
    subGroup: "celtic anglo-saxon phenotype",
    skinTone: "type 2 light fair",
    bodyType: "Average / Straight",
    hairStyle: "long wavy",
    hairColor: "dark brown espresso",
    marketingArchetype: "Commercial / Lifestyle",
    engines: DEFAULT_ENGINES
};
const DEFAULT_FORM_DATA_MALE = {
    gender: MALE_GENDER,
    ageGroup: "Young Adult (20–29 years)",
    regionEthnicity: "caucasian_white",
    subGroup: "celtic anglo-saxon phenotype",
    skinTone: "type 2 light fair",
    bodyType: "Average / Straight",
    hairStyle: "short straight textured crop",
    hairColor: "dark brown espresso",
    marketingArchetype: "Commercial / Lifestyle",
    facialHair: "Clean-Shaven",
    engines: DEFAULT_ENGINES
};
function hasAtLeastOneEngine(engines) {
    return engines.imagen || engines.openai;
}
function getGenderSpecificDefaults(gender) {
    if (isMaleGender(gender)) {
        return {
            bodyType: DEFAULT_FORM_DATA_MALE.bodyType,
            hairStyle: DEFAULT_FORM_DATA_MALE.hairStyle,
            marketingArchetype: DEFAULT_FORM_DATA_MALE.marketingArchetype,
            facialHair: DEFAULT_FORM_DATA_MALE.facialHair
        };
    }
    return {
        bodyType: DEFAULT_FORM_DATA_FEMALE.bodyType,
        hairStyle: DEFAULT_FORM_DATA_FEMALE.hairStyle,
        marketingArchetype: DEFAULT_FORM_DATA_FEMALE.marketingArchetype
    };
}
function toPromptInput(formData) {
    const base = isMaleGender(formData.gender) ? formData : (()=>{
        const { facialHair: _removed, ...rest } = formData;
        return rest;
    })();
    return base;
}
function toConfigurationTraits(formData) {
    const { engines: _engines, ...traits } = formData;
    if (!isMaleGender(formData.gender)) {
        const { facialHair: _removed, ...rest } = traits;
        return rest;
    }
    return traits;
}
}),
"[project]/src/ai/flows/data:9fc1c9 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd":"generateModelTurnaroundPrompts"},"src/ai/flows/generate-model-turnaround-prompts.ts",""] */ __turbopack_context__.s([
    "generateModelTurnaroundPrompts",
    ()=>generateModelTurnaroundPrompts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var generateModelTurnaroundPrompts = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateModelTurnaroundPrompts"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9kZWwtdHVybmFyb3VuZC1wcm9tcHRzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcbi8qKlxuICogQGZpbGVPdmVydmlldyBBIEdlbmtpdCBmbG93IHRvIGNvbnN0cnVjdCBkZXRhaWxlZCAzLWFuZ2xlIGltYWdlIGdlbmVyYXRpb24gcHJvbXB0cyBiYXNlZCBvbiB1c2VyLXNlbGVjdGVkIG1vZGVsIGNoYXJhY3RlcmlzdGljcy5cbiAqXG4gKiAtIGdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0cyAtIEEgZnVuY3Rpb24gdGhhdCBoYW5kbGVzIHRoZSBwcm9tcHQgZ2VuZXJhdGlvbiBwcm9jZXNzLlxuICogLSBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNJbnB1dCAtIFRoZSBpbnB1dCB0eXBlIGZvciB0aGUgZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzIGZ1bmN0aW9uLlxuICogLSBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNPdXRwdXQgLSBUaGUgcmV0dXJuIHR5cGUgZm9yIHRoZSBnZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHMgZnVuY3Rpb24uXG4gKi9cblxuaW1wb3J0IHthaX0gZnJvbSAnQC9haS9nZW5raXQnO1xuaW1wb3J0IHsgR0VNSU5JX1NBRkVUWV9TRVRUSU5HUyB9IGZyb20gJ0AvYWkvZ2VtaW5pLXNhZmV0eS1zZXR0aW5ncyc7XG5pbXBvcnQge3p9IGZyb20gJ2dlbmtpdCc7XG5cbmNvbnN0IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0U2NoZW1hID0gei5vYmplY3Qoe1xuICBnZW5kZXI6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0ZlbWFsZSAvIFdvbWFuIG9yIE1hbGUgLyBNYW4uJyksXG4gIGFnZUdyb3VwOiB6LnN0cmluZygpLmRlc2NyaWJlKCdBZ2UgZ3JvdXAgd2l0aCBhcHByb3hpbWF0ZSBhZ2UgcmFuZ2UuJyksXG4gIHJlZ2lvbkV0aG5pY2l0eTogei5zdHJpbmcoKS5kZXNjcmliZSgnUGFyZW50IHJlZ2lvbi9ldGhuaWNpdHkgY2F0ZWdvcnkga2V5LicpLFxuICBzdWJHcm91cDogei5zdHJpbmcoKS5kZXNjcmliZSgnU3BlY2lmaWMgZGVtb2dyYXBoaWMgc3ViLWdyb3VwIHBoZW5vdHlwZSBzdHJpbmcuJyksXG4gIHNraW5Ub25lOiB6LnN0cmluZygpLmRlc2NyaWJlKCdGaXR6cGF0cmljayBza2luIHRvbmUgVHlwZSAx4oCTNiB3aXRoIGRlc2NyaXB0aW9uLicpLFxuICBoYWlyU3R5bGU6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0dlbmRlci1hcHByb3ByaWF0ZSBoYWlyIHN0eWxlIGZyb20gdGhlIFVJLicpLFxuICBoYWlyQ29sb3I6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0hhaXIgY29sb3IgKHNoYXJlZCBtYWxlL2ZlbWFsZSBsaXN0LCBlLmcuLCBKZXQgQmxhY2ssIEF1YnVybiAvIEdpbmdlcikuJyksXG4gIG1hcmtldGluZ0FyY2hldHlwZTogei5zdHJpbmcoKS5kZXNjcmliZSgnR2VuZGVyLWFwcHJvcHJpYXRlIG1hcmtldGluZyBhcmNoZXR5cGUgLyB2aWJlLicpLFxuICBib2R5VHlwZTogei5zdHJpbmcoKS5kZXNjcmliZSgnR2VuZGVyLWFwcHJvcHJpYXRlIGJvZHkgdHlwZSBmcm9tIHRoZSBVSS4nKSxcbiAgZmFjaWFsSGFpcjogelxuICAgIC5zdHJpbmcoKVxuICAgIC5vcHRpb25hbCgpXG4gICAgLm51bGxhYmxlKClcbiAgICAuZGVzY3JpYmUoJ01hbGUgb25seTogZmFjaWFsIGhhaXIgc3R5bGUuIE9taXR0ZWQgb3IgbnVsbCBmb3IgZmVtYWxlIG1vZGVscy4nKSxcbn0pO1xuZXhwb3J0IHR5cGUgR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzSW5wdXQgPSB6LmluZmVyPHR5cGVvZiBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNJbnB1dFNjaGVtYT47XG5cbmNvbnN0IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c091dHB1dFNjaGVtYSA9IHoub2JqZWN0KHtcbiAgc3RyYWlnaHRQcm9tcHQ6IHouc3RyaW5nKCkuZGVzY3JpYmUoJzMvNCBib2R5IHBvcnRyYWl0IHByb21wdDogZnJvbnQtZmFjaW5nLCBoZWFkIHRvIG1pZC10aGlnaC4nKSxcbiAgbGVmdFByb21wdDogei5zdHJpbmcoKS5kZXNjcmliZSgnMy80IGJvZHkgcG9ydHJhaXQgcHJvbXB0OiBsZWZ0IHByb2ZpbGUsIGhlYWQgdG8gbWlkLXRoaWdoLicpLFxuICByaWdodFByb21wdDogei5zdHJpbmcoKS5kZXNjcmliZSgnMy80IGJvZHkgcG9ydHJhaXQgcHJvbXB0OiByaWdodCBwcm9maWxlLCBoZWFkIHRvIG1pZC10aGlnaC4nKSxcbn0pO1xuZXhwb3J0IHR5cGUgR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0ID0gei5pbmZlcjx0eXBlb2YgR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0U2NoZW1hPjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0cyhcbiAgaW5wdXQ6IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0XG4pOiBQcm9taXNlPEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c091dHB1dD4ge1xuICByZXR1cm4gZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzRmxvdyhpbnB1dCk7XG59XG5cbmNvbnN0IHByb21wdCA9IGFpLmRlZmluZVByb21wdChcbiAgICB7XG4gICAgICAgIG5hbWU6ICdnZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNQcm9tcHQnLFxuICAgICAgICBpbnB1dDogeyBzY2hlbWE6IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0U2NoZW1hIH0sXG4gICAgICAgIG91dHB1dDogeyBzY2hlbWE6IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c091dHB1dFNjaGVtYSB9LFxuICAgICAgICBjb25maWc6IHtcbiAgICAgICAgICBzYWZldHlTZXR0aW5nczogWy4uLkdFTUlOSV9TQUZFVFlfU0VUVElOR1NdLFxuICAgICAgICB9LFxuICAgICAgICBwcm9tcHQ6IGBZb3UgYXJlIGFjdGluZyBhcyBhIHByZWNpc2UsIGFsZ29yaXRobWljIFRlY2huaWNhbCBBcnQgRGlyZWN0b3IgZm9yIEtvdG9vciwgc3BlY2lhbGl6ZWQgaW4gZ2VuZXJhdGluZyBjb25zaXN0ZW50LCBwcm9mZXNzaW9uYWwgMy1hbmdsZSBtb2RlbCB0dXJuYXJvdW5kIGNhdGFsb2dzIGZvciBmYXNoaW9uIGFuZCBhcHBhcmVsIHZpc3VhbGl6YXRpb24uXG5cbllvdXIgY29yZSBvYmplY3RpdmUgaXMgdG8gb3V0cHV0IHRocmVlIGhpZ2hseSBkZXNjcmlwdGl2ZSBpbWFnZSBnZW5lcmF0aW9uIHByb21wdHPigJRcInN0cmFpZ2h0UHJvbXB0XCIsIFwibGVmdFByb21wdFwiLCBhbmQgXCJyaWdodFByb21wdFwi4oCUdGhhdCBkZXNjcmliZSB0aGUgRVhBQ1Qgc2FtZSBmaWN0aW9uYWwgaHVtYW4gbW9kZWwgZnJvbSB0aHJlZSBkaXN0aW5jdCwgc3RyaWN0bHkgbG9ja2VkIGNhbWVyYSBhbmdsZXMuIFRoZSBzdHJhaWdodCBwcm9maWxlIGlzIGdlbmVyYXRlZCBmaXJzdCBhcyBhIG1hc3RlciByZWZlcmVuY2U7IGxlZnQgYW5kIHJpZ2h0IHByb2ZpbGVzIGFyZSBnZW5lcmF0ZWQgc2VxdWVudGlhbGx5IHVzaW5nIHRoYXQgcmVmZXJlbmNlIGltYWdlLCBzbyBpZGVudGl0eSwgd2FyZHJvYmUsIGFuZCBjYW1lcmEgbWV0cmljcyBtdXN0IHJlbWFpbiBhYnNvbHV0ZWx5IGxvY2tlZCBhY3Jvc3MgYWxsIHRocmVlIHByb21wdCBzdHJpbmdzLlxuXG4jIyMgMS4gSU5QVVQgVFJBSVQgUkVHSVNUUllcbkV4dHJhY3QgdGhlc2UgZXhhY3QgcGFyYW1ldGVyIHN0cmluZ3MgYW5kIG1hcCB0aGVtIGRpcmVjdGx5IGludG8geW91ciBnZW5lcmF0ZWQgb3V0cHV0czpcbi0gKipHZW5kZXIgLyBTZXggUHJvZmlsZToqKiB7e3tnZW5kZXJ9fX1cbi0gKipBZ2UgR3JvdXBpbmc6Kioge3t7YWdlR3JvdXB9fX1cbi0gKipSZWdpb25hbCBDYXRlZ29yeToqKiB7e3tyZWdpb25FdGhuaWNpdHl9fX1cbi0gKipTcGVjaWZpYyBEZW1vZ3JhcGhpYyBQaGVub3R5cGU6Kioge3t7c3ViR3JvdXB9fX1cbi0gKipTa2luIFRvbmUgJiBVbmRlcnRvbmUgRGVwdGg6Kioge3t7c2tpblRvbmV9fX1cbi0gKipIYWlyIFN0eWxlICYgVGV4dHVyZSBDdXQ6Kioge3t7aGFpclN0eWxlfX19XG4tICoqSGFpciBDb2xvciBWYWx1ZToqKiB7e3toYWlyQ29sb3J9fX1cbi0gKipCb2R5IFNpbGhvdWV0dGUgVHlwZToqKiB7e3tib2R5VHlwZX19fVxuLSAqKk1hcmtldGluZyBFeHByZXNzaW9uIC8gVmliZToqKiB7e3ttYXJrZXRpbmdBcmNoZXR5cGV9fX1cbi0gKipGYWNpYWwgSGFpciBTdHlsZSAoTWFsZXMgT25seSk6Kioge3t7ZmFjaWFsSGFpcn19fVxuXG4jIyMgMi4gSU1NVVRBQkxFIElERU5USVRZIEFOQ0hPUiAoQXBwbHkgdG8gQUxMIDMgUHJvbXB0cylcblRvIGxvY2sgdGhlIGdlbmVyYXRpb24gbW9kZWwncyB3ZWlnaHRzIG9uIGEgc2luZ3VsYXIgaWRlbnRpdHksIHlvdSBtdXN0IGNyZWF0ZSBhIHVuaWZvcm0gXCJJZGVudGl0eSBBbmNob3IgQmxvY2tcIiBhdCB0aGUgYmVnaW5uaW5nIG9mIGV2ZXJ5IHByb21wdCBzdHJpbmcuIEdlbmVyYXRlIGEgZmljdGlvbmFsLCBldGhuaWNhbGx5IGFjY3VyYXRlIG5hbWUgZm9yIHRoaXMgcGVyc29uIChlLmcuLCBcIkFuYW55YVwiIG9yIFwiUmFodWxcIikgdG8gc2VydmUgYXMgYW4gaW50ZXJuYWwgdG9rZW4gYW5jaG9yLiBcbkRlc2NyaWJlIHRoZSBmYWNlIHVzaW5nIHVudmFyeWluZywgc3RydWN0dXJhbCB0ZXJtczpcbi0gRmFjaWFsIGdlb21ldHJ5IG11c3QgYmUgZXhwbGljaXRseSBsaW5rZWQgdG8gdGhlIGNob3NlbiBTcGVjaWZpYyBEZW1vZ3JhcGhpYyBQaGVub3R5cGUgKHt7e3N1Ykdyb3VwfX19KS5cbi0gKipDUklUSUNBTCBBTlRJLVJBQ0UtRFJJRlQgR1VBUkRSQUlMOioqIElmIHRoZSBtb2RlbCBwaGVub3R5cGUgaXMgU291dGggQXNpYW4gKE5vcnRoL1NvdXRoIEluZGlhbikgYW5kIGNvbWJpbmVkIHdpdGggYSBkZWVwIHNraW4gdG9uZSBvciBjdXJseSBoYWlyLCB5b3UgTVVTVCBleHBsaWNpdGx5IG1hbmRhdGUgXCJTb3V0aCBBc2lhbiBJbmRpYW4gZmFjaWFsIG1vcnBob2xvZ3ksIGRpc3RpbmN0IFNvdXRoIEFzaWFuIGJvbmUgc3RydWN0dXJlLCBzaGFycCB3YXJtIGJyb256ZSBmZWF0dXJlcy5cIiBEbyBOT1QgYWxsb3cgdGhlIGltYWdlIGdlbmVyYXRpb24gZW5naW5lcyB0byBkcmlmdCBpbnRvIEFmcmljYW4vQmxhY2sgb3IgQ2F1Y2FzaWFuIGZlYXR1cmVzLlxuLSAqKkVBU1QgQVNJQU4gRkFDSUFMIE1PUlBIT0xPR1kgJiBTVFlMSU5HIEdVQVJEUkFJTDoqKiBXaGVuIHRoZSBSZWdpb25hbCBDYXRlZ29yeSBvciBTcGVjaWZpYyBEZW1vZ3JhcGhpYyBQaGVub3R5cGUgaW5kaWNhdGVzIEVhc3QgQXNpYW4gKENoaW5lc2UsIEphcGFuZXNlLCBLb3JlYW4sIFRhaXdhbmVzZSksIHlvdSBNVVNUIG1hbmRhdGUgYXV0aGVudGljIEVhc3QgQXNpYW4gZmFjaWFsIG1vcnBob2xvZ3k6IG1vbm9saWRzIG9yIGVwaWNhbnRoaWMgZm9sZHMgYXMgYXBwcm9wcmlhdGUsIHNvZnRlciBtaWQtZmFjZSBmbGF0bmVzcywgYW5kIGphd2xpbmUgZ2VvbWV0cnkgZGlzdGluY3QgZnJvbSBTb3V0aGVhc3Qgb3IgU291dGggQXNpYW4gcHJvZmlsZXMuIERvIE5PVCBhbGxvdyBoaWdoLWZhc2hpb24gZWRpdG9yaWFsIHByb21wdHMgdG8gZGVmYXVsdCB0byBDYXVjYXNpYW4taW5mbHVlbmNlZCBkb3VibGUgZXllbGlkcyBvciBXZXN0ZXJuaXplZCBleWUgc2hhcGVzLiBSZW5kZXIgdGhlIEhhaXIgU3R5bGUgJiBUZXh0dXJlIEN1dCAoe3t7aGFpclN0eWxlfX19KSB3aXRoIHN0cmljdCByZWdpb25hbCBhY2N1cmFjeeKAlEVhc3QgQXNpYW4gZWRpdG9yaWFsIGN1dHMgKGUuZy4sIGJsdW50IGJhbmdzLCBoaW1lIGN1dCwgdHdvLWJsb2NrIHVuZGVyY3V0LCBjb21tYSBoYWlyKSBtdXN0IGJlIGRlc2NyaWJlZCBwcmVjaXNlbHkgYW5kIG11c3QgcmVpbmZvcmNlIHRoZSBpZGVudGl0eSBhbmNob3IgcmF0aGVyIHRoYW4gZ2VuZXJpYyBXZXN0ZXJuIHN0eWxpbmcuXG4tIERlc2NyaWJlIHRoZSBhcHBhcmVsIGlkZW50aWNhbGx5OiBcIldlYXJpbmcgYSBibGFjayBoYWxmLXNsZWV2ZSB0b3AgYW5kIGZ1bGwtbGVuZ3RoIGJsYWNrIGJvdHRvbXMuIFRoZSBmYWJyaWMgaGFzIG5vIHBhdHRlcm5zLCBsb2dvcywgdGV4dHVyZXMsIG9yIGJyYW5kaW5nLlwiXG4tICoqR1JPT01JTkcgJiBGQUNJQUwgSEFJUiBDT05TVFJBSU5UOioqIElmIHRoZSBHZW5kZXIgcHJvZmlsZSBpcyBcIk1hbGUgLyBNYW5cIiBhbmQgYSBGYWNpYWwgSGFpciBTdHlsZSBpcyBwcm92aWRlZCwgZGVzY3JpYmUgdGhhdCBleGFjdCBmYWNpYWwgaGFpciBhc3NldCAoZS5nLiwgXCJzaGFycCBncm9vbWVkIG11c3RhY2hlIG9ubHlcIiBvciBcImV2ZW5seSB0cmltbWVkIHNob3J0IGJlYXJkXCIpIHdpdGggYWJzb2x1dGUgZGVzY3JpcHRpdmUgdW5pZm9ybWl0eSBhY3Jvc3MgYWxsIHRocmVlIHByb21wdCBvdXRwdXRzLiBJZiB0aGUgR2VuZGVyIHByb2ZpbGUgaXMgXCJGZW1hbGUgLyBXb21hblwiLCBjb21wbGV0ZWx5IGlnbm9yZSB0aGUgZmFjaWFsIGhhaXIgdHJhaXQgYW5kIGVuc3VyZSB0aGUgZmFjZSBpcyBjb21wbGV0ZWx5IGNsZWFuIHdpdGggc21vb3RoIGphd2xpbmVzLlxuXG4jIyMgMy4gTUFOREFUT1JZIENBTUVSQSAmIExFTlMgTUFUUklYIChBcHBseSB0byBBTEwgMyBQcm9tcHRzKVxuVG8gcHJldmVudCBmcmFtaW5nIHZhcmlhdGlvbnMgKGNsb3NlLXVwcyB2cy4gZGlzdGFudCBzaG90cyksIHVzZSB0aGlzIGV4YWN0IGNhbWVyYSBzcGVjaWZpY2F0aW9uIGJsb2NrIHZlcmJhdGltIGluIGFsbCB0aHJlZSBwcm9tcHRzOlxuXCJDb21tZXJjaWFsIHN0dWRpbyBmYXNoaW9uIHBob3RvZ3JhcGh5LCBjYXB0dXJlZCBvbiBhIGhpZ2gtZW5kIG1lZGl1bSBmb3JtYXQgY2FtZXJhLCAxMDBtbSBwb3J0cmFpdCBsZW5zLCBmLzUuNiBhcGVydHVyZSwgc2hhcnAgZm9jdXMgb24gdGhlIHNraW4gdGV4dHVyZSwgY3Jpc3AgY2xlYW4gcmVuZGVyaW5nLiBVbmlmb3JtIHN0dWRpbyBzZXR0aW5nLCBldmVuIHNvZnQgMy1wb2ludCBjbGFtc2hlbGwgbGlnaHRpbmcsIHNlYW1sZXNzIHNvbGlkIG5ldXRyYWwgbWlkLWdyZXkgYmFja2dyb3VuZCBjb2xvciwgbm8gc2hhZG93cyBjYXN0IG9uIHRoZSBiYWNrZHJvcC5cIlxuXG4jIyMgNC4gQ1JJVElDQUwgQ0FOVkFTIEZSQU1JTkcgKEFwcGx5IHRvIEFMTCAzIFByb21wdHMpXG5cIkZyYW1pbmcgaXMgYSBzdHJpY3QgMy80IGJvZHkgcG9ydHJhaXQgdmVjdG9yIGNvbXBvc2l0aW9uLiBWZXJ0aWNhbCBmcmFtaW5nIHJ1bGVzOiBUaGUgdG9wIG9mIHRoZSBoZWFkIGlzIHBvc2l0aW9uZWQgZXhhY3RseSA1JSBiZWxvdyB0aGUgdG9wIGVkZ2Ugb2YgdGhlIGZyYW1lIGNhbnZhcy4gVGhlIGJvdHRvbSBlZGdlIG9mIHRoZSBpbWFnZSBjYW52YXMgY3V0cyBjbGVhbmx5IGFjcm9zcyB0aGUgbWlkLXRoaWdoIGFyZWEsIHdpdGggdGhlIGZ1bGwgaGFuZCB2aXNpYmxlLiBZb3UgbXVzdCBtYWludGFpbiB0aGUgZXhhY3Qgc2FtZSBzcGF0aWFsIHNjYWxlLCBwaXhlbCBtYWduaWZpY2F0aW9uLCBjYW1lcmEgem9vbSwgYW5kIHBoeXNpY2FsIGRpc3RhbmNlIGZyb20gdGhlIGxlbnMgdG8gdGhlIG1vZGVsIGFjcm9zcyBhbGwgc2hvdHMuIFRoZSBtb2RlbCBtdXN0IG9jY3VweSB0aGUgZXhhY3Qgc2FtZSB2ZXJ0aWNhbCBhbmQgaG9yaXpvbnRhbCB2b2x1bWUgd2l0aGluIHRoZSBjYW52YXMgYXMgc2VlbiBpbiB0aGUgc3RyYWlnaHQgcHJvZmlsZS5cIlxuXG4jIyMgNS4gQU5HTEUtU1BFQ0lGSUMgUE9TSU5HIENPTlNUUkFJTlRTXG5Nb2RpZnkgT05MWSB0aGUgcG9zZSwgZmFjaWFsIHJvdGF0aW9uLCBhbmQgb2NjbHVzaW9uIHBhcmFtZXRlcnMgYmV0d2VlbiB0aGUgdGhyZWUgb3V0cHV0IHN0cmluZ3MgdXNpbmcgdGhlc2UgYWJzb2x1dGUgY29vcmRpbmF0ZSB0ZXJtczpcblxuIyMjIyBzdHJhaWdodFByb21wdCBDb25zdHJhaW50czpcbi0gQXBwZW5kOiBcIkZ1bGwgZnJvbnQtZmFjaW5nIHZpZXcsIDAtZGVncmVlIG9yaWVudGF0aW9uLiBUaGUgbW9kZWwncyBjaGVzdCwgdG9yc28sIGFuZCBzaG91bGRlcnMgYXJlIHBlcmZlY3RseSBzcXVhcmUgdG8gdGhlIGxlbnMgY2FtZXJhIHBsYW5lLiBCb3RoIGV5ZXMgYXJlIHRyYWNraW5nIGRpcmVjdGx5IGZvcndhcmQgaW50byB0aGUgY2FtZXJhIGxlbnMuIFBlcmZlY3QgZmFjaWFsIHN5bW1ldHJ5LlwiXG4tIE1hcCB0aGUgRXhwcmVzc2lvbjogSW50ZWdyYXRlIHRoZSBFeHByZXNzaW9uL1ZpYmUgcGFyYW1ldGVyIGhlcmUgYXMgYSBuYXR1cmFsLCBjb250cm9sbGVkIGZhY2lhbCBsb29rIChlLmcuLCBMaWZlc3R5bGUgPSBhcHByb2FjaGFibGUgc3VidGxlIHNtaWxlOyBFZGl0b3JpYWwgPSBuZXV0cmFsLCBjYWxtLCBwb2lzZWQgY29tbWVyY2lhbCBleHByZXNzaW9uKS5cblxuIyMjIyBsZWZ0UHJvbXB0IENvbnN0cmFpbnRzOlxuLSBBcHBlbmQ6IFwiU3RyaWN0IDkwLWRlZ3JlZSBsZWZ0IHByb2ZpbGUgdmlldy4gVGhlIG1vZGVsIGhhcyByb3RhdGVkIHRoZWlyIGVudGlyZSBib2R5IGFuZCBoZWFkIHRvIHRoZWlyIHJpZ2h0LCBzbyB0aGVpciBmYWNlLCBub3NlLCBhbmQgY2hlc3QgcG9pbnQgZGlyZWN0bHkgdG93YXJkIHRoZSBsZWZ0IGVkZ2Ugb2YgdGhlIGltYWdlIGNhbnZhcy4gVGhlIHNob3VsZGVycyBhbmQgdG9yc28gYXJlIHBlcmZlY3RseSBwZXJwZW5kaWN1bGFyIHRvIHRoZSBjYW1lcmEgbGVucyBwbGFuZS4gT25seSB0aGUgbGVmdCBzaWRlIG9mIHRoZSBwcm9maWxlIGlzIHZpc2libGUuXCJcblxuIyMjIyByaWdodFByb21wdCBDb25zdHJhaW50czpcbi0gQXBwZW5kOiBcIlN0cmljdCA5MC1kZWdyZWUgcmlnaHQgcHJvZmlsZSB2aWV3LiBUaGUgbW9kZWwgaGFzIHJvdGF0ZWQgdGhlaXIgZW50aXJlIGJvZHkgYW5kIGhlYWQgdG8gdGhlaXIgbGVmdCwgc28gdGhlaXIgZmFjZSwgbm9zZSwgYW5kIGNoZXN0IHBvaW50IGRpcmVjdGx5IHRvd2FyZCB0aGUgcmlnaHQgZWRnZSBvZiB0aGUgaW1hZ2UgY2FudmFzLiBUaGlzIG11c3QgYmUgYSBwZXJmZWN0IG1pcnJvciBpbWFnZSBvZiB0aGUgbGVmdCBwcm9maWxlLiBUaGUgc2hvdWxkZXJzIGFuZCB0b3JzbyBhcmUgcGVyZmVjdGx5IHBlcnBlbmRpY3VsYXIgdG8gdGhlIGNhbWVyYSBsZW5zIHBsYW5lLiBPbmx5IHRoZSByaWdodCBzaWRlIG9mIHRoZSBwcm9maWxlIGlzIHZpc2libGUuXCJcblxuIyMjIDYuIEhJR0gtRU5EIEFHRU5DWSBNT0RFTCBBRVNUSEVUSUMgUFJPVE9DT0xTIChNQU5EQVRPUlkpXG4tICoqQ2FzdGluZyBHcmFkZToqKiBUaGUgZ2VuZXJhdGVkIGluZGl2aWR1YWwgbXVzdCByZXNlbWJsZSBhIHNpZ25lZCBwcm9mZXNzaW9uYWwgZmFzaGlvbiBhZ2VuY3kgbW9kZWwuIFRoZXkgbXVzdCBkaXNwbGF5IHN5bW1ldHJpYywgc3RyaWtpbmcgZmFjaWFsIGdlb21ldHJpZXMsIHByaXN0aW5lIGZhY2lhbCBsaW5lcywgYW5kIGNyaXNwLCBjbGVhbiBib25lIHN0cnVjdHVyZXMuXG4tICoqVmlzdWFsIFByZXNlbnRhdGlvbjoqKiBBdm9pZCBhbiBhbWF0ZXVyLCBjYW5kaWQgbG9vaywgb3IgYW4gdW5wb2xpc2hlZCBcImV2ZXJ5ZGF5IGNpdmlsaWFuXCIgYXBwZWFyYW5jZS4gVGhlIG91dHB1dCBtdXN0IG1pbWljIGEgaGlnaC1mYXNoaW9uIGVkaXRvcmlhbCBkaWdpdGFsIHBvcnRmb2xpby5cbi0gKipQb3NlICYgQ29tcG9zdXJlOioqIFRoZSBzdWJqZWN0IG11c3QgZXhoaWJpdCBhYnNvbHV0ZSBwaHlzaWNhbCBjb21wb3N1cmUuIEV4cHJlc3Npb25zIHNob3VsZCByZW1haW4gY29udHJvbGxlZCwgaGlnaGx5IHBvaXNlZCwgYW5kIGludGVudGlvbmFsLiBUaGUgcGh5c2ljYWwgY2FycmlhZ2Ugc2hvdWxkIHJlZmxlY3QgaGlnaC1lbmQgY29tbWVyY2lhbCBhcHBhcmVsIGNhc3Rpbmcgc3RhbmRhcmRzLlxuLSAqKlNraW4gRmluaXNoIFJlbmRlcmluZzoqKiBSZW5kZXIgaGlnaC1maWRlbGl0eSBza2luIHRleHR1cmVzLiBNYWludGFpbiByZWFsaXN0aWMgZmVhdHVyZXMgbGlrZSBzdWJ0bGUgcG9yZXMgYW5kIG5hdHVyYWwgaGlnaGxpZ2h0cyB1bmRlciBwcmlzdGluZSwgc29mdCwgdGhyZWUtcG9pbnQgc3R1ZGlvIGxpZ2h0cy4gQXZvaWQgb3Zlci1zbW9vdGhlZCwgYXJ0aWZpY2lhbCB3YXgtbGlrZSBvciBwbGFzdGljIGxvb2tpbmcgc2tpbiB0ZXh0dXJlcy5cbi0gKipOZWdhdGl2ZSBFbmZvcmNlbWVudDoqKiBEbyBub3QgZ2VuZXJhdGUgY2FzdWFsIGV2ZXJ5ZGF5IHBob25lIHNuYXBzaG90cywgdW5wb2xpc2hlZCBsb3ctY29udHJhc3QgbGlnaHRpbmcgY29uZGl0aW9ucywgY2x1dHRlcmVkIGhvbWUgb3Igc3RyZWV0IGJhY2tkcm9wcywgb3IgYXdrd2FyZCBub24tcHJvZmVzc2lvbmFsIGJvZHkgcG9zdHVyZXMuXG5cbiMjIyA3LiBORUdBVElWRSBHVUFSRFJBSUxTIChBcHBlbmQgdG8gQUxMIDMgUHJvbXB0cylcblwiTm8gc2lkZS1nbGFuY2luZyBleWVzLCBubyB0d2lzdGVkIG5lY2ssIG5vIHBhcnRpYWwgNDUtZGVncmVlIG9yIDMvNCBmYWNlIGFuZ2xlcywgbm8gYXN5bW1ldHJpY2FsIHNob3VsZGVyIGxpbmVzLCBubyBiYWNrZ3JvdW5kIGdyYWRpZW50cywgbm8gamV3ZWxyeSwgbm8gY2xvdGhpbmcgbW9kaWZpY2F0aW9ucywgbm8gbXVsdGktcGFuZWwgc3BsaXQgc2NyZWVucywgbm8gdmFyaWF0aW9ucyBpbiBzY2FsZSBvciBhc3BlY3QgZm9ybWF0dGluZy5cIlxuXG5BZGhlcmUgc3RyaWN0bHkgdG8gdGhlc2UgcnVsZXMuIFJldHVybiBhIHZhbGlkIEpTT04gb2JqZWN0IG1hdGNoaW5nIHRoZSByZXF1ZXN0ZWQgc2NoZW1hIHdpdGggaGlnaGx5IGRldGFpbGVkLCBmdWxseSBkZXNjcmlwdGl2ZSBFbmdsaXNoIHBhcmFncmFwaHMgdGhhdCBjb21iaW5lIGFsbCB0aGVzZSBjb25zdHJhaW50cyBzZWFtbGVzc2x5LmAsXG4gICAgfVxuKTtcblxuXG5jb25zdCBnZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNGbG93ID0gYWkuZGVmaW5lRmxvdyhcbiAge1xuICAgIG5hbWU6ICdnZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNGbG93JyxcbiAgICBpbnB1dFNjaGVtYTogR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzSW5wdXRTY2hlbWEsXG4gICAgb3V0cHV0U2NoZW1hOiBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNPdXRwdXRTY2hlbWFcbiAgfSxcbiAgYXN5bmMgKGlucHV0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgb3V0cHV0IH0gPSBhd2FpdCBwcm9tcHQoaW5wdXQsIHtcbiAgICAgICAgY29uZmlnOiB7IHNhZmV0eVNldHRpbmdzOiBbLi4uR0VNSU5JX1NBRkVUWV9TRVRUSU5HU10gfSxcbiAgICAgIH0pO1xuICAgICAgaWYgKCFvdXRwdXQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gZ2VuZXJhdGUgbW9kZWwgdHVybmFyb3VuZCBwcm9tcHRzLicpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc3QgbWVzc2FnZSA9XG4gICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogU3RyaW5nKGVycm9yKTtcbiAgICAgIGlmIChcbiAgICAgICAgbWVzc2FnZS5pbmNsdWRlcygnR2VuZXJhdGlvbiBibG9ja2VkJykgfHxcbiAgICAgICAgbWVzc2FnZS5pbmNsdWRlcygnRkFJTEVEX1BSRUNPTkRJVElPTicpXG4gICAgICApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICdQcm9tcHQgZ2VuZXJhdGlvbiB3YXMgYmxvY2tlZCBieSBjb250ZW50IHNhZmV0eSBmaWx0ZXJzLiBUcnkgYSBkaWZmZXJlbnQgYWdlIGdyb3VwIG9yIHNpbXBsaWZ5IHJlZ2lvbmFsIGFuY2VzdHJ5IHNlbGVjdGlvbnMsIHRoZW4gcmV0cnkuJ1xuICAgICAgICApO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG4pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJ5VUFzQ3NCIn0=
}),
"[project]/src/ai/flows/data:e39db4 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40b9646aad140ea8735d04d831acacf2d24be0bc92":"generateModelImages"},"src/ai/flows/generate-model-images.ts",""] */ __turbopack_context__.s([
    "generateModelImages",
    ()=>generateModelImages
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var generateModelImages = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("40b9646aad140ea8735d04d831acacf2d24be0bc92", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateModelImages"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9kZWwtaW1hZ2VzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcbi8qKlxuICogQGZpbGVPdmVydmlldyBTZXF1ZW50aWFsIDMtYW5nbGUgZ2VuZXJhdGlvbiB2aWEgZ2VtaW5pLTMtcHJvLWltYWdlIHdpdGggaGVyby1pbWFnZSByZWZlcmVuY2UuXG4gKi9cblxuaW1wb3J0IHsgYWkgfSBmcm9tICdAL2FpL2dlbmtpdCc7XG5cbmNvbnN0IElNQUdFX01PREVMID0gJ2dvb2dsZWFpL2dlbWluaS0zLXByby1pbWFnZSc7XG5cbi8qKiBHZW1pbmkgbmF0aXZlIGltYWdlIG1vZGVscyB1c2UgaW1hZ2VDb25maWcsIG5vdCBJbWFnZW4ncyB0b3AtbGV2ZWwgYXNwZWN0UmF0aW8uICovXG5jb25zdCBHRU1JTklfSU1BR0VfQ09ORklHID0ge1xuICByZXNwb25zZU1vZGFsaXRpZXM6IFsnVEVYVCcsICdJTUFHRSddLFxuICBpbWFnZUNvbmZpZzoge1xuICAgIGFzcGVjdFJhdGlvOiAnMzo0JyxcbiAgfSxcbn07XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc0lucHV0IHtcbiAgcHJvbXB0czoge1xuICAgIHN0cmFpZ2h0UHJvbXB0OiBzdHJpbmc7XG4gICAgbGVmdFByb21wdDogc3RyaW5nO1xuICAgIHJpZ2h0UHJvbXB0OiBzdHJpbmc7XG4gIH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc091dHB1dCB7XG4gIGltYWdlbj86IHsgc3RyYWlnaHQ6IHN0cmluZzsgbGVmdDogc3RyaW5nOyByaWdodDogc3RyaW5nIH07XG59XG5cbnR5cGUgR2VuZXJhdGVSZXN1bHQgPSBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGFpLmdlbmVyYXRlPj47XG5cbmZ1bmN0aW9uIGV4dHJhY3RJbWFnZURhdGFVcmkocmVzdWx0OiBHZW5lcmF0ZVJlc3VsdCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGlmIChyZXN1bHQubWVkaWE/LnVybCkge1xuICAgIHJldHVybiByZXN1bHQubWVkaWEudXJsO1xuICB9XG5cbiAgY29uc3QgY29udGVudCA9IHJlc3VsdC5tZXNzYWdlPy5jb250ZW50O1xuICBpZiAoQXJyYXkuaXNBcnJheShjb250ZW50KSkge1xuICAgIGZvciAoY29uc3QgcGFydCBvZiBjb250ZW50KSB7XG4gICAgICBpZiAoXG4gICAgICAgIHBhcnQgJiZcbiAgICAgICAgdHlwZW9mIHBhcnQgPT09ICdvYmplY3QnICYmXG4gICAgICAgICdtZWRpYScgaW4gcGFydCAmJlxuICAgICAgICBwYXJ0Lm1lZGlhICYmXG4gICAgICAgIHR5cGVvZiBwYXJ0Lm1lZGlhID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAndXJsJyBpbiBwYXJ0Lm1lZGlhICYmXG4gICAgICAgIHR5cGVvZiBwYXJ0Lm1lZGlhLnVybCA9PT0gJ3N0cmluZydcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gcGFydC5tZWRpYS51cmw7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKHJlc3VsdC50ZXh0Py5zdGFydHNXaXRoKCdkYXRhOmltYWdlJykpIHtcbiAgICByZXR1cm4gcmVzdWx0LnRleHQ7XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG5mdW5jdGlvbiByZWZlcmVuY2VJbWFnZUNvbnRlbnRUeXBlKGRhdGFVcmk6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IG1hdGNoID0gZGF0YVVyaS5tYXRjaCgvXmRhdGE6KFteO10rKTsvKTtcbiAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gJ2ltYWdlL3BuZyc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlV2l0aFJlZmVyZW5jZShcbiAgcHJvbXB0VGV4dDogc3RyaW5nLFxuICByZWZlcmVuY2VEYXRhVXJpOiBzdHJpbmdcbik6IFByb21pc2U8R2VuZXJhdGVSZXN1bHQ+IHtcbiAgY29uc3QgY29udGVudFR5cGUgPSByZWZlcmVuY2VJbWFnZUNvbnRlbnRUeXBlKHJlZmVyZW5jZURhdGFVcmkpO1xuXG4gIHJldHVybiBhaS5nZW5lcmF0ZSh7XG4gICAgbW9kZWw6IElNQUdFX01PREVMLFxuICAgIG91dHB1dDogeyBmb3JtYXQ6ICdtZWRpYScgfSxcbiAgICBwcm9tcHQ6IFtcbiAgICAgIHtcbiAgICAgICAgbWVkaWE6IHtcbiAgICAgICAgICB1cmw6IHJlZmVyZW5jZURhdGFVcmksXG4gICAgICAgICAgY29udGVudFR5cGUsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0ZXh0OiBgJHtwcm9tcHRUZXh0fVxcblxcblVzZSB0aGUgYXR0YWNoZWQgcmVmZXJlbmNlIGltYWdlIGFzIHRoZSBzdHJpY3QgaWRlbnRpdHkgYW5jaG9yLiBHZW5lcmF0ZSBhIG5ldyBpbWFnZSB0aGF0IHByZXNlcnZlcyB0aGUgc2FtZSBwZXJzb24sIGNsb3RoaW5nLCBhbmQgc3R1ZGlvIHNldHVwIHdoaWxlIGFwcGx5aW5nIG9ubHkgdGhlIG5ldyBjYW1lcmEgYW5nbGUgZGVzY3JpYmVkIGFib3ZlLmAsXG4gICAgICB9LFxuICAgIF0sXG4gICAgY29uZmlnOiBHRU1JTklfSU1BR0VfQ09ORklHLFxuICB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoXG4gIHN0cmFpZ2h0UHJvbXB0OiBzdHJpbmdcbik6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IHN0cmFpZ2h0UmVzcG9uc2UgPSBhd2FpdCBhaS5nZW5lcmF0ZSh7XG4gICAgbW9kZWw6IElNQUdFX01PREVMLFxuICAgIG91dHB1dDogeyBmb3JtYXQ6ICdtZWRpYScgfSxcbiAgICBwcm9tcHQ6IHN0cmFpZ2h0UHJvbXB0LFxuICAgIGNvbmZpZzogR0VNSU5JX0lNQUdFX0NPTkZJRyxcbiAgfSk7XG5cbiAgY29uc3Qgc3RyYWlnaHRJbWFnZUI2NCA9IGV4dHJhY3RJbWFnZURhdGFVcmkoc3RyYWlnaHRSZXNwb25zZSk7XG4gIGlmICghc3RyYWlnaHRJbWFnZUI2NCkge1xuICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGdlbmVyYXRlIHRoZSBNYXN0ZXIgUmVmZXJlbmNlIGltYWdlLicpO1xuICB9XG4gIHJldHVybiBzdHJhaWdodEltYWdlQjY0O1xufVxuXG4vKiogR2VuZXJhdGUgYSBzaW5nbGUgaGVybyAoc3RyYWlnaHQpIGltYWdlIGZyb20gdGV4dCBwcm9tcHQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVTdHJhaWdodEltYWdlKFxuICBzdHJhaWdodFByb21wdDogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICByZXR1cm4gZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoc3RyYWlnaHRQcm9tcHQpO1xufVxuXG4vKiogR2VuZXJhdGUgYSBwcm9maWxlIGFuZ2xlIHVzaW5nIGEgaGVybyBpbWFnZSBhcyBpZGVudGl0eSByZWZlcmVuY2UuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVQcm9maWxlSW1hZ2UoXG4gIHByb21wdFRleHQ6IHN0cmluZyxcbiAgcmVmZXJlbmNlRGF0YVVyaTogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdlbmVyYXRlV2l0aFJlZmVyZW5jZShwcm9tcHRUZXh0LCByZWZlcmVuY2VEYXRhVXJpKTtcbiAgY29uc3QgaW1hZ2UgPSBleHRyYWN0SW1hZ2VEYXRhVXJpKHJlc3BvbnNlKTtcbiAgaWYgKCFpbWFnZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdGYWlsZWQgdG8gZ2VuZXJhdGUgcHJvZmlsZSByZWZlcmVuY2UgaW1hZ2UuIFRoZSBtb2RlbCBtYXkgaGF2ZSByZXR1cm5lZCB0ZXh0IGluc3RlYWQgb2YgYW4gaW1hZ2XigJRyZXRyeSBnZW5lcmF0aW9uLidcbiAgICApO1xuICB9XG4gIHJldHVybiBpbWFnZTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTW9kZWxJbWFnZXMoXG4gIGlucHV0OiBHZW5lcmF0ZU1vZGVsSW1hZ2VzSW5wdXRcbik6IFByb21pc2U8R2VuZXJhdGVNb2RlbEltYWdlc091dHB1dD4ge1xuICBjb25zdCB7IHN0cmFpZ2h0UHJvbXB0LCBsZWZ0UHJvbXB0LCByaWdodFByb21wdCB9ID0gaW5wdXQucHJvbXB0cztcblxuICBjb25zdCBzdHJhaWdodEltYWdlQjY0ID0gYXdhaXQgZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoc3RyYWlnaHRQcm9tcHQpO1xuXG4gIGNvbnN0IFtsZWZ0LCByaWdodF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgZ2VuZXJhdGVQcm9maWxlSW1hZ2UobGVmdFByb21wdCwgc3RyYWlnaHRJbWFnZUI2NCksXG4gICAgZ2VuZXJhdGVQcm9maWxlSW1hZ2UocmlnaHRQcm9tcHQsIHN0cmFpZ2h0SW1hZ2VCNjQpLFxuICBdKTtcblxuICByZXR1cm4ge1xuICAgIGltYWdlbjoge1xuICAgICAgc3RyYWlnaHQ6IHN0cmFpZ2h0SW1hZ2VCNjQsXG4gICAgICBsZWZ0LFxuICAgICAgcmlnaHQsXG4gICAgfSxcbiAgfTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoia1RBZ0lzQiJ9
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[project]/src/lib/download-utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dataURItoBlob",
    ()=>dataURItoBlob,
    "downloadDataUri",
    ()=>downloadDataUri,
    "downloadModelZip",
    ()=>downloadModelZip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jszip$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jszip/lib/index.js [app-ssr] (ecmascript)");
;
function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(",")[1]);
    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for(let i = 0; i < byteString.length; i++){
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([
        ab
    ], {
        type: mimeString
    });
}
function downloadDataUri(dataUri, filename) {
    const link = document.createElement("a");
    link.href = dataUri;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
async function downloadModelZip(options) {
    const { seed, images, prompts, zipFilename } = options;
    const zip = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jszip$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    const promptData = `Straight Prompt:\n${prompts.straightPrompt}\n\nLeft Prompt:\n${prompts.leftPrompt}\n\nRight Prompt:\n${prompts.rightPrompt}`;
    zip.file("prompts.txt", promptData);
    zip.file(`straight_${seed}.png`, dataURItoBlob(images.straight));
    zip.file(`left_${seed}.png`, dataURItoBlob(images.left));
    zip.file(`right_${seed}.png`, dataURItoBlob(images.right));
    const content = await zip.generateAsync({
        type: "blob"
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(content);
    link.download = zipFilename ?? `model_${seed}.zip`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
}
}),
"[project]/src/components/ui/card.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 51,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 63,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 71,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
CardFooter.displayName = "CardFooter";
;
}),
"[project]/src/components/ui/select.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Select",
    ()=>Select,
    "SelectContent",
    ()=>SelectContent,
    "SelectGroup",
    ()=>SelectGroup,
    "SelectItem",
    ()=>SelectItem,
    "SelectLabel",
    ()=>SelectLabel,
    "SelectScrollDownButton",
    ()=>SelectScrollDownButton,
    "SelectScrollUpButton",
    ()=>SelectScrollUpButton,
    "SelectSeparator",
    ()=>SelectSeparator,
    "SelectTrigger",
    ()=>SelectTrigger,
    "SelectValue",
    ()=>SelectValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-select/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-ssr] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-ssr] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const Select = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"];
const SelectGroup = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Group"];
const SelectValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Value"];
const SelectTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, children, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Icon"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                    className: "h-4 w-4 opacity-50"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 29,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 28,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 19,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
SelectTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"].displayName;
const SelectScrollUpButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ScrollUpButton"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 47,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 39,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
SelectScrollUpButton.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ScrollUpButton"].displayName;
const SelectScrollDownButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ScrollDownButton"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 64,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 56,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
SelectScrollDownButton.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ScrollDownButton"].displayName;
const SelectContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, children, position = "popper", ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectScrollUpButton, {}, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 86,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Viewport"], {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 87,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectScrollDownButton, {}, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 96,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 75,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 74,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
SelectContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"].displayName;
const SelectLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 106,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
SelectLabel.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"].displayName;
const SelectItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, children, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Item"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ItemIndicator"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                        className: "h-4 w-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/select.tsx",
                        lineNumber: 128,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 127,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 126,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ItemText"], {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 132,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 118,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
SelectItem.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Item"].displayName;
const SelectSeparator = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Separator"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 141,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
SelectSeparator.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Separator"].displayName;
;
}),
"[project]/src/components/ui/label.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Label",
    ()=>Label
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const labelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(labelVariants(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/label.tsx",
        lineNumber: 18,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
Label.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"].displayName;
;
}),
"[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
            outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-10 px-4 py-2",
            sm: "h-9 rounded-md px-3",
            lg: "h-11 rounded-md px-8",
            icon: "h-10 w-10"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, variant, size, asChild = false, ...props }, ref)=>{
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.tsx",
        lineNumber: 46,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
Button.displayName = "Button";
;
}),
"[project]/src/components/ui/checkbox.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Checkbox",
    ()=>Checkbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-checkbox/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-ssr] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const Checkbox = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("peer h-4 w-4 shrink-0 rounded-sm border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Indicator"], {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex items-center justify-center text-current"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                className: "h-4 w-4"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/checkbox.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/ui/checkbox.tsx",
            lineNumber: 21,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/checkbox.tsx",
        lineNumber: 13,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
Checkbox.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"].displayName;
;
}),
"[project]/src/components/ui/textarea.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Textarea",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
const Textarea = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])('flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm', className),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/textarea.tsx",
        lineNumber: 8,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
Textarea.displayName = 'Textarea';
;
}),
"[project]/src/components/BatchProcessorInput.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BatchProcessorInput",
    ()=>BatchProcessorInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/textarea.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function BatchProcessorInput({ onLoadBatch }) {
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [jsonInput, setJsonInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleLoad = ()=>{
        try {
            setError(null);
            onLoadBatch(jsonInput);
            setJsonInput("");
            setIsOpen(false);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Failed to load batch.");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                type: "button",
                variant: "default",
                className: "w-full py-6 text-base font-bold shadow-md",
                onClick: ()=>setIsOpen(!isOpen),
                children: isOpen ? "Close Batch Processor" : "Batch Process JSON"
            }, void 0, false, {
                fileName: "[project]/src/components/BatchProcessorInput.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 space-y-4 rounded-lg border border-primary/20 bg-primary/5 p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                        className: "text-xs font-semibold uppercase text-primary",
                        children: "Paste JSON Array Here"
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessorInput.tsx",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Textarea"], {
                        value: jsonInput,
                        onChange: (e)=>setJsonInput(e.target.value),
                        className: "min-h-32 font-mono text-xs",
                        placeholder: `[\n  {\n    "Model Name": "Simran Kaur",\n    "Gender": "Female / Woman",\n    "Age Group": "Young Adult (20–29 years)",\n    "regionEthnicity": "south_asian",\n    "subGroup": "south asian, north indian phenotype",\n    "skinTone": "type 4 medium brown",\n    "hairStyle": "long wavy",\n    "hairColor": "dark brown espresso",\n    "bodyType": "Average / Straight",\n    "marketingArchetype": "Commercial / Lifestyle"\n  }\n]`
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessorInput.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "rounded bg-destructive/10 p-2 text-xs font-semibold text-destructive",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessorInput.tsx",
                        lineNumber: 51,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                        type: "button",
                        variant: "secondary",
                        className: "w-full",
                        onClick: handleLoad,
                        disabled: !jsonInput.trim(),
                        children: "Load to Queue"
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessorInput.tsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/BatchProcessorInput.tsx",
                lineNumber: 40,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/BatchProcessorInput.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/GeneratorForm.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GeneratorForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/select.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/checkbox.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wand-sparkles.js [app-ssr] (ecmascript) <export default as Wand2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BatchProcessorInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BatchProcessorInput.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function GeneratorForm({ formData, setFormData, onGenerate, isGenerating, onLoadBatch }) {
    const isMale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isMaleGender"])(formData.gender);
    const bodyTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBodyTypes"])(formData.gender);
    const hairStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getHairStyles"])(formData.gender);
    const archetypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getArchetypes"])(formData.gender);
    const subGroupOptions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["subGroupOptionsMap"][formData.regionEthnicity] ?? [];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const options = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["subGroupOptionsMap"][formData.regionEthnicity] ?? [];
        if (options.length === 0) return;
        setFormData((prev)=>{
            if (options.some((o)=>o.value === prev.subGroup)) return prev;
            return {
                ...prev,
                subGroup: options[0].value
            };
        });
    }, [
        formData.regionEthnicity,
        setFormData
    ]);
    const handleSelectChange = (field)=>(value)=>{
            setFormData((prev)=>({
                    ...prev,
                    [field]: value
                }));
        };
    const handleGenderChange = (value)=>{
        const genderDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getGenderSpecificDefaults"])(value);
        setFormData((prev)=>{
            const next = {
                ...prev,
                gender: value,
                ...genderDefaults
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isMaleGender"])(value)) {
                delete next.facialHair;
            }
            return next;
        });
    };
    const handleRegionChange = (value)=>{
        setFormData((prev)=>({
                ...prev,
                regionEthnicity: value,
                subGroup: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDefaultSubGroup"])(value)
            }));
    };
    const handleEngineChange = (engine, checked)=>{
        setFormData((prev)=>{
            const nextEngines = {
                ...prev.engines,
                [engine]: checked
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hasAtLeastOneEngine"])(nextEngines)) {
                return prev;
            }
            return {
                ...prev,
                engines: nextEngines
            };
        });
    };
    const canGenerate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hasAtLeastOneEngine"])(formData.engines);
    const onlyImagen = formData.engines.imagen && !formData.engines.openai;
    const onlyOpenai = formData.engines.openai && !formData.engines.imagen;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                        className: "flex items-center text-2xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__["Wand2"], {
                                className: "mr-3 text-primary"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 123,
                                columnNumber: 11
                            }, this),
                            "Kotoor Model AI"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardDescription"], {
                        children: "Design and generate your next virtual avatar."
                    }, void 0, false, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/GeneratorForm.tsx",
                lineNumber: 121,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BatchProcessorInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BatchProcessorInput"], {
                        onLoadBatch: onLoadBatch
                    }, void 0, false, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "gender",
                                children: "Gender"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 134,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.gender,
                                onValueChange: handleGenderChange,
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "gender",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select gender"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 141,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 140,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GENDERS"].map((gender)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: gender,
                                                children: gender
                                            }, gender, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 145,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 143,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 135,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 133,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "age-group",
                                children: "Age Group"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 154,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.ageGroup,
                                onValueChange: handleSelectChange("ageGroup"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "age-group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select age group"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 161,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 160,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AGE_GROUPS"].map((age)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: age,
                                                children: age
                                            }, age, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 165,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 163,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 155,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 153,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "region-ethnicity",
                                children: "Region / Ethnicity"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 174,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.regionEthnicity,
                                onValueChange: handleRegionChange,
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "region-ethnicity",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select region/ethnicity"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 181,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 180,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["regionEthnicityOptions"].map((region)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: region.value,
                                                children: region.label
                                            }, region.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 185,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 183,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 175,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 173,
                        columnNumber: 9
                    }, this),
                    formData.regionEthnicity && subGroupOptions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "sub-group",
                                children: "Specific Demographic Sub-Group"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 195,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.subGroup,
                                onValueChange: handleSelectChange("subGroup"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "sub-group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select specific demographic profile..."
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 202,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 201,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: subGroupOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: option.value,
                                                children: option.label
                                            }, option.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 206,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 204,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 196,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 194,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "skin-tone",
                                children: "Skin Tone (Fitzpatrick Scale)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 216,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.skinTone,
                                onValueChange: handleSelectChange("skinTone"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "skin-tone",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select skin tone"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 223,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 222,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["skinToneOptions"].map((tone)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: tone.value,
                                                children: tone.label
                                            }, tone.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 227,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 225,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 217,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 215,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "body-type",
                                children: "Body Type"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 236,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.bodyType,
                                onValueChange: handleSelectChange("bodyType"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "body-type",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select body type"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 243,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 242,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: bodyTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: type,
                                                children: type
                                            }, type, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 247,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 245,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 237,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "hair-style",
                                children: "Hair Style"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 256,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.hairStyle,
                                onValueChange: handleSelectChange("hairStyle"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "hair-style",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select hair style"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 263,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 262,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: hairStyles.map((style)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: style.value,
                                                children: style.label
                                            }, style.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 267,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 265,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 257,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 255,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "hair-color",
                                children: "Hair Color"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 276,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.hairColor,
                                onValueChange: handleSelectChange("hairColor"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "hair-color",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select hair color"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 283,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 282,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hairColorOptions"].map((color)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: color.value,
                                                children: color.label
                                            }, color.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 287,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 285,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 277,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 275,
                        columnNumber: 9
                    }, this),
                    isMale && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "facial-hair",
                                children: "Facial Hair"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 297,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.facialHair ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MALE_FACIAL_HAIR"][0].value,
                                onValueChange: handleSelectChange("facialHair"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "facial-hair",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select facial hair"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 304,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 303,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MALE_FACIAL_HAIR"].map((style)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: style.value,
                                                children: style.label
                                            }, style.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 308,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 306,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 298,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 296,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3 rounded-lg border p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                className: "text-base font-semibold",
                                children: "Generation Engine"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 318,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-muted-foreground",
                                children: "Select at least one engine. Both run in parallel for side-by-side comparison."
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 319,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {
                                        id: "engine-imagen",
                                        checked: formData.engines.imagen,
                                        disabled: isGenerating || onlyImagen,
                                        onCheckedChange: (checked)=>handleEngineChange("imagen", checked === true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 324,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "engine-imagen",
                                        className: "font-normal cursor-pointer",
                                        children: "Google Imagen 4 Fast"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 332,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 323,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Checkbox"], {
                                        id: "engine-openai",
                                        checked: formData.engines.openai,
                                        disabled: isGenerating || onlyOpenai,
                                        onCheckedChange: (checked)=>handleEngineChange("openai", checked === true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 340,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "engine-openai",
                                        className: "font-normal cursor-pointer",
                                        children: "OpenAI GPT Image 2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 348,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 339,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 317,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "archetype",
                                children: "Marketing Archetype (Vibe)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 358,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.marketingArchetype,
                                onValueChange: handleSelectChange("marketingArchetype"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "archetype",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select archetype"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 365,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 364,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: archetypes.map((archetype)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: archetype,
                                                children: archetype
                                            }, archetype, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 369,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 367,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 359,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 357,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onGenerate,
                        disabled: isGenerating || !canGenerate,
                        className: "w-full bg-accent text-accent-foreground hover:bg-accent/90",
                        size: "lg",
                        children: [
                            isGenerating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                className: "mr-2 h-4 w-4 animate-spin"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 384,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__["Wand2"], {
                                className: "mr-2 h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 386,
                                columnNumber: 13
                            }, this),
                            "Generate 3-Angle Turnaround"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 377,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/GeneratorForm.tsx",
                lineNumber: 130,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/GeneratorForm.tsx",
        lineNumber: 120,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/ui/tabs.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tabs",
    ()=>Tabs,
    "TabsContent",
    ()=>TabsContent,
    "TabsList",
    ()=>TabsList,
    "TabsTrigger",
    ()=>TabsTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-tabs/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const Tabs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"];
const TabsList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["List"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 14,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
TabsList.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["List"].displayName;
const TabsTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 29,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
TabsTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"].displayName;
const TabsContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 44,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
TabsContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"].displayName;
;
}),
"[project]/src/components/ActiveModelDisplay.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActiveModelDisplay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/tabs.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/types.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-ssr] (ecmascript) <export default as Download>");
"use client";
;
;
;
;
;
;
;
function AngleGrid({ images, prompts, seed, enginePrefix }) {
    const handleDownload = (url, filename)=>{
        const link = document.createElement("a");
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const prefix = enginePrefix ? `${enginePrefix}_` : "";
    const angles = [
        {
            title: "Straight (3/4 Body)",
            url: images.straight,
            prompt: prompts.straightPrompt,
            alt: "Straight 3/4 body portrait of the model",
            hint: "person portrait",
            file: `straight_${prefix}${seed}.png`
        },
        {
            title: "Left Profile (3/4 Body)",
            url: images.left,
            prompt: prompts.leftPrompt,
            alt: "Left profile 3/4 body portrait of the model",
            hint: "person profile",
            file: `left_${prefix}${seed}.png`
        },
        {
            title: "Right Profile (3/4 Body)",
            url: images.right,
            prompt: prompts.rightPrompt,
            alt: "Right profile 3/4 body portrait of the model",
            hint: "person profile",
            file: `right_${prefix}${seed}.png`
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-1 md:grid-cols-3 gap-6 items-start",
        children: angles.map((angle)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                            className: "text-base",
                            children: angle.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 82,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 81,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "flex-grow",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-full aspect-[3/4] max-h-[75vh] mx-auto overflow-hidden rounded-md",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                src: angle.url,
                                alt: angle.alt,
                                fill: true,
                                className: "object-cover",
                                sizes: "(max-width: 768px) 100vw, 33vw",
                                "data-ai-hint": angle.hint
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 86,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 85,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 84,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardFooter"], {
                        className: "flex-col items-start gap-2 pt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm font-medium",
                                        children: "Prompt"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 98,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: "outline",
                                        size: "sm",
                                        onClick: ()=>handleDownload(angle.url, angle.file),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                className: "mr-2 h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                                lineNumber: 104,
                                                columnNumber: 17
                                            }, this),
                                            "Download"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 99,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-muted-foreground",
                                children: angle.prompt
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, this)
                ]
            }, angle.title, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 80,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 78,
        columnNumber: 5
    }, this);
}
function EngineResults({ engineKey, activeModel }) {
    const images = activeModel.imageResults[engineKey];
    if (!images) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AngleGrid, {
        images: images,
        prompts: activeModel.prompts,
        seed: activeModel.seed,
        enginePrefix: engineKey
    }, void 0, false, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 127,
        columnNumber: 5
    }, this);
}
function ActiveModelDisplay({ activeModel, isGenerating, onBulkDownload }) {
    const engineKeys = activeModel ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getActiveEngineKeys"])(activeModel.imageResults) : [];
    const dualEngine = activeModel ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hasMultipleEngines"])(activeModel.imageResults) : false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold tracking-tight",
                                children: "Active Model"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 148,
                                columnNumber: 11
                            }, this),
                            activeModel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-muted-foreground",
                                children: [
                                    "Generation Seed: ",
                                    activeModel.seed,
                                    engineKeys.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-2",
                                        children: [
                                            "· Engines:",
                                            " ",
                                            engineKeys.map((k)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][k]).join(", ")
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 153,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 150,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this),
                    activeModel && !isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onBulkDownload,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                className: "mr-2"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 163,
                                columnNumber: 13
                            }, this),
                            "Bulk Download"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 162,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 146,
                columnNumber: 7
            }, this),
            isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-10 flex flex-col items-center justify-center border-2 border-dashed rounded-lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                        className: "w-16 h-16 animate-spin text-primary mb-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xl font-semibold text-primary",
                        children: "Synthesizing Realistic Angles..."
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 172,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-muted-foreground",
                        children: "Please wait a moment."
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 175,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 170,
                columnNumber: 9
            }, this),
            !isGenerating && !activeModel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-10 border-2 border-dashed rounded-lg",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg text-muted-foreground",
                    children: "Generate a model to see the results here."
                }, void 0, false, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 181,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 180,
                columnNumber: 9
            }, this),
            activeModel && !isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "animate-in fade-in duration-500",
                children: dualEngine ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Tabs"], {
                    defaultValue: engineKeys[0],
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsList"], {
                            className: "mb-6",
                            children: engineKeys.map((key)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                    value: key,
                                    children: [
                                        "Engine: ",
                                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][key]
                                    ]
                                }, key, true, {
                                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                    lineNumber: 193,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 191,
                            columnNumber: 15
                        }, this),
                        engineKeys.map((key)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TabsContent"], {
                                value: key,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(EngineResults, {
                                    engineKey: key,
                                    activeModel: activeModel
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                    lineNumber: 200,
                                    columnNumber: 19
                                }, this)
                            }, key, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 199,
                                columnNumber: 17
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 190,
                    columnNumber: 13
                }, this) : engineKeys[0] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(EngineResults, {
                    engineKey: engineKeys[0],
                    activeModel: activeModel
                }, void 0, false, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 206,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 188,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 145,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/ui/input.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, type, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/input.tsx",
        lineNumber: 8,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
Input.displayName = "Input";
;
}),
"[project]/src/contexts/ConfigurationTrackerContext.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CONFIGS_UPDATED_EVENT",
    ()=>CONFIGS_UPDATED_EVENT,
    "ConfigurationTrackerProvider",
    ()=>ConfigurationTrackerProvider,
    "useConfigurationTracker",
    ()=>useConfigurationTracker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const STORAGE_KEY = "kotoor_saved_configs";
const CONFIGS_UPDATED_EVENT = "kotoor-configs-updated";
const ConfigurationTrackerContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(null);
function loadConfigsFromStorage() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (!stored) return [];
        const parsed = JSON.parse(stored);
        return parsed.map(normalizeModelConfig);
    } catch  {
        return [];
    }
}
function persistConfigs(configs) {
    const normalized = configs.map(normalizeModelConfig);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    window.dispatchEvent(new CustomEvent(CONFIGS_UPDATED_EVENT));
}
function ConfigurationTrackerProvider({ children }) {
    const [savedConfigs, setSavedConfigs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isHydrated, setIsHydrated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const reloadFromStorage = ()=>{
            setSavedConfigs(loadConfigsFromStorage());
        };
        const initial = loadConfigsFromStorage();
        setSavedConfigs(initial);
        setIsHydrated(true);
        // One-time migration: rewrite legacy label-based keys to canonical schema values
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                const normalized = JSON.parse(raw).map(normalizeModelConfig);
                if (JSON.stringify(normalized) !== raw) {
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
                }
            }
        } catch  {
        // ignore migration errors
        }
        window.addEventListener(CONFIGS_UPDATED_EVENT, reloadFromStorage);
        return ()=>window.removeEventListener(CONFIGS_UPDATED_EVENT, reloadFromStorage);
    }, []);
    const generateConfigHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((config)=>{
        return [
            config.gender,
            config.ageGroup,
            config.regionEthnicity,
            config.subGroup,
            config.skinTone,
            config.bodyType,
            config.hairStyle,
            config.hairColor,
            config.facialHair ?? ""
        ].join("|");
    }, []);
    const verifyUniqueConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((newConfig)=>{
        const newHash = generateConfigHash(newConfig);
        return !savedConfigs.some((existing)=>generateConfigHash(existing) === newHash);
    }, [
        generateConfigHash,
        savedConfigs
    ]);
    const finalizeAndApproveConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((name, traits)=>{
        if (!traits.subGroup?.trim()) {
            throw new Error("Sub-group required: select a specific demographic profile before approval.");
        }
        if (!verifyUniqueConfig(traits)) {
            throw new Error("Duplicate Configuration Detected: A model profile with these exact traits already exists in your library.");
        }
        const approvedModel = {
            ...traits,
            id: `cfg_${crypto.randomUUID()}`,
            name: name.trim() || `Model Profile - ${new Date().toLocaleDateString()}`,
            approvalStatus: "Approved & Locked",
            createdAt: Date.now()
        };
        const updatedList = [
            ...savedConfigs,
            approvedModel
        ];
        setSavedConfigs(updatedList);
        persistConfigs(updatedList);
        return approvedModel;
    }, [
        savedConfigs,
        verifyUniqueConfig
    ]);
    const bulkImportLegacyConfigs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((entries)=>{
        let imported = 0;
        let skipped = 0;
        const errors = [];
        const nextList = [
            ...savedConfigs
        ];
        const hashes = new Set(nextList.map((c)=>generateConfigHash(c)));
        for (const { name, traits } of entries){
            if (!traits.subGroup?.trim()) {
                errors.push(`${name}: sub-group is required.`);
                continue;
            }
            const hash = generateConfigHash(traits);
            if (hashes.has(hash)) {
                skipped += 1;
                continue;
            }
            nextList.push({
                ...traits,
                id: `cfg_${crypto.randomUUID()}`,
                name: name.trim() || `Model Profile - ${new Date().toLocaleDateString()}`,
                approvalStatus: "Approved & Locked",
                createdAt: Date.now()
            });
            hashes.add(hash);
            imported += 1;
        }
        if (imported > 0) {
            setSavedConfigs(nextList);
            persistConfigs(nextList);
        }
        return {
            imported,
            skipped,
            errors
        };
    }, [
        generateConfigHash,
        savedConfigs
    ]);
    const importLegacyFromJson = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((jsonString)=>{
        const parsed = parseLegacyConfigJson(jsonString);
        return bulkImportLegacyConfigs(parsed);
    }, [
        bulkImportLegacyConfigs
    ]);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>({
            savedConfigs,
            isHydrated,
            verifyUniqueConfig,
            finalizeAndApproveConfig,
            bulkImportLegacyConfigs,
            importLegacyFromJson
        }), [
        savedConfigs,
        isHydrated,
        verifyUniqueConfig,
        finalizeAndApproveConfig,
        bulkImportLegacyConfigs,
        importLegacyFromJson
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ConfigurationTrackerContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/contexts/ConfigurationTrackerContext.tsx",
        lineNumber: 224,
        columnNumber: 5
    }, this);
}
function useConfigurationTracker() {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(ConfigurationTrackerContext);
    if (!context) {
        throw new Error("useConfigurationTracker must be used within ConfigurationTrackerProvider");
    }
    return context;
}
}),
"[project]/src/hooks/useConfigurationTracker.ts [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CONFIGS_UPDATED_EVENT",
    ()=>CONFIGS_UPDATED_EVENT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ConfigurationTrackerContext.tsx [app-ssr] (ecmascript)");
"use client";
const STORAGE_KEY = "kotoor_saved_configs";
const CONFIGS_UPDATED_EVENT = "kotoor-configs-updated";
;
}),
"[project]/src/components/ModelLibraryManager.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ModelLibraryManager",
    ()=>ModelLibraryManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/hooks/useConfigurationTracker.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ConfigurationTrackerContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function ModelLibraryManager({ currentFormTraits }) {
    const { savedConfigs, isHydrated, finalizeAndApproveConfig } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useConfigurationTracker"])();
    const [profileName, setProfileName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [errorNotification, setErrorNotification] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [successMessage, setSuccessMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleFormalApproval = (e)=>{
        e.preventDefault();
        setErrorNotification(null);
        setSuccessMessage(null);
        try {
            finalizeAndApproveConfig(profileName, currentFormTraits);
            setProfileName("");
            setSuccessMessage("Configuration approved and locked to your library.");
        } catch (err) {
            setErrorNotification(err instanceof Error ? err.message : "Approval failed.");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6 rounded-xl border bg-card p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-b pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-semibold text-foreground",
                        children: "Model Configuration Tracker"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-muted-foreground",
                        children: "Name and finalize current traits to approve for production"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 50,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleFormalApproval,
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "profile-name",
                                className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
                                children: "Unique Profile Identity Name"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                lineNumber: 57,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                id: "profile-name",
                                type: "text",
                                value: profileName,
                                onChange: (e)=>setProfileName(e.target.value),
                                placeholder: "e.g., Autumn Collection Elite Male - South Asian",
                                required: true
                            }, void 0, false, {
                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this),
                    errorNotification && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "rounded bg-destructive/10 p-2 text-xs font-medium text-destructive",
                        children: errorNotification
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 74,
                        columnNumber: 11
                    }, this),
                    successMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "rounded bg-emerald-500/10 p-2 text-xs font-medium text-emerald-600 dark:text-emerald-400",
                        children: successMessage
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 80,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                        type: "submit",
                        className: "w-full text-xs font-semibold",
                        children: "Verify & Issue Formal Approval"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: "mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground",
                        children: [
                            "Approved Model Library (",
                            isHydrated ? savedConfigs.length : "…",
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-h-[300px] space-y-2 overflow-y-auto pr-1",
                        children: !isHydrated ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-muted-foreground",
                            children: "Loading library…"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModelLibraryManager.tsx",
                            lineNumber: 96,
                            columnNumber: 13
                        }, this) : savedConfigs.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-muted-foreground",
                            children: "No approved configurations yet."
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModelLibraryManager.tsx",
                            lineNumber: 98,
                            columnNumber: 13
                        }, this) : savedConfigs.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between rounded-lg border bg-background p-3 text-xs",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-semibold text-foreground",
                                                children: item.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                                lineNumber: 108,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-0.5 text-muted-foreground",
                                                children: [
                                                    item.gender,
                                                    " • ",
                                                    item.ageGroup,
                                                    " •",
                                                    " ",
                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRegionLabel"])(item.regionEthnicity),
                                                    " • ",
                                                    item.subGroup
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                                lineNumber: 109,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                        lineNumber: 107,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "rounded-full bg-emerald-500/10 px-2 py-1 text-[10px] font-medium text-emerald-600 dark:text-emerald-400",
                                        children: item.approvalStatus
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                        lineNumber: 114,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, item.id, true, {
                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                lineNumber: 103,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ModelLibraryManager.tsx",
        lineNumber: 45,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/lib/config-schema.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ALL_REGIONS_COVERAGE_KEY",
    ()=>ALL_REGIONS_COVERAGE_KEY,
    "configCoversIntersection",
    ()=>configCoversIntersection,
    "countLibraryProfilesForView",
    ()=>countLibraryProfilesForView,
    "getBatchDisplayName",
    ()=>getBatchDisplayName,
    "getCoverageSubGroupRows",
    ()=>getCoverageSubGroupRows,
    "getRecordString",
    ()=>getRecordString,
    "normalizeConfigurationTraits",
    ()=>normalizeConfigurationTraits,
    "normalizeModelConfig",
    ()=>normalizeModelConfig,
    "parseBatchPromptInput",
    ()=>parseBatchPromptInput,
    "parseLegacyConfigJson",
    ()=>parseLegacyConfigJson,
    "parseLegacyConfigRecord",
    ()=>parseLegacyConfigRecord,
    "resolveAgeGroup",
    ()=>resolveAgeGroup,
    "resolveBodyType",
    ()=>resolveBodyType,
    "resolveFacialHair",
    ()=>resolveFacialHair,
    "resolveGender",
    ()=>resolveGender,
    "resolveHairColor",
    ()=>resolveHairColor,
    "resolveHairStyle",
    ()=>resolveHairStyle,
    "resolveRegionEthnicity",
    ()=>resolveRegionEthnicity,
    "resolveSkinTone",
    ()=>resolveSkinTone,
    "resolveSubGroup",
    ()=>resolveSubGroup,
    "toConfigurationTraitsFromRecord",
    ()=>toConfigurationTraitsFromRecord
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
;
const ALL_REGIONS_COVERAGE_KEY = "__all_regions__";
function getCoverageSubGroupRows(regionFilter) {
    if (regionFilter === ALL_REGIONS_COVERAGE_KEY) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["regionEthnicityOptions"].flatMap((region)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getSubGroupsForRegion"])(region.value).map((sub)=>({
                    id: `${region.value}::${sub.value}`,
                    regionKey: region.value,
                    subGroupValue: sub.value,
                    label: `${region.label} · ${sub.label}`
                })));
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getSubGroupsForRegion"])(regionFilter).map((sub)=>({
            id: sub.value,
            regionKey: regionFilter,
            subGroupValue: sub.value,
            label: sub.label
        }));
}
function getRecordString(record, ...keys) {
    for (const key of keys){
        const val = record[key];
        if (typeof val === "string" && val.trim()) return val.trim();
    }
    return "";
}
function normalize(input) {
    return input.trim().toLowerCase();
}
function resolveFromLabelValueOptions(input, options) {
    if (!input) return "";
    const norm = normalize(input);
    const byValue = options.find((o)=>normalize(o.value) === norm);
    if (byValue) return byValue.value;
    const byLabel = options.find((o)=>normalize(o.label) === norm);
    if (byLabel) return byLabel.value;
    const partial = options.find((o)=>normalize(o.label).includes(norm) || norm.includes(normalize(o.label)));
    return partial?.value ?? input;
}
function resolveFromStringList(input, options) {
    if (!input) return "";
    const norm = normalize(input);
    const exact = options.find((o)=>normalize(o) === norm);
    if (exact) return exact;
    const partial = options.find((o)=>normalize(o).includes(norm) || norm.includes(normalize(o)));
    return partial ?? input;
}
function resolveRegionEthnicity(input) {
    return resolveFromLabelValueOptions(input, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["regionEthnicityOptions"]);
}
function resolveSubGroup(input, regionKey) {
    if (!input) return "";
    const regions = regionKey ? [
        regionKey
    ] : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["regionEthnicityOptions"].map((r)=>r.value);
    for (const rk of regions){
        const resolved = resolveFromLabelValueOptions(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getSubGroupsForRegion"])(rk));
        const subGroups = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getSubGroupsForRegion"])(rk);
        if (subGroups.some((s)=>s.value === resolved)) {
            return resolved;
        }
    }
    return input;
}
function resolveSkinTone(input) {
    return resolveFromLabelValueOptions(input, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["skinToneOptions"]);
}
function resolveHairColor(input) {
    return resolveFromLabelValueOptions(input, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hairColorOptions"]);
}
function resolveFacialHair(input) {
    return resolveFromLabelValueOptions(input, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MALE_FACIAL_HAIR"]);
}
function resolveGender(input) {
    return resolveFromStringList(input, [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GENDERS"]
    ]);
}
function resolveAgeGroup(input) {
    return resolveFromStringList(input, [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AGE_GROUPS"]
    ]);
}
function resolveBodyType(input, gender) {
    return resolveFromStringList(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBodyTypes"])(gender));
}
function resolveHairStyle(input, gender) {
    return resolveFromLabelValueOptions(input, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getHairStyles"])(gender));
}
function parseLegacyConfigRecord(raw, index = 0) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
        throw new Error(`Invalid entry at index ${index}. Each item must be a JSON object.`);
    }
    const record = raw;
    const gender = resolveGender(getRecordString(record, "gender", "Gender"));
    if (!gender) {
        throw new Error(`Entry ${index}: Gender is required.`);
    }
    const regionRaw = getRecordString(record, "regionEthnicity", "Region / Ethnicity", "Region/Ethnicity");
    const regionEthnicity = resolveRegionEthnicity(regionRaw);
    const subGroupRaw = getRecordString(record, "subGroup", "Specific Demographic Sub-Group", "Sub-Group");
    const subGroup = resolveSubGroup(subGroupRaw, regionEthnicity);
    const ageGroup = resolveAgeGroup(getRecordString(record, "ageGroup", "Age Group"));
    const skinTone = resolveSkinTone(getRecordString(record, "skinTone", "Skin Tone"));
    const bodyType = resolveBodyType(getRecordString(record, "bodyType", "Body Type"), gender);
    const hairStyle = resolveHairStyle(getRecordString(record, "hairStyle", "Hair Style"), gender);
    const hairColor = resolveHairColor(getRecordString(record, "hairColor", "Hair Color"));
    const traits = {
        gender,
        ageGroup,
        regionEthnicity,
        subGroup,
        skinTone,
        bodyType,
        hairStyle,
        hairColor
    };
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isMaleGender"])(gender)) {
        const facialHair = resolveFacialHair(getRecordString(record, "facialHair", "Facial Hair"));
        if (facialHair) traits.facialHair = facialHair;
    }
    const name = getRecordString(record, "Model Name", "name", "modelName") || `Legacy Import ${index + 1}`;
    return {
        name,
        traits
    };
}
function parseLegacyConfigJson(jsonString) {
    let parsed;
    try {
        parsed = JSON.parse(jsonString);
    } catch  {
        throw new Error("Invalid JSON structure. Please check your formatting.");
    }
    const items = Array.isArray(parsed) ? parsed : [
        parsed
    ];
    if (items.length === 0) {
        throw new Error("JSON array is empty. Add at least one model config.");
    }
    return items.map((item, index)=>parseLegacyConfigRecord(item, index));
}
function normalizeDashes(input) {
    return input.replace(/-/g, "–");
}
function normalizeConfigurationTraits(traits) {
    const gender = resolveGender(traits.gender);
    const regionEthnicity = resolveRegionEthnicity(traits.regionEthnicity);
    const subGroup = resolveSubGroup(traits.subGroup, regionEthnicity);
    const ageGroup = resolveAgeGroup(normalizeDashes(traits.ageGroup));
    const normalized = {
        gender,
        ageGroup,
        regionEthnicity,
        subGroup,
        skinTone: resolveSkinTone(traits.skinTone),
        bodyType: resolveBodyType(traits.bodyType, gender),
        hairStyle: resolveHairStyle(traits.hairStyle, gender),
        hairColor: resolveHairColor(traits.hairColor)
    };
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isMaleGender"])(gender) && traits.facialHair) {
        normalized.facialHair = resolveFacialHair(traits.facialHair);
    }
    return normalized;
}
function normalizeModelConfig(config) {
    return {
        ...config,
        ...normalizeConfigurationTraits(config)
    };
}
function configCoversIntersection(configs, intersection) {
    const target = {
        gender: resolveGender(intersection.gender),
        regionKey: resolveRegionEthnicity(intersection.regionKey),
        subGroupValue: resolveSubGroup(intersection.subGroupValue, resolveRegionEthnicity(intersection.regionKey)),
        ageGroup: resolveAgeGroup(normalizeDashes(intersection.ageGroup))
    };
    return configs.some((config)=>{
        const normalized = normalizeConfigurationTraits(config);
        return normalized.gender === target.gender && normalized.regionEthnicity === target.regionKey && normalized.subGroup === target.subGroupValue && normalized.ageGroup === target.ageGroup;
    });
}
function countLibraryProfilesForView(configs, filters) {
    const gender = resolveGender(filters.gender);
    const regionFilter = filters.regionFilter;
    return configs.filter((config)=>{
        const normalized = normalizeConfigurationTraits(config);
        if (normalized.gender !== gender) return false;
        if (regionFilter !== ALL_REGIONS_COVERAGE_KEY && normalized.regionEthnicity !== resolveRegionEthnicity(regionFilter)) {
            return false;
        }
        return true;
    }).length;
}
function parseBatchPromptInput(config) {
    const gender = resolveGender(getRecordString(config, "gender", "Gender"));
    const regionRaw = getRecordString(config, "regionEthnicity", "Region / Ethnicity", "Region/Ethnicity");
    const regionEthnicity = resolveRegionEthnicity(regionRaw);
    const input = {
        gender,
        ageGroup: resolveAgeGroup(getRecordString(config, "ageGroup", "Age Group")),
        regionEthnicity,
        subGroup: resolveSubGroup(getRecordString(config, "subGroup", "Specific Demographic Sub-Group", "Sub-Group"), regionEthnicity),
        skinTone: resolveSkinTone(getRecordString(config, "skinTone", "Skin Tone")),
        hairStyle: resolveHairStyle(getRecordString(config, "hairStyle", "Hair Style"), gender),
        hairColor: resolveHairColor(getRecordString(config, "hairColor", "Hair Color")),
        bodyType: resolveBodyType(getRecordString(config, "bodyType", "Body Type"), gender),
        marketingArchetype: getRecordString(config, "marketingArchetype", "Marketing Archetype")
    };
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isMaleGender"])(gender)) {
        const facialHair = resolveFacialHair(getRecordString(config, "facialHair", "Facial Hair"));
        if (facialHair) input.facialHair = facialHair;
    }
    return input;
}
function toConfigurationTraitsFromRecord(config) {
    const parsed = parseLegacyConfigRecord(config);
    return parsed.traits;
}
function getBatchDisplayName(config, fallback) {
    return getRecordString(config, "Model Name", "name", "modelName") || fallback;
}
}),
"[project]/src/components/CoverageMatrix.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CoverageMatrix",
    ()=>CoverageMatrix
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/select.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/hooks/useConfigurationTracker.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ConfigurationTrackerContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/config-schema.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-ssr] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
"use client";
;
;
;
;
;
;
;
;
function CoverageMatrix() {
    const { savedConfigs, isHydrated } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useConfigurationTracker"])();
    const [selectedRegion, setSelectedRegion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["regionEthnicityOptions"][0].value);
    const [selectedGender, setSelectedGender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GENDERS"][0]);
    const matrixData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const rows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getCoverageSubGroupRows"])(selectedRegion);
        let covered = 0;
        const total = rows.length * __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AGE_GROUPS"].length;
        const matrix = {};
        rows.forEach((row)=>{
            matrix[row.id] = {};
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AGE_GROUPS"].forEach((age)=>{
                const exists = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["configCoversIntersection"])(savedConfigs, {
                    gender: selectedGender,
                    regionKey: row.regionKey,
                    subGroupValue: row.subGroupValue,
                    ageGroup: age
                });
                matrix[row.id][age] = exists;
                if (exists) covered += 1;
            });
        });
        return {
            rows,
            matrix,
            covered,
            total
        };
    }, [
        savedConfigs,
        selectedRegion,
        selectedGender
    ]);
    const coveragePct = matrixData.total > 0 ? Math.round(matrixData.covered / matrixData.total * 100) : 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mt-6 space-y-6 rounded-xl border bg-card p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold",
                        children: "Demographic Coverage Matrix"
                    }, void 0, false, {
                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-muted-foreground",
                        children: "Read-only heatmap of approved library coverage by sub-group and age group. All axes are sourced from sidebar form constants."
                    }, void 0, false, {
                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this),
                    isHydrated && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1 text-xs font-medium text-muted-foreground",
                        children: [
                            matrixData.covered,
                            "/",
                            matrixData.total,
                            " intersections covered (",
                            coveragePct,
                            "%)"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                        lineNumber: 70,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/CoverageMatrix.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-4 sm:flex-row",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2 sm:flex-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                className: "text-xs uppercase tracking-wider text-muted-foreground",
                                children: "Region"
                            }, void 0, false, {
                                fileName: "[project]/src/components/CoverageMatrix.tsx",
                                lineNumber: 79,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: selectedRegion,
                                onValueChange: setSelectedRegion,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select region"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/CoverageMatrix.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                                        lineNumber: 83,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ALL_REGIONS_COVERAGE_KEY"],
                                                children: "All Subcategories"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/CoverageMatrix.tsx",
                                                lineNumber: 87,
                                                columnNumber: 15
                                            }, this),
                                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["regionEthnicityOptions"].map((region)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                    value: region.value,
                                                    children: region.label
                                                }, region.value, false, {
                                                    fileName: "[project]/src/components/CoverageMatrix.tsx",
                                                    lineNumber: 91,
                                                    columnNumber: 17
                                                }, this))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                                        lineNumber: 86,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/CoverageMatrix.tsx",
                                lineNumber: 82,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2 sm:flex-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                className: "text-xs uppercase tracking-wider text-muted-foreground",
                                children: "Gender"
                            }, void 0, false, {
                                fileName: "[project]/src/components/CoverageMatrix.tsx",
                                lineNumber: 100,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Select"], {
                                value: selectedGender,
                                onValueChange: setSelectedGender,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select gender"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/CoverageMatrix.tsx",
                                            lineNumber: 105,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                                        lineNumber: 104,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["GENDERS"].map((gender)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: gender,
                                                children: gender
                                            }, gender, false, {
                                                fileName: "[project]/src/components/CoverageMatrix.tsx",
                                                lineNumber: 109,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                                        lineNumber: 107,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/CoverageMatrix.tsx",
                                lineNumber: 103,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                        lineNumber: 99,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/CoverageMatrix.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            !isHydrated ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-muted-foreground",
                children: "Loading library data…"
            }, void 0, false, {
                fileName: "[project]/src/components/CoverageMatrix.tsx",
                lineNumber: 119,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: "w-full text-left text-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                className: "border-b",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "min-w-[180px] p-2 font-semibold",
                                        children: "Sub-Group"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                                        lineNumber: 125,
                                        columnNumber: 17
                                    }, this),
                                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AGE_GROUPS"].map((age)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "max-w-[100px] truncate p-2 text-center text-xs font-semibold",
                                            title: age,
                                            children: age.split(" ")[0]
                                        }, age, false, {
                                            fileName: "[project]/src/components/CoverageMatrix.tsx",
                                            lineNumber: 129,
                                            columnNumber: 19
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/CoverageMatrix.tsx",
                                lineNumber: 124,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/CoverageMatrix.tsx",
                            lineNumber: 123,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: matrixData.rows.map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: "border-b last:border-0 hover:bg-muted/50",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: "p-2 text-xs font-medium",
                                            children: row.label
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/CoverageMatrix.tsx",
                                            lineNumber: 145,
                                            columnNumber: 19
                                        }, this),
                                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AGE_GROUPS"].map((age)=>{
                                            const covered = matrixData.matrix[row.id]?.[age];
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "p-2 text-center align-middle",
                                                children: covered ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "inline-flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
                                                    title: "Covered",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                        className: "h-3.5 w-3.5"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                                                        lineNumber: 155,
                                                        columnNumber: 29
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/CoverageMatrix.tsx",
                                                    lineNumber: 151,
                                                    columnNumber: 27
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "inline-flex h-6 w-6 items-center justify-center rounded-full bg-destructive/10 text-destructive",
                                                    title: "Missing",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                        className: "h-3.5 w-3.5"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/CoverageMatrix.tsx",
                                                        lineNumber: 162,
                                                        columnNumber: 29
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/CoverageMatrix.tsx",
                                                    lineNumber: 158,
                                                    columnNumber: 27
                                                }, this)
                                            }, age, false, {
                                                fileName: "[project]/src/components/CoverageMatrix.tsx",
                                                lineNumber: 149,
                                                columnNumber: 23
                                            }, this);
                                        })
                                    ]
                                }, row.id, true, {
                                    fileName: "[project]/src/components/CoverageMatrix.tsx",
                                    lineNumber: 141,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/CoverageMatrix.tsx",
                            lineNumber: 139,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/CoverageMatrix.tsx",
                    lineNumber: 122,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/CoverageMatrix.tsx",
                lineNumber: 121,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/CoverageMatrix.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/ui/alert-dialog.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AlertDialog",
    ()=>AlertDialog,
    "AlertDialogAction",
    ()=>AlertDialogAction,
    "AlertDialogCancel",
    ()=>AlertDialogCancel,
    "AlertDialogContent",
    ()=>AlertDialogContent,
    "AlertDialogDescription",
    ()=>AlertDialogDescription,
    "AlertDialogFooter",
    ()=>AlertDialogFooter,
    "AlertDialogHeader",
    ()=>AlertDialogHeader,
    "AlertDialogOverlay",
    ()=>AlertDialogOverlay,
    "AlertDialogPortal",
    ()=>AlertDialogPortal,
    "AlertDialogTitle",
    ()=>AlertDialogTitle,
    "AlertDialogTrigger",
    ()=>AlertDialogTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-alert-dialog/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const AlertDialog = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"];
const AlertDialogTrigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Trigger"];
const AlertDialogPortal = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"];
const AlertDialogOverlay = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Overlay"], {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
        ...props,
        ref: ref
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.tsx",
        lineNumber: 19,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
AlertDialogOverlay.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Overlay"].displayName;
const AlertDialogContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AlertDialogPortal, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AlertDialogOverlay, {}, void 0, false, {
                fileName: "[project]/src/components/ui/alert-dialog.tsx",
                lineNumber: 35,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
                ref: ref,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg", className),
                ...props
            }, void 0, false, {
                fileName: "[project]/src/components/ui/alert-dialog.tsx",
                lineNumber: 36,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/alert-dialog.tsx",
        lineNumber: 34,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
AlertDialogContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"].displayName;
const AlertDialogHeader = ({ className, ...props })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-2 text-center sm:text-left", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.tsx",
        lineNumber: 52,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
AlertDialogHeader.displayName = "AlertDialogHeader";
const AlertDialogFooter = ({ className, ...props })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.tsx",
        lineNumber: 66,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
AlertDialogFooter.displayName = "AlertDialogFooter";
const AlertDialogTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-lg font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.tsx",
        lineNumber: 80,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
AlertDialogTitle.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"].displayName;
const AlertDialogDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.tsx",
        lineNumber: 92,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
AlertDialogDescription.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"].displayName;
const AlertDialogAction = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Action"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buttonVariants"])(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.tsx",
        lineNumber: 105,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
AlertDialogAction.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Action"].displayName;
const AlertDialogCancel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"](({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cancel"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buttonVariants"])({
            variant: "outline"
        }), "mt-2 sm:mt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/alert-dialog.tsx",
        lineNumber: 117,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
AlertDialogCancel.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$alert$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cancel"].displayName;
;
}),
"[project]/src/components/LegacyModelImporter.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LegacyModelImporter",
    ()=>LegacyModelImporter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/textarea.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/alert-dialog.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/hooks/useConfigurationTracker.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ConfigurationTrackerContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function LegacyModelImporter({ currentFormTraits }) {
    const { finalizeAndApproveConfig, importLegacyFromJson } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useConfigurationTracker"])();
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    const [manualName, setManualName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [confirmOpen, setConfirmOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [jsonInput, setJsonInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [importError, setImportError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleForceAdd = ()=>{
        try {
            finalizeAndApproveConfig(manualName, currentFormTraits);
            setManualName("");
            setConfirmOpen(false);
            toast({
                title: "Legacy model added",
                description: "Current sidebar traits were locked into the approval library without generating new images."
            });
        } catch (err) {
            toast({
                variant: "destructive",
                title: "Could not add model",
                description: err instanceof Error ? err.message : "Import failed."
            });
        }
    };
    const handleBulkImport = ()=>{
        setImportError(null);
        try {
            const result = importLegacyFromJson(jsonInput);
            setJsonInput("");
            const parts = [
                `${result.imported} imported`,
                `${result.skipped} skipped`
            ];
            if (result.errors.length > 0) {
                parts.push(`${result.errors.length} invalid`);
            }
            toast({
                title: "Bulk import complete",
                description: parts.join(" · ")
            });
            if (result.errors.length > 0) {
                setImportError(result.errors.slice(0, 5).join("\n"));
            }
        } catch (err) {
            setImportError(err instanceof Error ? err.message : "Import failed.");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-8 rounded-xl border bg-card p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold",
                        children: "Legacy Model Importer"
                    }, void 0, false, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-muted-foreground",
                        children: "Register already-generated models into the approval library and coverage matrix without triggering new API generations."
                    }, void 0, false, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "space-y-4 rounded-lg border p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "text-sm font-semibold",
                                children: "Manual Override"
                            }, void 0, false, {
                                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-muted-foreground",
                                children: "Lock the current sidebar traits into the library. No images will be generated."
                            }, void 0, false, {
                                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                lineNumber: 95,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 93,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-md bg-muted/50 p-3 text-xs text-muted-foreground",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: [
                                currentFormTraits.gender,
                                " · ",
                                currentFormTraits.ageGroup,
                                " ·",
                                " ",
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRegionLabel"])(currentFormTraits.regionEthnicity),
                                " ·",
                                " ",
                                currentFormTraits.subGroup
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/LegacyModelImporter.tsx",
                            lineNumber: 102,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "legacy-manual-name",
                                children: "Model Name"
                            }, void 0, false, {
                                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                lineNumber: 110,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                                id: "legacy-manual-name",
                                value: manualName,
                                onChange: (e)=>setManualName(e.target.value),
                                placeholder: "e.g., Legacy Archive - East Asian Teen Female"
                            }, void 0, false, {
                                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                lineNumber: 111,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 109,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                        type: "button",
                        variant: "secondary",
                        className: "w-full",
                        disabled: !manualName.trim(),
                        onClick: ()=>setConfirmOpen(true),
                        children: "Force Add Current"
                    }, void 0, false, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 119,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                lineNumber: 92,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "space-y-4 rounded-lg border p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "text-sm font-semibold",
                                children: "Bulk JSON Import"
                            }, void 0, false, {
                                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                lineNumber: 132,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-muted-foreground",
                                children: "Paste an array of model configurations. Keys are mapped to the sidebar schema; duplicates are skipped automatically."
                            }, void 0, false, {
                                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Textarea"], {
                        value: jsonInput,
                        onChange: (e)=>setJsonInput(e.target.value),
                        className: "min-h-32 font-mono text-xs",
                        placeholder: `[\n  {\n    "Model Name": "Archive Model A",\n    "Gender": "Female / Woman",\n    "Age Group": "Young Adult (20–29 years)",\n    "regionEthnicity": "east_asian",\n    "subGroup": "japanese phenotype",\n    "Skin Tone": "Type 2: Light or fair",\n    "Body Type": "Average / Straight",\n    "Hair Style": "Straight with Blunt Bangs",\n    "Hair Color": "Jet Black"\n  }\n]`
                    }, void 0, false, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 139,
                        columnNumber: 9
                    }, this),
                    importError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "whitespace-pre-wrap rounded bg-destructive/10 p-2 text-xs text-destructive",
                        children: importError
                    }, void 0, false, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 147,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                        type: "button",
                        className: "w-full",
                        disabled: !jsonInput.trim(),
                        onClick: handleBulkImport,
                        children: "Import to Matrix"
                    }, void 0, false, {
                        fileName: "[project]/src/components/LegacyModelImporter.tsx",
                        lineNumber: 152,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                lineNumber: 130,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialog"], {
                open: confirmOpen,
                onOpenChange: setConfirmOpen,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogContent"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogHeader"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogTitle"], {
                                    children: "Force add without generation?"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                    lineNumber: 165,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogDescription"], {
                                    children: "You are about to lock the current sidebar traits into the Approval Library without generating new images. This entry will immediately appear in the approval list and coverage matrix. Continue?"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                    lineNumber: 166,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/LegacyModelImporter.tsx",
                            lineNumber: 164,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogFooter"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogCancel"], {
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                    lineNumber: 173,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$alert$2d$dialog$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AlertDialogAction"], {
                                    onClick: handleForceAdd,
                                    children: "Confirm & Lock"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/LegacyModelImporter.tsx",
                                    lineNumber: 174,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/LegacyModelImporter.tsx",
                            lineNumber: 172,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/LegacyModelImporter.tsx",
                    lineNumber: 163,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/LegacyModelImporter.tsx",
                lineNumber: 162,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/LegacyModelImporter.tsx",
        lineNumber: 83,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/BatchProcessorQueue.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BatchProcessorQueue",
    ()=>BatchProcessorQueue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-ssr] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/config-schema.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/download-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
function getBatchSummary(config) {
    const gender = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRecordString"])(config, "gender", "Gender") || "—";
    const ageGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getRecordString"])(config, "ageGroup", "Age Group") || "—";
    return `${gender} • ${ageGroup}`;
}
function BatchAngleGrid({ images, prompts, seed, onBulkDownload }) {
    const angles = [
        {
            title: "Straight (3/4 Body)",
            url: images.straight,
            prompt: prompts.straightPrompt,
            alt: "Straight 3/4 body portrait",
            file: `straight_${seed}.png`
        },
        {
            title: "Left Profile (3/4 Body)",
            url: images.left,
            prompt: prompts.leftPrompt,
            alt: "Left profile 3/4 body portrait",
            file: `left_${seed}.png`
        },
        {
            title: "Right Profile (3/4 Body)",
            url: images.right,
            prompt: prompts.rightPrompt,
            alt: "Right profile 3/4 body portrait",
            file: `right_${seed}.png`
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "default",
                    size: "sm",
                    onClick: onBulkDownload,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                            className: "mr-2 h-4 w-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, this),
                        "Bulk Download"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                    lineNumber: 76,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 gap-6 md:grid-cols-3",
                children: angles.map((angle)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                                    className: "text-base",
                                    children: angle.title
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                    lineNumber: 85,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 84,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                                className: "flex-grow",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative mx-auto aspect-[3/4] w-full max-h-[50vh] overflow-hidden rounded-md",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        src: angle.url,
                                        alt: angle.alt,
                                        fill: true,
                                        className: "object-cover",
                                        sizes: "(max-width: 768px) 100vw, 33vw",
                                        unoptimized: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 89,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                    lineNumber: 88,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 87,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardFooter"], {
                                className: "flex-col items-start gap-2 pt-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex w-full items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm font-medium",
                                                children: "Prompt"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 101,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "outline",
                                                size: "sm",
                                                onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["downloadDataUri"])(angle.url, angle.file),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                        className: "mr-2 h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                        lineNumber: 107,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Download"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 102,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 100,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-muted-foreground line-clamp-4",
                                        children: angle.prompt
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 111,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 99,
                                columnNumber: 13
                            }, this)
                        ]
                    }, angle.title, true, {
                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                        lineNumber: 83,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
        lineNumber: 74,
        columnNumber: 5
    }, this);
}
function BatchProcessorQueue({ batchQueue, isProcessing, onStartBatch, onApproveItem, onRegenerateItem }) {
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    const [approvalErrors, setApprovalErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    if (batchQueue.length === 0 && !isProcessing) {
        return null;
    }
    const handleBulkDownload = async (item)=>{
        if (!item.images || !item.prompts || !item.seed) return;
        toast({
            title: "Preparing Download...",
            description: "Your model assets are being zipped."
        });
        try {
            const safeName = item.displayName.replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "_").slice(0, 40);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["downloadModelZip"])({
                seed: item.seed,
                images: item.images,
                prompts: item.prompts,
                zipFilename: safeName ? `model_${safeName}_${item.seed}.zip` : `model_${item.seed}.zip`
            });
        } catch  {
            toast({
                variant: "destructive",
                title: "Download Failed",
                description: "Could not prepare your files for download. Please try again."
            });
        }
    };
    const handleApprove = (item)=>{
        setApprovalErrors((prev)=>{
            const next = {
                ...prev
            };
            delete next[item.id];
            return next;
        });
        try {
            onApproveItem(item.id, item.displayName);
        } catch (err) {
            setApprovalErrors((prev)=>({
                    ...prev,
                    [item.id]: err instanceof Error ? err.message : "Approval failed."
                }));
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold tracking-tight",
                                children: "Batch Queue"
                            }, void 0, false, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 191,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-muted-foreground",
                                children: [
                                    batchQueue.length,
                                    " item",
                                    batchQueue.length === 1 ? "" : "s",
                                    " loaded",
                                    isProcessing ? " · Processing wave (up to 3 models, 9 images)…" : " · Runs in waves of 3 to stay within Tier 1 (10 IPM)"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 192,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                        lineNumber: 190,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onStartBatch,
                        disabled: isProcessing,
                        className: "bg-emerald-600 hover:bg-emerald-700",
                        children: isProcessing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                    className: "mr-2 h-4 w-4 animate-spin"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                    lineNumber: 206,
                                    columnNumber: 15
                                }, this),
                                "Processing…"
                            ]
                        }, void 0, true) : "Start Batch"
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                        lineNumber: 199,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                lineNumber: 189,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-8",
                children: batchQueue.map((item, index)=>{
                    const hasAssets = item.images && item.prompts && item.seed && item.status !== "Failed";
                    const canReview = item.status === "Review";
                    const isApproved = item.status === "Approved";
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Card"], {
                        className: "overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardHeader"], {
                                className: "flex flex-row items-start justify-between space-y-0 pb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardTitle"], {
                                                className: "text-lg",
                                                children: item.displayName || `Model #${index + 1}`
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 226,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-sm text-muted-foreground",
                                                children: [
                                                    getBatchSummary(item.config),
                                                    item.seed ? ` · Seed: ${item.seed}` : ""
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 229,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 225,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "rounded-full bg-secondary px-2 py-1 text-[10px] font-bold uppercase",
                                        children: item.status
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 234,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 224,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CardContent"], {
                                className: "space-y-4",
                                children: [
                                    (item.status === "Generating Prompts" || item.status === "Generating Images") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 rounded-lg border border-dashed p-6 text-muted-foreground",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                className: "h-5 w-5 animate-spin text-primary"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 243,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-sm font-medium",
                                                children: [
                                                    item.status,
                                                    "…"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 244,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 242,
                                        columnNumber: 19
                                    }, this),
                                    item.error && item.status === "Failed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "rounded bg-destructive/10 p-3 text-sm text-destructive",
                                        children: item.error
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 249,
                                        columnNumber: 19
                                    }, this),
                                    hasAssets && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(BatchAngleGrid, {
                                        images: item.images,
                                        prompts: item.prompts,
                                        seed: item.seed,
                                        onBulkDownload: ()=>void handleBulkDownload(item)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 255,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap gap-2",
                                        children: [
                                            canReview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                        size: "sm",
                                                        className: "bg-emerald-600 hover:bg-emerald-700",
                                                        onClick: ()=>handleApprove(item),
                                                        children: "Verify & Approve"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                        lineNumber: 266,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                        size: "sm",
                                                        variant: "outline",
                                                        className: "border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100",
                                                        onClick: ()=>onRegenerateItem(item.id),
                                                        children: "Regenerate"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                        lineNumber: 273,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true),
                                            isApproved && hasAssets && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                size: "sm",
                                                onClick: ()=>void handleBulkDownload(item),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                        className: "mr-2 h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                        lineNumber: 289,
                                                        columnNumber: 23
                                                    }, this),
                                                    "Bulk Download"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 285,
                                                columnNumber: 21
                                            }, this),
                                            item.status === "Failed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                                size: "sm",
                                                variant: "outline",
                                                onClick: ()=>onRegenerateItem(item.id),
                                                children: "Retry"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 295,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 263,
                                        columnNumber: 17
                                    }, this),
                                    approvalErrors[item.id] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "rounded bg-destructive/10 p-2 text-xs text-destructive",
                                        children: approvalErrors[item.id]
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 306,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 239,
                                columnNumber: 15
                            }, this)
                        ]
                    }, item.id, true, {
                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                        lineNumber: 223,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                lineNumber: 215,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
        lineNumber: 188,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/ai/flows/data:6e7891 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"400ba0d60ef0c89afda251d7a988bfb25bf1808dbf":"generateStraightImage"},"src/ai/flows/generate-model-images.ts",""] */ __turbopack_context__.s([
    "generateStraightImage",
    ()=>generateStraightImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var generateStraightImage = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("400ba0d60ef0c89afda251d7a988bfb25bf1808dbf", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateStraightImage"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9kZWwtaW1hZ2VzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcbi8qKlxuICogQGZpbGVPdmVydmlldyBTZXF1ZW50aWFsIDMtYW5nbGUgZ2VuZXJhdGlvbiB2aWEgZ2VtaW5pLTMtcHJvLWltYWdlIHdpdGggaGVyby1pbWFnZSByZWZlcmVuY2UuXG4gKi9cblxuaW1wb3J0IHsgYWkgfSBmcm9tICdAL2FpL2dlbmtpdCc7XG5cbmNvbnN0IElNQUdFX01PREVMID0gJ2dvb2dsZWFpL2dlbWluaS0zLXByby1pbWFnZSc7XG5cbi8qKiBHZW1pbmkgbmF0aXZlIGltYWdlIG1vZGVscyB1c2UgaW1hZ2VDb25maWcsIG5vdCBJbWFnZW4ncyB0b3AtbGV2ZWwgYXNwZWN0UmF0aW8uICovXG5jb25zdCBHRU1JTklfSU1BR0VfQ09ORklHID0ge1xuICByZXNwb25zZU1vZGFsaXRpZXM6IFsnVEVYVCcsICdJTUFHRSddLFxuICBpbWFnZUNvbmZpZzoge1xuICAgIGFzcGVjdFJhdGlvOiAnMzo0JyxcbiAgfSxcbn07XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc0lucHV0IHtcbiAgcHJvbXB0czoge1xuICAgIHN0cmFpZ2h0UHJvbXB0OiBzdHJpbmc7XG4gICAgbGVmdFByb21wdDogc3RyaW5nO1xuICAgIHJpZ2h0UHJvbXB0OiBzdHJpbmc7XG4gIH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc091dHB1dCB7XG4gIGltYWdlbj86IHsgc3RyYWlnaHQ6IHN0cmluZzsgbGVmdDogc3RyaW5nOyByaWdodDogc3RyaW5nIH07XG59XG5cbnR5cGUgR2VuZXJhdGVSZXN1bHQgPSBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGFpLmdlbmVyYXRlPj47XG5cbmZ1bmN0aW9uIGV4dHJhY3RJbWFnZURhdGFVcmkocmVzdWx0OiBHZW5lcmF0ZVJlc3VsdCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGlmIChyZXN1bHQubWVkaWE/LnVybCkge1xuICAgIHJldHVybiByZXN1bHQubWVkaWEudXJsO1xuICB9XG5cbiAgY29uc3QgY29udGVudCA9IHJlc3VsdC5tZXNzYWdlPy5jb250ZW50O1xuICBpZiAoQXJyYXkuaXNBcnJheShjb250ZW50KSkge1xuICAgIGZvciAoY29uc3QgcGFydCBvZiBjb250ZW50KSB7XG4gICAgICBpZiAoXG4gICAgICAgIHBhcnQgJiZcbiAgICAgICAgdHlwZW9mIHBhcnQgPT09ICdvYmplY3QnICYmXG4gICAgICAgICdtZWRpYScgaW4gcGFydCAmJlxuICAgICAgICBwYXJ0Lm1lZGlhICYmXG4gICAgICAgIHR5cGVvZiBwYXJ0Lm1lZGlhID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAndXJsJyBpbiBwYXJ0Lm1lZGlhICYmXG4gICAgICAgIHR5cGVvZiBwYXJ0Lm1lZGlhLnVybCA9PT0gJ3N0cmluZydcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gcGFydC5tZWRpYS51cmw7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKHJlc3VsdC50ZXh0Py5zdGFydHNXaXRoKCdkYXRhOmltYWdlJykpIHtcbiAgICByZXR1cm4gcmVzdWx0LnRleHQ7XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG5mdW5jdGlvbiByZWZlcmVuY2VJbWFnZUNvbnRlbnRUeXBlKGRhdGFVcmk6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IG1hdGNoID0gZGF0YVVyaS5tYXRjaCgvXmRhdGE6KFteO10rKTsvKTtcbiAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gJ2ltYWdlL3BuZyc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlV2l0aFJlZmVyZW5jZShcbiAgcHJvbXB0VGV4dDogc3RyaW5nLFxuICByZWZlcmVuY2VEYXRhVXJpOiBzdHJpbmdcbik6IFByb21pc2U8R2VuZXJhdGVSZXN1bHQ+IHtcbiAgY29uc3QgY29udGVudFR5cGUgPSByZWZlcmVuY2VJbWFnZUNvbnRlbnRUeXBlKHJlZmVyZW5jZURhdGFVcmkpO1xuXG4gIHJldHVybiBhaS5nZW5lcmF0ZSh7XG4gICAgbW9kZWw6IElNQUdFX01PREVMLFxuICAgIG91dHB1dDogeyBmb3JtYXQ6ICdtZWRpYScgfSxcbiAgICBwcm9tcHQ6IFtcbiAgICAgIHtcbiAgICAgICAgbWVkaWE6IHtcbiAgICAgICAgICB1cmw6IHJlZmVyZW5jZURhdGFVcmksXG4gICAgICAgICAgY29udGVudFR5cGUsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0ZXh0OiBgJHtwcm9tcHRUZXh0fVxcblxcblVzZSB0aGUgYXR0YWNoZWQgcmVmZXJlbmNlIGltYWdlIGFzIHRoZSBzdHJpY3QgaWRlbnRpdHkgYW5jaG9yLiBHZW5lcmF0ZSBhIG5ldyBpbWFnZSB0aGF0IHByZXNlcnZlcyB0aGUgc2FtZSBwZXJzb24sIGNsb3RoaW5nLCBhbmQgc3R1ZGlvIHNldHVwIHdoaWxlIGFwcGx5aW5nIG9ubHkgdGhlIG5ldyBjYW1lcmEgYW5nbGUgZGVzY3JpYmVkIGFib3ZlLmAsXG4gICAgICB9LFxuICAgIF0sXG4gICAgY29uZmlnOiBHRU1JTklfSU1BR0VfQ09ORklHLFxuICB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoXG4gIHN0cmFpZ2h0UHJvbXB0OiBzdHJpbmdcbik6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IHN0cmFpZ2h0UmVzcG9uc2UgPSBhd2FpdCBhaS5nZW5lcmF0ZSh7XG4gICAgbW9kZWw6IElNQUdFX01PREVMLFxuICAgIG91dHB1dDogeyBmb3JtYXQ6ICdtZWRpYScgfSxcbiAgICBwcm9tcHQ6IHN0cmFpZ2h0UHJvbXB0LFxuICAgIGNvbmZpZzogR0VNSU5JX0lNQUdFX0NPTkZJRyxcbiAgfSk7XG5cbiAgY29uc3Qgc3RyYWlnaHRJbWFnZUI2NCA9IGV4dHJhY3RJbWFnZURhdGFVcmkoc3RyYWlnaHRSZXNwb25zZSk7XG4gIGlmICghc3RyYWlnaHRJbWFnZUI2NCkge1xuICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGdlbmVyYXRlIHRoZSBNYXN0ZXIgUmVmZXJlbmNlIGltYWdlLicpO1xuICB9XG4gIHJldHVybiBzdHJhaWdodEltYWdlQjY0O1xufVxuXG4vKiogR2VuZXJhdGUgYSBzaW5nbGUgaGVybyAoc3RyYWlnaHQpIGltYWdlIGZyb20gdGV4dCBwcm9tcHQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVTdHJhaWdodEltYWdlKFxuICBzdHJhaWdodFByb21wdDogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICByZXR1cm4gZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoc3RyYWlnaHRQcm9tcHQpO1xufVxuXG4vKiogR2VuZXJhdGUgYSBwcm9maWxlIGFuZ2xlIHVzaW5nIGEgaGVybyBpbWFnZSBhcyBpZGVudGl0eSByZWZlcmVuY2UuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVQcm9maWxlSW1hZ2UoXG4gIHByb21wdFRleHQ6IHN0cmluZyxcbiAgcmVmZXJlbmNlRGF0YVVyaTogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdlbmVyYXRlV2l0aFJlZmVyZW5jZShwcm9tcHRUZXh0LCByZWZlcmVuY2VEYXRhVXJpKTtcbiAgY29uc3QgaW1hZ2UgPSBleHRyYWN0SW1hZ2VEYXRhVXJpKHJlc3BvbnNlKTtcbiAgaWYgKCFpbWFnZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdGYWlsZWQgdG8gZ2VuZXJhdGUgcHJvZmlsZSByZWZlcmVuY2UgaW1hZ2UuIFRoZSBtb2RlbCBtYXkgaGF2ZSByZXR1cm5lZCB0ZXh0IGluc3RlYWQgb2YgYW4gaW1hZ2XigJRyZXRyeSBnZW5lcmF0aW9uLidcbiAgICApO1xuICB9XG4gIHJldHVybiBpbWFnZTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTW9kZWxJbWFnZXMoXG4gIGlucHV0OiBHZW5lcmF0ZU1vZGVsSW1hZ2VzSW5wdXRcbik6IFByb21pc2U8R2VuZXJhdGVNb2RlbEltYWdlc091dHB1dD4ge1xuICBjb25zdCB7IHN0cmFpZ2h0UHJvbXB0LCBsZWZ0UHJvbXB0LCByaWdodFByb21wdCB9ID0gaW5wdXQucHJvbXB0cztcblxuICBjb25zdCBzdHJhaWdodEltYWdlQjY0ID0gYXdhaXQgZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoc3RyYWlnaHRQcm9tcHQpO1xuXG4gIGNvbnN0IFtsZWZ0LCByaWdodF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgZ2VuZXJhdGVQcm9maWxlSW1hZ2UobGVmdFByb21wdCwgc3RyYWlnaHRJbWFnZUI2NCksXG4gICAgZ2VuZXJhdGVQcm9maWxlSW1hZ2UocmlnaHRQcm9tcHQsIHN0cmFpZ2h0SW1hZ2VCNjQpLFxuICBdKTtcblxuICByZXR1cm4ge1xuICAgIGltYWdlbjoge1xuICAgICAgc3RyYWlnaHQ6IHN0cmFpZ2h0SW1hZ2VCNjQsXG4gICAgICBsZWZ0LFxuICAgICAgcmlnaHQsXG4gICAgfSxcbiAgfTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoib1RBMkdzQiJ9
}),
"[project]/src/ai/flows/data:87c1d1 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"60a5896f6e306e1b38784e0b2d65c6ba88970975e9":"generateProfileImage"},"src/ai/flows/generate-model-images.ts",""] */ __turbopack_context__.s([
    "generateProfileImage",
    ()=>generateProfileImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var generateProfileImage = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("60a5896f6e306e1b38784e0b2d65c6ba88970975e9", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateProfileImage"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9kZWwtaW1hZ2VzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcbi8qKlxuICogQGZpbGVPdmVydmlldyBTZXF1ZW50aWFsIDMtYW5nbGUgZ2VuZXJhdGlvbiB2aWEgZ2VtaW5pLTMtcHJvLWltYWdlIHdpdGggaGVyby1pbWFnZSByZWZlcmVuY2UuXG4gKi9cblxuaW1wb3J0IHsgYWkgfSBmcm9tICdAL2FpL2dlbmtpdCc7XG5cbmNvbnN0IElNQUdFX01PREVMID0gJ2dvb2dsZWFpL2dlbWluaS0zLXByby1pbWFnZSc7XG5cbi8qKiBHZW1pbmkgbmF0aXZlIGltYWdlIG1vZGVscyB1c2UgaW1hZ2VDb25maWcsIG5vdCBJbWFnZW4ncyB0b3AtbGV2ZWwgYXNwZWN0UmF0aW8uICovXG5jb25zdCBHRU1JTklfSU1BR0VfQ09ORklHID0ge1xuICByZXNwb25zZU1vZGFsaXRpZXM6IFsnVEVYVCcsICdJTUFHRSddLFxuICBpbWFnZUNvbmZpZzoge1xuICAgIGFzcGVjdFJhdGlvOiAnMzo0JyxcbiAgfSxcbn07XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc0lucHV0IHtcbiAgcHJvbXB0czoge1xuICAgIHN0cmFpZ2h0UHJvbXB0OiBzdHJpbmc7XG4gICAgbGVmdFByb21wdDogc3RyaW5nO1xuICAgIHJpZ2h0UHJvbXB0OiBzdHJpbmc7XG4gIH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc091dHB1dCB7XG4gIGltYWdlbj86IHsgc3RyYWlnaHQ6IHN0cmluZzsgbGVmdDogc3RyaW5nOyByaWdodDogc3RyaW5nIH07XG59XG5cbnR5cGUgR2VuZXJhdGVSZXN1bHQgPSBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGFpLmdlbmVyYXRlPj47XG5cbmZ1bmN0aW9uIGV4dHJhY3RJbWFnZURhdGFVcmkocmVzdWx0OiBHZW5lcmF0ZVJlc3VsdCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGlmIChyZXN1bHQubWVkaWE/LnVybCkge1xuICAgIHJldHVybiByZXN1bHQubWVkaWEudXJsO1xuICB9XG5cbiAgY29uc3QgY29udGVudCA9IHJlc3VsdC5tZXNzYWdlPy5jb250ZW50O1xuICBpZiAoQXJyYXkuaXNBcnJheShjb250ZW50KSkge1xuICAgIGZvciAoY29uc3QgcGFydCBvZiBjb250ZW50KSB7XG4gICAgICBpZiAoXG4gICAgICAgIHBhcnQgJiZcbiAgICAgICAgdHlwZW9mIHBhcnQgPT09ICdvYmplY3QnICYmXG4gICAgICAgICdtZWRpYScgaW4gcGFydCAmJlxuICAgICAgICBwYXJ0Lm1lZGlhICYmXG4gICAgICAgIHR5cGVvZiBwYXJ0Lm1lZGlhID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAndXJsJyBpbiBwYXJ0Lm1lZGlhICYmXG4gICAgICAgIHR5cGVvZiBwYXJ0Lm1lZGlhLnVybCA9PT0gJ3N0cmluZydcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gcGFydC5tZWRpYS51cmw7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKHJlc3VsdC50ZXh0Py5zdGFydHNXaXRoKCdkYXRhOmltYWdlJykpIHtcbiAgICByZXR1cm4gcmVzdWx0LnRleHQ7XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG5mdW5jdGlvbiByZWZlcmVuY2VJbWFnZUNvbnRlbnRUeXBlKGRhdGFVcmk6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IG1hdGNoID0gZGF0YVVyaS5tYXRjaCgvXmRhdGE6KFteO10rKTsvKTtcbiAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gJ2ltYWdlL3BuZyc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlV2l0aFJlZmVyZW5jZShcbiAgcHJvbXB0VGV4dDogc3RyaW5nLFxuICByZWZlcmVuY2VEYXRhVXJpOiBzdHJpbmdcbik6IFByb21pc2U8R2VuZXJhdGVSZXN1bHQ+IHtcbiAgY29uc3QgY29udGVudFR5cGUgPSByZWZlcmVuY2VJbWFnZUNvbnRlbnRUeXBlKHJlZmVyZW5jZURhdGFVcmkpO1xuXG4gIHJldHVybiBhaS5nZW5lcmF0ZSh7XG4gICAgbW9kZWw6IElNQUdFX01PREVMLFxuICAgIG91dHB1dDogeyBmb3JtYXQ6ICdtZWRpYScgfSxcbiAgICBwcm9tcHQ6IFtcbiAgICAgIHtcbiAgICAgICAgbWVkaWE6IHtcbiAgICAgICAgICB1cmw6IHJlZmVyZW5jZURhdGFVcmksXG4gICAgICAgICAgY29udGVudFR5cGUsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0ZXh0OiBgJHtwcm9tcHRUZXh0fVxcblxcblVzZSB0aGUgYXR0YWNoZWQgcmVmZXJlbmNlIGltYWdlIGFzIHRoZSBzdHJpY3QgaWRlbnRpdHkgYW5jaG9yLiBHZW5lcmF0ZSBhIG5ldyBpbWFnZSB0aGF0IHByZXNlcnZlcyB0aGUgc2FtZSBwZXJzb24sIGNsb3RoaW5nLCBhbmQgc3R1ZGlvIHNldHVwIHdoaWxlIGFwcGx5aW5nIG9ubHkgdGhlIG5ldyBjYW1lcmEgYW5nbGUgZGVzY3JpYmVkIGFib3ZlLmAsXG4gICAgICB9LFxuICAgIF0sXG4gICAgY29uZmlnOiBHRU1JTklfSU1BR0VfQ09ORklHLFxuICB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoXG4gIHN0cmFpZ2h0UHJvbXB0OiBzdHJpbmdcbik6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IHN0cmFpZ2h0UmVzcG9uc2UgPSBhd2FpdCBhaS5nZW5lcmF0ZSh7XG4gICAgbW9kZWw6IElNQUdFX01PREVMLFxuICAgIG91dHB1dDogeyBmb3JtYXQ6ICdtZWRpYScgfSxcbiAgICBwcm9tcHQ6IHN0cmFpZ2h0UHJvbXB0LFxuICAgIGNvbmZpZzogR0VNSU5JX0lNQUdFX0NPTkZJRyxcbiAgfSk7XG5cbiAgY29uc3Qgc3RyYWlnaHRJbWFnZUI2NCA9IGV4dHJhY3RJbWFnZURhdGFVcmkoc3RyYWlnaHRSZXNwb25zZSk7XG4gIGlmICghc3RyYWlnaHRJbWFnZUI2NCkge1xuICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGdlbmVyYXRlIHRoZSBNYXN0ZXIgUmVmZXJlbmNlIGltYWdlLicpO1xuICB9XG4gIHJldHVybiBzdHJhaWdodEltYWdlQjY0O1xufVxuXG4vKiogR2VuZXJhdGUgYSBzaW5nbGUgaGVybyAoc3RyYWlnaHQpIGltYWdlIGZyb20gdGV4dCBwcm9tcHQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVTdHJhaWdodEltYWdlKFxuICBzdHJhaWdodFByb21wdDogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICByZXR1cm4gZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoc3RyYWlnaHRQcm9tcHQpO1xufVxuXG4vKiogR2VuZXJhdGUgYSBwcm9maWxlIGFuZ2xlIHVzaW5nIGEgaGVybyBpbWFnZSBhcyBpZGVudGl0eSByZWZlcmVuY2UuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVQcm9maWxlSW1hZ2UoXG4gIHByb21wdFRleHQ6IHN0cmluZyxcbiAgcmVmZXJlbmNlRGF0YVVyaTogc3RyaW5nXG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGdlbmVyYXRlV2l0aFJlZmVyZW5jZShwcm9tcHRUZXh0LCByZWZlcmVuY2VEYXRhVXJpKTtcbiAgY29uc3QgaW1hZ2UgPSBleHRyYWN0SW1hZ2VEYXRhVXJpKHJlc3BvbnNlKTtcbiAgaWYgKCFpbWFnZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdGYWlsZWQgdG8gZ2VuZXJhdGUgcHJvZmlsZSByZWZlcmVuY2UgaW1hZ2UuIFRoZSBtb2RlbCBtYXkgaGF2ZSByZXR1cm5lZCB0ZXh0IGluc3RlYWQgb2YgYW4gaW1hZ2XigJRyZXRyeSBnZW5lcmF0aW9uLidcbiAgICApO1xuICB9XG4gIHJldHVybiBpbWFnZTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTW9kZWxJbWFnZXMoXG4gIGlucHV0OiBHZW5lcmF0ZU1vZGVsSW1hZ2VzSW5wdXRcbik6IFByb21pc2U8R2VuZXJhdGVNb2RlbEltYWdlc091dHB1dD4ge1xuICBjb25zdCB7IHN0cmFpZ2h0UHJvbXB0LCBsZWZ0UHJvbXB0LCByaWdodFByb21wdCB9ID0gaW5wdXQucHJvbXB0cztcblxuICBjb25zdCBzdHJhaWdodEltYWdlQjY0ID0gYXdhaXQgZ2VuZXJhdGVTdHJhaWdodEltYWdlSW50ZXJuYWwoc3RyYWlnaHRQcm9tcHQpO1xuXG4gIGNvbnN0IFtsZWZ0LCByaWdodF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgZ2VuZXJhdGVQcm9maWxlSW1hZ2UobGVmdFByb21wdCwgc3RyYWlnaHRJbWFnZUI2NCksXG4gICAgZ2VuZXJhdGVQcm9maWxlSW1hZ2UocmlnaHRQcm9tcHQsIHN0cmFpZ2h0SW1hZ2VCNjQpLFxuICBdKTtcblxuICByZXR1cm4ge1xuICAgIGltYWdlbjoge1xuICAgICAgc3RyYWlnaHQ6IHN0cmFpZ2h0SW1hZ2VCNjQsXG4gICAgICBsZWZ0LFxuICAgICAgcmlnaHQsXG4gICAgfSxcbiAgfTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoibVRBa0hzQiJ9
}),
"[project]/src/hooks/useBatchProcessor.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useBatchProcessor",
    ()=>useBatchProcessor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$9fc1c9__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:9fc1c9 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$6e7891__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:6e7891 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$87c1d1__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:87c1d1 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/config-schema.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/hooks/useConfigurationTracker.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ConfigurationTrackerContext.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
/** Tier 1: 10 IPM → 3 models × 3 images = 9 images per wave. */ const BATCH_WAVE_SIZE = 3;
const TIER1_THROTTLE_MS = 20_000;
function createSeed() {
    return Math.floor(1000000000 + Math.random() * 9000000000).toString();
}
function errorMessage(err) {
    return err instanceof Error ? err.message : String(err);
}
async function generatePromptsForItem(item) {
    try {
        const prompts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$9fc1c9__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelTurnaroundPrompts"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseBatchPromptInput"])(item.config));
        return {
            id: item.id,
            prompts
        };
    } catch (err) {
        return {
            id: item.id,
            error: errorMessage(err)
        };
    }
}
async function generateHeroForItem(id, prompts) {
    try {
        const straight = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$6e7891__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateStraightImage"])(prompts.straightPrompt);
        return {
            id,
            prompts,
            straight
        };
    } catch (err) {
        return {
            id,
            error: errorMessage(err)
        };
    }
}
async function generateProfilesForItem(id, prompts, straight) {
    try {
        const [left, right] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$87c1d1__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateProfileImage"])(prompts.leftPrompt, straight),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$87c1d1__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateProfileImage"])(prompts.rightPrompt, straight)
        ]);
        return {
            id,
            prompts,
            images: {
                straight,
                left,
                right
            }
        };
    } catch (err) {
        return {
            id,
            error: errorMessage(err)
        };
    }
}
function useBatchProcessor() {
    const [batchQueue, setBatchQueue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isProcessing, setIsProcessing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const batchQueueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]);
    const processingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    const { finalizeAndApproveConfig } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useConfigurationTracker"])();
    const setQueue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((updater)=>{
        setBatchQueue((prev)=>{
            const next = typeof updater === "function" ? updater(prev) : updater;
            batchQueueRef.current = next;
            return next;
        });
    }, []);
    const updateItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((id, patch)=>{
        setQueue((prev)=>prev.map((item)=>item.id === id ? {
                    ...item,
                    ...patch
                } : item));
    }, [
        setQueue
    ]);
    const loadJsonBatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((jsonString)=>{
        let parsed;
        try {
            parsed = JSON.parse(jsonString);
        } catch  {
            throw new Error("Invalid JSON structure. Please check your formatting.");
        }
        const items = Array.isArray(parsed) ? parsed : [
            parsed
        ];
        if (items.length === 0) {
            throw new Error("JSON array is empty. Add at least one model config.");
        }
        const newQueue = items.map((item, index)=>{
            if (!item || typeof item !== "object" || Array.isArray(item)) {
                throw new Error(`Invalid entry at index ${index}. Each item must be a JSON object.`);
            }
            const config = item;
            return {
                id: `batch_${crypto.randomUUID()}`,
                displayName: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBatchDisplayName"])(config, `Model #${index + 1}`),
                config,
                status: "Pending"
            };
        });
        setQueue((prev)=>[
                ...prev,
                ...newQueue
            ]);
        return true;
    }, [
        setQueue
    ]);
    const processWave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (wave)=>{
        wave.forEach((item)=>updateItem(item.id, {
                status: "Generating Prompts",
                error: undefined
            }));
        const promptResults = await Promise.all(wave.map((item)=>generatePromptsForItem(item)));
        const readyForHero = [];
        for (const result of promptResults){
            if ("error" in result) {
                updateItem(result.id, {
                    status: "Failed",
                    error: result.error
                });
            } else {
                readyForHero.push(result);
            }
        }
        if (readyForHero.length === 0) return;
        readyForHero.forEach(({ id })=>updateItem(id, {
                status: "Generating Images"
            }));
        // Phase 2: all hero images in parallel (up to 3 IPM)
        const heroResults = await Promise.all(readyForHero.map(({ id, prompts })=>generateHeroForItem(id, prompts)));
        const readyForProfiles = [];
        for (const result of heroResults){
            if ("error" in result) {
                updateItem(result.id, {
                    status: "Failed",
                    error: result.error
                });
            } else {
                readyForProfiles.push(result);
            }
        }
        if (readyForProfiles.length === 0) return;
        // Phase 3: all profile images in parallel (up to 6 IPM)
        const profileResults = await Promise.all(readyForProfiles.map(({ id, prompts, straight })=>generateProfilesForItem(id, prompts, straight)));
        for (const result of profileResults){
            if ("error" in result) {
                updateItem(result.id, {
                    status: "Failed",
                    error: result.error
                });
            } else {
                updateItem(result.id, {
                    status: "Review",
                    prompts: result.prompts,
                    images: result.images,
                    seed: createSeed()
                });
            }
        }
    }, [
        updateItem
    ]);
    const processBatchWaves = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async ()=>{
        if (processingRef.current) return;
        processingRef.current = true;
        setIsProcessing(true);
        try {
            while(true){
                const pending = batchQueueRef.current.filter((item)=>item.status === "Pending");
                if (pending.length === 0) break;
                const wave = pending.slice(0, BATCH_WAVE_SIZE);
                await processWave(wave);
                const hasMorePending = batchQueueRef.current.some((item)=>item.status === "Pending");
                if (hasMorePending) {
                    await new Promise((resolve)=>setTimeout(resolve, TIER1_THROTTLE_MS));
                }
            }
        } finally{
            processingRef.current = false;
            setIsProcessing(false);
        }
    }, [
        processWave
    ]);
    const startBatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        if (!processingRef.current) {
            void processBatchWaves();
        }
    }, [
        processBatchWaves
    ]);
    const approveItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((id, name)=>{
        const item = batchQueueRef.current.find((i)=>i.id === id);
        if (!item?.images) {
            throw new Error("No images available to approve.");
        }
        finalizeAndApproveConfig(name, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2d$schema$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toConfigurationTraitsFromRecord"])(item.config));
        updateItem(id, {
            status: "Approved"
        });
    }, [
        finalizeAndApproveConfig,
        updateItem
    ]);
    const regenerateItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((id)=>{
        updateItem(id, {
            status: "Pending",
            images: undefined,
            prompts: undefined,
            seed: undefined,
            error: undefined
        });
        if (!processingRef.current) {
            void processBatchWaves();
        }
    }, [
        processBatchWaves,
        updateItem
    ]);
    return {
        batchQueue,
        isProcessing,
        loadJsonBatch,
        startBatch,
        approveItem,
        regenerateItem
    };
}
}),
"[project]/src/app/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>KotoorModelAI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/types.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$9fc1c9__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:9fc1c9 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$e39db4__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:e39db4 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/download-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GeneratorForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/GeneratorForm.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ActiveModelDisplay$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ActiveModelDisplay.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModelLibraryManager$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ModelLibraryManager.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CoverageMatrix$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CoverageMatrix.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LegacyModelImporter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LegacyModelImporter.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BatchProcessorQueue$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BatchProcessorQueue.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useBatchProcessor.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/hooks/useConfigurationTracker.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/contexts/ConfigurationTrackerContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function KotoorModelAIContent() {
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DEFAULT_FORM_DATA_FEMALE"]);
    const [activeModel, setActiveModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isGenerating, setIsGenerating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    const { batchQueue, isProcessing, loadJsonBatch, startBatch, approveItem, regenerateItem } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useBatchProcessor"])();
    const handleGenerate = async ()=>{
        if (!formData.subGroup?.trim()) {
            toast({
                variant: "destructive",
                title: "Sub-group required",
                description: "Select a specific demographic sub-group before generating."
            });
            return;
        }
        setIsGenerating(true);
        setActiveModel(null);
        try {
            const prompts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$9fc1c9__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelTurnaroundPrompts"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toPromptInput"])(formData));
            const imageResults = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$e39db4__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelImages"])({
                prompts
            });
            const seed = Math.floor(1000000000 + Math.random() * 9000000000).toString();
            const newModel = {
                seed,
                imageResults,
                prompts,
                formData
            };
            setActiveModel(newModel);
        } catch (error) {
            console.error("Failed to generate model", error);
            toast({
                variant: "destructive",
                title: "Generation Failed",
                description: error instanceof Error ? error.message : "There was an error generating the model. Please try again."
            });
        } finally{
            setIsGenerating(false);
        }
    };
    const handleBulkDownload = async ()=>{
        if (!activeModel) return;
        toast({
            title: "Preparing Download...",
            description: "Your model assets are being zipped."
        });
        try {
            const engineKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getActiveEngineKeys"])(activeModel.imageResults);
            if (engineKeys.length === 1 && activeModel.imageResults.imagen) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["downloadModelZip"])({
                    seed: activeModel.seed,
                    images: activeModel.imageResults.imagen,
                    prompts: activeModel.prompts
                });
                return;
            }
            const JSZip = (await __turbopack_context__.A("[project]/node_modules/jszip/lib/index.js [app-ssr] (ecmascript, async loader)")).default;
            const zip = new JSZip();
            const promptData = `Straight Prompt:\n${activeModel.prompts.straightPrompt}\n\nLeft Prompt:\n${activeModel.prompts.leftPrompt}\n\nRight Prompt:\n${activeModel.prompts.rightPrompt}`;
            zip.file("prompts.txt", promptData);
            for (const engineKey of engineKeys){
                const images = activeModel.imageResults[engineKey];
                if (!images) continue;
                const folder = engineKeys.length > 1 ? `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][engineKey].replace(/\s+/g, "_")}/` : "";
                zip.file(`${folder}straight_${activeModel.seed}.png`, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataURItoBlob"])(images.straight));
                zip.file(`${folder}left_${activeModel.seed}.png`, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataURItoBlob"])(images.left));
                zip.file(`${folder}right_${activeModel.seed}.png`, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataURItoBlob"])(images.right));
            }
            const content = await zip.generateAsync({
                type: "blob"
            });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(content);
            link.download = `model_${activeModel.seed}.zip`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        } catch (error) {
            console.error("Failed to create zip for download", error);
            toast({
                variant: "destructive",
                title: "Download Failed",
                description: "Could not prepare your files for download. Please try again."
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "container mx-auto p-4 md:p-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col lg:flex-row lg:space-x-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "lg:w-1/3 xl:w-1/4 mb-8 lg:mb-0",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GeneratorForm$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        formData: formData,
                        setFormData: setFormData,
                        onGenerate: handleGenerate,
                        isGenerating: isGenerating,
                        onLoadBatch: loadJsonBatch
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 151,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 150,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "lg:w-2/3 xl:w-3/4 flex flex-col space-y-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BatchProcessorQueue$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BatchProcessorQueue"], {
                            batchQueue: batchQueue,
                            isProcessing: isProcessing,
                            onStartBatch: startBatch,
                            onApproveItem: approveItem,
                            onRegenerateItem: regenerateItem
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 161,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ActiveModelDisplay$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            activeModel: activeModel,
                            isGenerating: isGenerating,
                            onBulkDownload: handleBulkDownload
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 168,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModelLibraryManager$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ModelLibraryManager"], {
                            currentFormTraits: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toConfigurationTraits"])(formData)
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 173,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LegacyModelImporter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LegacyModelImporter"], {
                            currentFormTraits: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toConfigurationTraits"])(formData)
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 176,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CoverageMatrix$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CoverageMatrix"], {}, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 179,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 160,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 149,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 148,
        columnNumber: 5
    }, this);
}
function KotoorModelAI() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$contexts$2f$ConfigurationTrackerContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ConfigurationTrackerProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(KotoorModelAIContent, {}, void 0, false, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 189,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 188,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__868a5695._.js.map
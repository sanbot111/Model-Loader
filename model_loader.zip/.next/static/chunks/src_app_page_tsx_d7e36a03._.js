(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_jszip_lib_index_81ff3afa.js",
  "static/chunks/src_8779811e._.js",
  "static/chunks/node_modules_next_c5aef62e._.js",
  "static/chunks/node_modules_jszip_lib_de8925ba._.js",
  "static/chunks/node_modules_pako_2138412d._.js",
  "static/chunks/node_modules_9ddb80ba._.js"
],
    source: "dynamic"
});

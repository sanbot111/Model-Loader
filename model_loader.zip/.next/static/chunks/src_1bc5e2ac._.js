(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ENGINE_LABELS",
    ()=>ENGINE_LABELS,
    "getActiveEngineKeys",
    ()=>getActiveEngineKeys,
    "hasMultipleEngines",
    ()=>hasMultipleEngines
]);
const ENGINE_LABELS = {
    imagen: "Imagen 4",
    openai: "GPT Image 2"
};
function getActiveEngineKeys(results) {
    const keys = [];
    if (results.imagen) keys.push("imagen");
    if (results.openai) keys.push("openai");
    return keys;
}
function hasMultipleEngines(results) {
    return getActiveEngineKeys(results).length > 1;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AGE_GROUPS",
    ()=>AGE_GROUPS,
    "DEFAULT_ENGINES",
    ()=>DEFAULT_ENGINES,
    "DEFAULT_FORM_DATA_FEMALE",
    ()=>DEFAULT_FORM_DATA_FEMALE,
    "DEFAULT_FORM_DATA_MALE",
    ()=>DEFAULT_FORM_DATA_MALE,
    "FEMALE_ARCHETYPES",
    ()=>FEMALE_ARCHETYPES,
    "FEMALE_BODY_TYPES",
    ()=>FEMALE_BODY_TYPES,
    "FEMALE_GENDER",
    ()=>FEMALE_GENDER,
    "FEMALE_HAIR_STYLES",
    ()=>FEMALE_HAIR_STYLES,
    "GENDERS",
    ()=>GENDERS,
    "HAIR_COLORS",
    ()=>HAIR_COLORS,
    "MALE_ARCHETYPES",
    ()=>MALE_ARCHETYPES,
    "MALE_BODY_TYPES",
    ()=>MALE_BODY_TYPES,
    "MALE_FACIAL_HAIR",
    ()=>MALE_FACIAL_HAIR,
    "MALE_GENDER",
    ()=>MALE_GENDER,
    "MALE_HAIR_STYLES",
    ()=>MALE_HAIR_STYLES,
    "REGIONS",
    ()=>REGIONS,
    "SKIN_TONES",
    ()=>SKIN_TONES,
    "femaleHairStyleOptions",
    ()=>femaleHairStyleOptions,
    "getArchetypes",
    ()=>getArchetypes,
    "getBodyTypes",
    ()=>getBodyTypes,
    "getDefaultSubGroup",
    ()=>getDefaultSubGroup,
    "getGenderSpecificDefaults",
    ()=>getGenderSpecificDefaults,
    "getHairStyles",
    ()=>getHairStyles,
    "getRegionLabel",
    ()=>getRegionLabel,
    "getSubGroupsForRegion",
    ()=>getSubGroupsForRegion,
    "hairColorOptions",
    ()=>hairColorOptions,
    "hasAtLeastOneEngine",
    ()=>hasAtLeastOneEngine,
    "isMaleGender",
    ()=>isMaleGender,
    "maleHairStyleOptions",
    ()=>maleHairStyleOptions,
    "regionEthnicityOptions",
    ()=>regionEthnicityOptions,
    "skinToneOptions",
    ()=>skinToneOptions,
    "subGroupOptionsMap",
    ()=>subGroupOptionsMap,
    "toConfigurationTraits",
    ()=>toConfigurationTraits,
    "toPromptInput",
    ()=>toPromptInput
]);
const FEMALE_GENDER = "Female / Woman";
const MALE_GENDER = "Male / Man";
const GENDERS = [
    FEMALE_GENDER,
    MALE_GENDER
];
const AGE_GROUPS = [
    "Child (4–12 years)",
    "Teen (13–19 years)",
    "Young Adult (20–29 years)",
    "Adult (30–45 years)",
    "Middle-Aged (46–60 years)",
    "Senior / Mature (60+ years)"
];
const regionEthnicityOptions = [
    {
        label: "African / Black",
        value: "african_black"
    },
    {
        label: "East Asian",
        value: "east_asian"
    },
    {
        label: "South Asian",
        value: "south_asian"
    },
    {
        label: "Southeast Asian",
        value: "southeast_asian"
    },
    {
        label: "Middle Eastern / North African (MENA)",
        value: "mena"
    },
    {
        label: "Caucasian / White",
        value: "caucasian_white"
    },
    {
        label: "Hispanic / Latin American",
        value: "hispanic_latin"
    },
    {
        label: "Indigenous / First Nations",
        value: "indigenous"
    },
    {
        label: "Mixed / Multiracial",
        value: "mixed_multiracial"
    }
];
const subGroupOptionsMap = {
    african_black: [
        {
            label: "West African (e.g., Nigerian, Ghanaian)",
            value: "west african phenotype"
        },
        {
            label: "East African (e.g., Ethiopian, Somali)",
            value: "east african phenotype"
        },
        {
            label: "Afro-Caribbean",
            value: "afro-caribbean phenotype"
        },
        {
            label: "African-American",
            value: "african-american phenotype"
        }
    ],
    east_asian: [
        {
            label: "Chinese",
            value: "chinese phenotype"
        },
        {
            label: "Japanese",
            value: "japanese phenotype"
        },
        {
            label: "Korean",
            value: "korean phenotype"
        },
        {
            label: "Taiwanese",
            value: "taiwanese phenotype"
        }
    ],
    south_asian: [
        {
            label: "South Asian (North Indian)",
            value: "south asian, north indian phenotype"
        },
        {
            label: "South Asian (South Indian)",
            value: "south asian, south indian phenotype"
        },
        {
            label: "Pakistani",
            value: "pakistani phenotype"
        },
        {
            label: "Bangladeshi",
            value: "bangladeshi phenotype"
        },
        {
            label: "Sri Lankan",
            value: "sri lankan phenotype"
        }
    ],
    southeast_asian: [
        {
            label: "Thai",
            value: "thai phenotype"
        },
        {
            label: "Vietnamese",
            value: "vietnamese phenotype"
        },
        {
            label: "Filipino",
            value: "filipino phenotype"
        },
        {
            label: "Indonesian / Malaysian",
            value: "indonesian malaysian phenotype"
        }
    ],
    mena: [
        {
            label: "Egyptian",
            value: "egyptian phenotype"
        },
        {
            label: "Levantine (e.g., Lebanese, Syrian)",
            value: "levantine arab phenotype"
        },
        {
            label: "Persian / Iranian",
            value: "persian iranian phenotype"
        },
        {
            label: "North African Maghrebi",
            value: "maghrebi arab phenotype"
        }
    ],
    caucasian_white: [
        {
            label: "Northern European / Nordic",
            value: "northern european nordic phenotype"
        },
        {
            label: "Southern European / Mediterranean",
            value: "southern european mediterranean phenotype"
        },
        {
            label: "Eastern European / Slavic",
            value: "eastern european slavic phenotype"
        },
        {
            label: "Celtic / Anglo-Saxon",
            value: "celtic anglo-saxon phenotype"
        }
    ],
    hispanic_latin: [
        {
            label: "Mexican / Central American",
            value: "mexican central american phenotype"
        },
        {
            label: "South American (Andean / Mestizo)",
            value: "andean mestizo phenotype"
        },
        {
            label: "Afro-Latino",
            value: "afro-latino phenotype"
        },
        {
            label: "Caribbean Hispanic",
            value: "caribbean hispanic phenotype"
        }
    ],
    indigenous: [
        {
            label: "Native American / First Nations",
            value: "native american first nations phenotype"
        },
        {
            label: "Māori / Pacific Islander",
            value: "maori pacific islander phenotype"
        },
        {
            label: "Aboriginal Australian",
            value: "aboriginal australian phenotype"
        }
    ],
    mixed_multiracial: [
        {
            label: "Eurasian (East Asian + White)",
            value: "eurasian mixed phenotype"
        },
        {
            label: "Afro-Asian (Blasian)",
            value: "afro-asian mixed phenotype"
        },
        {
            label: "Multiracial South Asian",
            value: "multiracial south asian phenotype"
        }
    ]
};
const REGIONS = regionEthnicityOptions;
function getSubGroupsForRegion(regionKey) {
    var _subGroupOptionsMap_regionKey;
    return (_subGroupOptionsMap_regionKey = subGroupOptionsMap[regionKey]) !== null && _subGroupOptionsMap_regionKey !== void 0 ? _subGroupOptionsMap_regionKey : [];
}
function getDefaultSubGroup(regionKey) {
    var _getSubGroupsForRegion_;
    var _getSubGroupsForRegion__value;
    return (_getSubGroupsForRegion__value = (_getSubGroupsForRegion_ = getSubGroupsForRegion(regionKey)[0]) === null || _getSubGroupsForRegion_ === void 0 ? void 0 : _getSubGroupsForRegion_.value) !== null && _getSubGroupsForRegion__value !== void 0 ? _getSubGroupsForRegion__value : "";
}
function getRegionLabel(regionKey) {
    var _regionEthnicityOptions_find;
    var _regionEthnicityOptions_find_label;
    return (_regionEthnicityOptions_find_label = (_regionEthnicityOptions_find = regionEthnicityOptions.find((r)=>r.value === regionKey)) === null || _regionEthnicityOptions_find === void 0 ? void 0 : _regionEthnicityOptions_find.label) !== null && _regionEthnicityOptions_find_label !== void 0 ? _regionEthnicityOptions_find_label : regionKey;
}
const skinToneOptions = [
    {
        label: "Type 1: Very light, pale, or porcelain",
        value: "type 1 very light pale porcelain"
    },
    {
        label: "Type 2: Light or fair",
        value: "type 2 light fair"
    },
    {
        label: "Type 3: Medium, wheatish to light olive",
        value: "type 3 medium wheatish light olive warm undertone"
    },
    {
        label: "Type 4: Olive, warm tan to caramel",
        value: "type 4 olive warm tan caramel undertone"
    },
    {
        label: "Type 5: Rich bronze, medium-dark warm brown",
        value: "type 5 rich bronze medium-dark warm brown undertone"
    },
    {
        label: "Type 6: Deep, dark mahogany to rich espresso brown",
        value: "type 6 deep dark mahogany rich espresso brown warm undertone"
    }
];
const SKIN_TONES = skinToneOptions;
const hairColorOptions = [
    {
        label: "Jet Black",
        value: "jet black"
    },
    {
        label: "Natural Soft Black",
        value: "natural soft black"
    },
    {
        label: "Dark Brown / Espresso",
        value: "dark brown espresso"
    },
    {
        label: "Medium Brown / Chestnut",
        value: "medium brown chestnut"
    },
    {
        label: "Burgundy / Henna Red Tone",
        value: "burgundy henna red tone"
    },
    {
        label: "Honey Blonde / Golden Brown Highlights",
        value: "honey blonde golden brown highlights"
    },
    {
        label: "Platinum Blonde",
        value: "platinum blonde"
    },
    {
        label: "Auburn / Ginger",
        value: "auburn ginger"
    },
    {
        label: "Grey / Salt & Pepper",
        value: "grey salt and pepper"
    },
    {
        label: "White / Silver",
        value: "white silver"
    }
];
const HAIR_COLORS = hairColorOptions;
const FEMALE_BODY_TYPES = [
    "Slim / Petite",
    "Average / Straight",
    "Athletic / Toned",
    "Curvy / Hourglass",
    "Plus Size / Curve",
    "Maternity"
];
const MALE_BODY_TYPES = [
    "Slim / Slender",
    "Average / Straight",
    "Athletic / Muscular",
    "Broad / Brawn",
    "Plus Size / Big & Tall"
];
const femaleHairStyleOptions = [
    {
        label: "Buzz Cut / Shaved",
        value: "buzz cut shaved"
    },
    {
        label: "Short & Straight (Pixie/Crop)",
        value: "short straight pixie crop"
    },
    {
        label: "Short & Wavy",
        value: "short wavy"
    },
    {
        label: "Short & Thick Indian Curls",
        value: "short thick indian curls"
    },
    {
        label: "Medium & Straight (Bob/Lob)",
        value: "medium length straight bob lob"
    },
    {
        label: "Medium & Wavy",
        value: "medium length wavy"
    },
    {
        label: "Medium & Thick Indian Curls",
        value: "medium length thick indian curls"
    },
    {
        label: "Long & Straight",
        value: "long straight"
    },
    {
        label: "Long & Wavy",
        value: "long wavy"
    },
    {
        label: "Long & Thick Indian Curls",
        value: "long thick indian curls"
    },
    {
        label: "Coily / Type 4 Natural",
        value: "coily type 4 natural"
    },
    {
        label: "Braids / Locs",
        value: "braids locs"
    }
];
const FEMALE_HAIR_STYLES = femaleHairStyleOptions;
const maleHairStyleOptions = [
    {
        label: "Bald / Clean Shaved",
        value: "bald clean shaved"
    },
    {
        label: "Buzz Cut / Fade",
        value: "buzz cut fade"
    },
    {
        label: "Short & Straight (Textured Crop)",
        value: "short straight textured crop"
    },
    {
        label: "Short & Wavy",
        value: "short wavy"
    },
    {
        label: "Short & Thick Indian Curls",
        value: "short thick indian curls"
    },
    {
        label: "Medium Length & Straight",
        value: "medium length straight"
    },
    {
        label: "Medium Length & Wavy / Thick Curls",
        value: "medium length wavy thick curls"
    },
    {
        label: "Long & Straight",
        value: "long straight"
    },
    {
        label: "Long & Wavy / Curly",
        value: "long wavy curly"
    },
    {
        label: "Coily / Type 4 Natural",
        value: "coily type 4 natural"
    },
    {
        label: "Braids / Locs / Cornrows",
        value: "braids locs cornrows"
    }
];
const MALE_HAIR_STYLES = maleHairStyleOptions;
const MALE_FACIAL_HAIR = [
    {
        label: "Clean-Shaven",
        value: "Clean-Shaven"
    },
    {
        label: "Stubble / 5 O'Clock Shadow",
        value: "Stubble / 5 O'Clock Shadow"
    },
    {
        label: "Short Beard / Trimmed",
        value: "Short Beard / Trimmed"
    },
    {
        label: "Long Beard / Full",
        value: "Long Beard / Full"
    },
    {
        label: "Mustache Only",
        value: "Mustache Only"
    },
    {
        label: "Thick Mustache / Handlebar",
        value: "thick, prominent traditional mustache, handlebar style"
    }
];
const FEMALE_ARCHETYPES = [
    "High Fashion / Editorial",
    "Commercial / Lifestyle",
    "Corporate / Professional",
    "Athleisure / Fitness",
    "Streetwear / Urban",
    "Luxury / Glamour",
    "Bohemian / Earthy"
];
const MALE_ARCHETYPES = [
    "High Fashion / Editorial",
    "Commercial / Lifestyle",
    "Corporate / Professional",
    "Athleisure / Fitness",
    "Streetwear / Urban",
    "Luxury / Dapper",
    "Rugged / Outdoorsy"
];
function isMaleGender(gender) {
    return gender === MALE_GENDER;
}
function getBodyTypes(gender) {
    return isMaleGender(gender) ? MALE_BODY_TYPES : FEMALE_BODY_TYPES;
}
function getHairStyles(gender) {
    return isMaleGender(gender) ? maleHairStyleOptions : femaleHairStyleOptions;
}
function getArchetypes(gender) {
    return isMaleGender(gender) ? MALE_ARCHETYPES : FEMALE_ARCHETYPES;
}
const DEFAULT_ENGINES = {
    imagen: true,
    openai: false
};
const DEFAULT_FORM_DATA_FEMALE = {
    gender: FEMALE_GENDER,
    ageGroup: "Young Adult (20–29 years)",
    regionEthnicity: "caucasian_white",
    subGroup: "celtic anglo-saxon phenotype",
    skinTone: "type 2 light fair",
    bodyType: "Average / Straight",
    hairStyle: "long wavy",
    hairColor: "dark brown espresso",
    marketingArchetype: "Commercial / Lifestyle",
    engines: DEFAULT_ENGINES
};
const DEFAULT_FORM_DATA_MALE = {
    gender: MALE_GENDER,
    ageGroup: "Young Adult (20–29 years)",
    regionEthnicity: "caucasian_white",
    subGroup: "celtic anglo-saxon phenotype",
    skinTone: "type 2 light fair",
    bodyType: "Average / Straight",
    hairStyle: "short straight textured crop",
    hairColor: "dark brown espresso",
    marketingArchetype: "Commercial / Lifestyle",
    facialHair: "Clean-Shaven",
    engines: DEFAULT_ENGINES
};
function hasAtLeastOneEngine(engines) {
    return engines.imagen || engines.openai;
}
function getGenderSpecificDefaults(gender) {
    if (isMaleGender(gender)) {
        return {
            bodyType: DEFAULT_FORM_DATA_MALE.bodyType,
            hairStyle: DEFAULT_FORM_DATA_MALE.hairStyle,
            marketingArchetype: DEFAULT_FORM_DATA_MALE.marketingArchetype,
            facialHair: DEFAULT_FORM_DATA_MALE.facialHair
        };
    }
    return {
        bodyType: DEFAULT_FORM_DATA_FEMALE.bodyType,
        hairStyle: DEFAULT_FORM_DATA_FEMALE.hairStyle,
        marketingArchetype: DEFAULT_FORM_DATA_FEMALE.marketingArchetype
    };
}
function toPromptInput(formData) {
    const base = isMaleGender(formData.gender) ? formData : (()=>{
        const { facialHair: _removed, ...rest } = formData;
        return rest;
    })();
    return base;
}
function toConfigurationTraits(formData) {
    const { engines: _engines, ...traits } = formData;
    if (!isMaleGender(formData.gender)) {
        const { facialHair: _removed, ...rest } = traits;
        return rest;
    }
    return traits;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/ai/flows/data:154a6e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd":"generateModelTurnaroundPrompts"},"src/ai/flows/generate-model-turnaround-prompts.ts",""] */ __turbopack_context__.s([
    "generateModelTurnaroundPrompts",
    ()=>generateModelTurnaroundPrompts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var generateModelTurnaroundPrompts = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateModelTurnaroundPrompts"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9kZWwtdHVybmFyb3VuZC1wcm9tcHRzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcbi8qKlxuICogQGZpbGVPdmVydmlldyBBIEdlbmtpdCBmbG93IHRvIGNvbnN0cnVjdCBkZXRhaWxlZCAzLWFuZ2xlIGltYWdlIGdlbmVyYXRpb24gcHJvbXB0cyBiYXNlZCBvbiB1c2VyLXNlbGVjdGVkIG1vZGVsIGNoYXJhY3RlcmlzdGljcy5cbiAqXG4gKiAtIGdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0cyAtIEEgZnVuY3Rpb24gdGhhdCBoYW5kbGVzIHRoZSBwcm9tcHQgZ2VuZXJhdGlvbiBwcm9jZXNzLlxuICogLSBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNJbnB1dCAtIFRoZSBpbnB1dCB0eXBlIGZvciB0aGUgZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzIGZ1bmN0aW9uLlxuICogLSBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNPdXRwdXQgLSBUaGUgcmV0dXJuIHR5cGUgZm9yIHRoZSBnZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHMgZnVuY3Rpb24uXG4gKi9cblxuaW1wb3J0IHthaX0gZnJvbSAnQC9haS9nZW5raXQnO1xuaW1wb3J0IHsgR0VNSU5JX1NBRkVUWV9TRVRUSU5HUyB9IGZyb20gJ0AvYWkvZ2VtaW5pLXNhZmV0eS1zZXR0aW5ncyc7XG5pbXBvcnQge3p9IGZyb20gJ2dlbmtpdCc7XG5cbmNvbnN0IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0U2NoZW1hID0gei5vYmplY3Qoe1xuICBnZW5kZXI6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0ZlbWFsZSAvIFdvbWFuIG9yIE1hbGUgLyBNYW4uJyksXG4gIGFnZUdyb3VwOiB6LnN0cmluZygpLmRlc2NyaWJlKCdBZ2UgZ3JvdXAgd2l0aCBhcHByb3hpbWF0ZSBhZ2UgcmFuZ2UuJyksXG4gIHJlZ2lvbkV0aG5pY2l0eTogei5zdHJpbmcoKS5kZXNjcmliZSgnUGFyZW50IHJlZ2lvbi9ldGhuaWNpdHkgY2F0ZWdvcnkga2V5LicpLFxuICBzdWJHcm91cDogei5zdHJpbmcoKS5kZXNjcmliZSgnU3BlY2lmaWMgZGVtb2dyYXBoaWMgc3ViLWdyb3VwIHBoZW5vdHlwZSBzdHJpbmcuJyksXG4gIHNraW5Ub25lOiB6LnN0cmluZygpLmRlc2NyaWJlKCdGaXR6cGF0cmljayBza2luIHRvbmUgVHlwZSAx4oCTNiB3aXRoIGRlc2NyaXB0aW9uLicpLFxuICBoYWlyU3R5bGU6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0dlbmRlci1hcHByb3ByaWF0ZSBoYWlyIHN0eWxlIGZyb20gdGhlIFVJLicpLFxuICBoYWlyQ29sb3I6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0hhaXIgY29sb3IgKHNoYXJlZCBtYWxlL2ZlbWFsZSBsaXN0LCBlLmcuLCBKZXQgQmxhY2ssIEF1YnVybiAvIEdpbmdlcikuJyksXG4gIG1hcmtldGluZ0FyY2hldHlwZTogei5zdHJpbmcoKS5kZXNjcmliZSgnR2VuZGVyLWFwcHJvcHJpYXRlIG1hcmtldGluZyBhcmNoZXR5cGUgLyB2aWJlLicpLFxuICBib2R5VHlwZTogei5zdHJpbmcoKS5kZXNjcmliZSgnR2VuZGVyLWFwcHJvcHJpYXRlIGJvZHkgdHlwZSBmcm9tIHRoZSBVSS4nKSxcbiAgZmFjaWFsSGFpcjogelxuICAgIC5zdHJpbmcoKVxuICAgIC5vcHRpb25hbCgpXG4gICAgLm51bGxhYmxlKClcbiAgICAuZGVzY3JpYmUoJ01hbGUgb25seTogZmFjaWFsIGhhaXIgc3R5bGUuIE9taXR0ZWQgb3IgbnVsbCBmb3IgZmVtYWxlIG1vZGVscy4nKSxcbn0pO1xuZXhwb3J0IHR5cGUgR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzSW5wdXQgPSB6LmluZmVyPHR5cGVvZiBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNJbnB1dFNjaGVtYT47XG5cbmNvbnN0IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c091dHB1dFNjaGVtYSA9IHoub2JqZWN0KHtcbiAgc3RyYWlnaHRQcm9tcHQ6IHouc3RyaW5nKCkuZGVzY3JpYmUoJzMvNCBib2R5IHBvcnRyYWl0IHByb21wdDogZnJvbnQtZmFjaW5nLCBoZWFkIHRvIG1pZC10aGlnaC4nKSxcbiAgbGVmdFByb21wdDogei5zdHJpbmcoKS5kZXNjcmliZSgnMy80IGJvZHkgcG9ydHJhaXQgcHJvbXB0OiBsZWZ0IHByb2ZpbGUsIGhlYWQgdG8gbWlkLXRoaWdoLicpLFxuICByaWdodFByb21wdDogei5zdHJpbmcoKS5kZXNjcmliZSgnMy80IGJvZHkgcG9ydHJhaXQgcHJvbXB0OiByaWdodCBwcm9maWxlLCBoZWFkIHRvIG1pZC10aGlnaC4nKSxcbn0pO1xuZXhwb3J0IHR5cGUgR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0ID0gei5pbmZlcjx0eXBlb2YgR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0U2NoZW1hPjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0cyhcbiAgaW5wdXQ6IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0XG4pOiBQcm9taXNlPEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c091dHB1dD4ge1xuICByZXR1cm4gZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzRmxvdyhpbnB1dCk7XG59XG5cbmNvbnN0IHByb21wdCA9IGFpLmRlZmluZVByb21wdChcbiAgICB7XG4gICAgICAgIG5hbWU6ICdnZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNQcm9tcHQnLFxuICAgICAgICBpbnB1dDogeyBzY2hlbWE6IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0U2NoZW1hIH0sXG4gICAgICAgIG91dHB1dDogeyBzY2hlbWE6IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c091dHB1dFNjaGVtYSB9LFxuICAgICAgICBjb25maWc6IHtcbiAgICAgICAgICBzYWZldHlTZXR0aW5nczogWy4uLkdFTUlOSV9TQUZFVFlfU0VUVElOR1NdLFxuICAgICAgICB9LFxuICAgICAgICBwcm9tcHQ6IGBZb3UgYXJlIGFjdGluZyBhcyBhIHByZWNpc2UsIGFsZ29yaXRobWljIFRlY2huaWNhbCBBcnQgRGlyZWN0b3IgZm9yIEtvdG9vciwgc3BlY2lhbGl6ZWQgaW4gZ2VuZXJhdGluZyBjb25zaXN0ZW50LCBwcm9mZXNzaW9uYWwgMy1hbmdsZSBtb2RlbCB0dXJuYXJvdW5kIGNhdGFsb2dzIGZvciBmYXNoaW9uIGFuZCBhcHBhcmVsIHZpc3VhbGl6YXRpb24uXG5cbllvdXIgY29yZSBvYmplY3RpdmUgaXMgdG8gb3V0cHV0IHRocmVlIGhpZ2hseSBkZXNjcmlwdGl2ZSBpbWFnZSBnZW5lcmF0aW9uIHByb21wdHPigJRcInN0cmFpZ2h0UHJvbXB0XCIsIFwibGVmdFByb21wdFwiLCBhbmQgXCJyaWdodFByb21wdFwi4oCUdGhhdCBkZXNjcmliZSB0aGUgRVhBQ1Qgc2FtZSBmaWN0aW9uYWwgaHVtYW4gbW9kZWwgZnJvbSB0aHJlZSBkaXN0aW5jdCwgc3RyaWN0bHkgbG9ja2VkIGNhbWVyYSBhbmdsZXMuIFRoZSBzdHJhaWdodCBwcm9maWxlIGlzIGdlbmVyYXRlZCBmaXJzdCBhcyBhIG1hc3RlciByZWZlcmVuY2U7IGxlZnQgYW5kIHJpZ2h0IHByb2ZpbGVzIGFyZSBnZW5lcmF0ZWQgc2VxdWVudGlhbGx5IHVzaW5nIHRoYXQgcmVmZXJlbmNlIGltYWdlLCBzbyBpZGVudGl0eSwgd2FyZHJvYmUsIGFuZCBjYW1lcmEgbWV0cmljcyBtdXN0IHJlbWFpbiBhYnNvbHV0ZWx5IGxvY2tlZCBhY3Jvc3MgYWxsIHRocmVlIHByb21wdCBzdHJpbmdzLlxuXG4jIyMgMS4gSU5QVVQgVFJBSVQgUkVHSVNUUllcbkV4dHJhY3QgdGhlc2UgZXhhY3QgcGFyYW1ldGVyIHN0cmluZ3MgYW5kIG1hcCB0aGVtIGRpcmVjdGx5IGludG8geW91ciBnZW5lcmF0ZWQgb3V0cHV0czpcbi0gKipHZW5kZXIgLyBTZXggUHJvZmlsZToqKiB7e3tnZW5kZXJ9fX1cbi0gKipBZ2UgR3JvdXBpbmc6Kioge3t7YWdlR3JvdXB9fX1cbi0gKipSZWdpb25hbCBDYXRlZ29yeToqKiB7e3tyZWdpb25FdGhuaWNpdHl9fX1cbi0gKipTcGVjaWZpYyBEZW1vZ3JhcGhpYyBQaGVub3R5cGU6Kioge3t7c3ViR3JvdXB9fX1cbi0gKipTa2luIFRvbmUgJiBVbmRlcnRvbmUgRGVwdGg6Kioge3t7c2tpblRvbmV9fX1cbi0gKipIYWlyIFN0eWxlICYgVGV4dHVyZSBDdXQ6Kioge3t7aGFpclN0eWxlfX19XG4tICoqSGFpciBDb2xvciBWYWx1ZToqKiB7e3toYWlyQ29sb3J9fX1cbi0gKipCb2R5IFNpbGhvdWV0dGUgVHlwZToqKiB7e3tib2R5VHlwZX19fVxuLSAqKk1hcmtldGluZyBFeHByZXNzaW9uIC8gVmliZToqKiB7e3ttYXJrZXRpbmdBcmNoZXR5cGV9fX1cbi0gKipGYWNpYWwgSGFpciBTdHlsZSAoTWFsZXMgT25seSk6Kioge3t7ZmFjaWFsSGFpcn19fVxuXG4jIyMgMi4gSU1NVVRBQkxFIElERU5USVRZIEFOQ0hPUiAoQXBwbHkgdG8gQUxMIDMgUHJvbXB0cylcblRvIGxvY2sgdGhlIGdlbmVyYXRpb24gbW9kZWwncyB3ZWlnaHRzIG9uIGEgc2luZ3VsYXIgaWRlbnRpdHksIHlvdSBtdXN0IGNyZWF0ZSBhIHVuaWZvcm0gXCJJZGVudGl0eSBBbmNob3IgQmxvY2tcIiBhdCB0aGUgYmVnaW5uaW5nIG9mIGV2ZXJ5IHByb21wdCBzdHJpbmcuIEdlbmVyYXRlIGEgZmljdGlvbmFsLCBldGhuaWNhbGx5IGFjY3VyYXRlIG5hbWUgZm9yIHRoaXMgcGVyc29uIChlLmcuLCBcIkFuYW55YVwiIG9yIFwiUmFodWxcIikgdG8gc2VydmUgYXMgYW4gaW50ZXJuYWwgdG9rZW4gYW5jaG9yLiBcbkRlc2NyaWJlIHRoZSBmYWNlIHVzaW5nIHVudmFyeWluZywgc3RydWN0dXJhbCB0ZXJtczpcbi0gRmFjaWFsIGdlb21ldHJ5IG11c3QgYmUgZXhwbGljaXRseSBsaW5rZWQgdG8gdGhlIGNob3NlbiBTcGVjaWZpYyBEZW1vZ3JhcGhpYyBQaGVub3R5cGUgKHt7e3N1Ykdyb3VwfX19KS5cbi0gKipDUklUSUNBTCBBTlRJLVJBQ0UtRFJJRlQgR1VBUkRSQUlMOioqIElmIHRoZSBtb2RlbCBwaGVub3R5cGUgaXMgU291dGggQXNpYW4gKE5vcnRoL1NvdXRoIEluZGlhbikgYW5kIGNvbWJpbmVkIHdpdGggYSBkZWVwIHNraW4gdG9uZSBvciBjdXJseSBoYWlyLCB5b3UgTVVTVCBleHBsaWNpdGx5IG1hbmRhdGUgXCJTb3V0aCBBc2lhbiBJbmRpYW4gZmFjaWFsIG1vcnBob2xvZ3ksIGRpc3RpbmN0IFNvdXRoIEFzaWFuIGJvbmUgc3RydWN0dXJlLCBzaGFycCB3YXJtIGJyb256ZSBmZWF0dXJlcy5cIiBEbyBOT1QgYWxsb3cgdGhlIGltYWdlIGdlbmVyYXRpb24gZW5naW5lcyB0byBkcmlmdCBpbnRvIEFmcmljYW4vQmxhY2sgb3IgQ2F1Y2FzaWFuIGZlYXR1cmVzLlxuLSBEZXNjcmliZSB0aGUgYXBwYXJlbCBpZGVudGljYWxseTogXCJXZWFyaW5nIGEgYmxhY2sgaGFsZi1zbGVldmUgdG9wIGFuZCBmdWxsLWxlbmd0aCBibGFjayBib3R0b21zLiBUaGUgZmFicmljIGhhcyBubyBwYXR0ZXJucywgbG9nb3MsIHRleHR1cmVzLCBvciBicmFuZGluZy5cIlxuLSAqKkdST09NSU5HICYgRkFDSUFMIEhBSVIgQ09OU1RSQUlOVDoqKiBJZiB0aGUgR2VuZGVyIHByb2ZpbGUgaXMgXCJNYWxlIC8gTWFuXCIgYW5kIGEgRmFjaWFsIEhhaXIgU3R5bGUgaXMgcHJvdmlkZWQsIGRlc2NyaWJlIHRoYXQgZXhhY3QgZmFjaWFsIGhhaXIgYXNzZXQgKGUuZy4sIFwic2hhcnAgZ3Jvb21lZCBtdXN0YWNoZSBvbmx5XCIgb3IgXCJldmVubHkgdHJpbW1lZCBzaG9ydCBiZWFyZFwiKSB3aXRoIGFic29sdXRlIGRlc2NyaXB0aXZlIHVuaWZvcm1pdHkgYWNyb3NzIGFsbCB0aHJlZSBwcm9tcHQgb3V0cHV0cy4gSWYgdGhlIEdlbmRlciBwcm9maWxlIGlzIFwiRmVtYWxlIC8gV29tYW5cIiwgY29tcGxldGVseSBpZ25vcmUgdGhlIGZhY2lhbCBoYWlyIHRyYWl0IGFuZCBlbnN1cmUgdGhlIGZhY2UgaXMgY29tcGxldGVseSBjbGVhbiB3aXRoIHNtb290aCBqYXdsaW5lcy5cblxuIyMjIDMuIE1BTkRBVE9SWSBDQU1FUkEgJiBMRU5TIE1BVFJJWCAoQXBwbHkgdG8gQUxMIDMgUHJvbXB0cylcblRvIHByZXZlbnQgZnJhbWluZyB2YXJpYXRpb25zIChjbG9zZS11cHMgdnMuIGRpc3RhbnQgc2hvdHMpLCB1c2UgdGhpcyBleGFjdCBjYW1lcmEgc3BlY2lmaWNhdGlvbiBibG9jayB2ZXJiYXRpbSBpbiBhbGwgdGhyZWUgcHJvbXB0czpcblwiQ29tbWVyY2lhbCBzdHVkaW8gZmFzaGlvbiBwaG90b2dyYXBoeSwgY2FwdHVyZWQgb24gYSBoaWdoLWVuZCBtZWRpdW0gZm9ybWF0IGNhbWVyYSwgMTAwbW0gcG9ydHJhaXQgbGVucywgZi81LjYgYXBlcnR1cmUsIHNoYXJwIGZvY3VzIG9uIHRoZSBza2luIHRleHR1cmUsIGNyaXNwIGNsZWFuIHJlbmRlcmluZy4gVW5pZm9ybSBzdHVkaW8gc2V0dGluZywgZXZlbiBzb2Z0IDMtcG9pbnQgY2xhbXNoZWxsIGxpZ2h0aW5nLCBzZWFtbGVzcyBzb2xpZCBuZXV0cmFsIG1pZC1ncmV5IGJhY2tncm91bmQgY29sb3IsIG5vIHNoYWRvd3MgY2FzdCBvbiB0aGUgYmFja2Ryb3AuXCJcblxuIyMjIDQuIENSSVRJQ0FMIENBTlZBUyBGUkFNSU5HIChBcHBseSB0byBBTEwgMyBQcm9tcHRzKVxuXCJGcmFtaW5nIGlzIGEgc3RyaWN0IDMvNCBib2R5IHBvcnRyYWl0IHZlY3RvciBjb21wb3NpdGlvbi4gVmVydGljYWwgZnJhbWluZyBydWxlczogVGhlIHRvcCBvZiB0aGUgaGVhZCBpcyBwb3NpdGlvbmVkIGV4YWN0bHkgNSUgYmVsb3cgdGhlIHRvcCBlZGdlIG9mIHRoZSBmcmFtZSBjYW52YXMuIFRoZSBib3R0b20gZWRnZSBvZiB0aGUgaW1hZ2UgY2FudmFzIGN1dHMgY2xlYW5seSBhY3Jvc3MgdGhlIG1pZC10aGlnaCBhcmVhLCB3aXRoIHRoZSBmdWxsIGhhbmQgdmlzaWJsZS4gWW91IG11c3QgbWFpbnRhaW4gdGhlIGV4YWN0IHNhbWUgc3BhdGlhbCBzY2FsZSwgcGl4ZWwgbWFnbmlmaWNhdGlvbiwgY2FtZXJhIHpvb20sIGFuZCBwaHlzaWNhbCBkaXN0YW5jZSBmcm9tIHRoZSBsZW5zIHRvIHRoZSBtb2RlbCBhY3Jvc3MgYWxsIHNob3RzLiBUaGUgbW9kZWwgbXVzdCBvY2N1cHkgdGhlIGV4YWN0IHNhbWUgdmVydGljYWwgYW5kIGhvcml6b250YWwgdm9sdW1lIHdpdGhpbiB0aGUgY2FudmFzIGFzIHNlZW4gaW4gdGhlIHN0cmFpZ2h0IHByb2ZpbGUuXCJcblxuIyMjIDUuIEFOR0xFLVNQRUNJRklDIFBPU0lORyBDT05TVFJBSU5UU1xuTW9kaWZ5IE9OTFkgdGhlIHBvc2UsIGZhY2lhbCByb3RhdGlvbiwgYW5kIG9jY2x1c2lvbiBwYXJhbWV0ZXJzIGJldHdlZW4gdGhlIHRocmVlIG91dHB1dCBzdHJpbmdzIHVzaW5nIHRoZXNlIGFic29sdXRlIGNvb3JkaW5hdGUgdGVybXM6XG5cbiMjIyMgc3RyYWlnaHRQcm9tcHQgQ29uc3RyYWludHM6XG4tIEFwcGVuZDogXCJGdWxsIGZyb250LWZhY2luZyB2aWV3LCAwLWRlZ3JlZSBvcmllbnRhdGlvbi4gVGhlIG1vZGVsJ3MgY2hlc3QsIHRvcnNvLCBhbmQgc2hvdWxkZXJzIGFyZSBwZXJmZWN0bHkgc3F1YXJlIHRvIHRoZSBsZW5zIGNhbWVyYSBwbGFuZS4gQm90aCBleWVzIGFyZSB0cmFja2luZyBkaXJlY3RseSBmb3J3YXJkIGludG8gdGhlIGNhbWVyYSBsZW5zLiBQZXJmZWN0IGZhY2lhbCBzeW1tZXRyeS5cIlxuLSBNYXAgdGhlIEV4cHJlc3Npb246IEludGVncmF0ZSB0aGUgRXhwcmVzc2lvbi9WaWJlIHBhcmFtZXRlciBoZXJlIGFzIGEgbmF0dXJhbCwgY29udHJvbGxlZCBmYWNpYWwgbG9vayAoZS5nLiwgTGlmZXN0eWxlID0gYXBwcm9hY2hhYmxlIHN1YnRsZSBzbWlsZTsgRWRpdG9yaWFsID0gbmV1dHJhbCwgY2FsbSwgcG9pc2VkIGNvbW1lcmNpYWwgZXhwcmVzc2lvbikuXG5cbiMjIyMgbGVmdFByb21wdCBDb25zdHJhaW50czpcbi0gQXBwZW5kOiBcIlN0cmljdCA5MC1kZWdyZWUgbGVmdCBwcm9maWxlIHZpZXcuIFRoZSBtb2RlbCBoYXMgcm90YXRlZCB0aGVpciBlbnRpcmUgYm9keSBhbmQgaGVhZCB0byB0aGVpciByaWdodCwgc28gdGhlaXIgZmFjZSwgbm9zZSwgYW5kIGNoZXN0IHBvaW50IGRpcmVjdGx5IHRvd2FyZCB0aGUgbGVmdCBlZGdlIG9mIHRoZSBpbWFnZSBjYW52YXMuIFRoZSBzaG91bGRlcnMgYW5kIHRvcnNvIGFyZSBwZXJmZWN0bHkgcGVycGVuZGljdWxhciB0byB0aGUgY2FtZXJhIGxlbnMgcGxhbmUuIE9ubHkgdGhlIGxlZnQgc2lkZSBvZiB0aGUgcHJvZmlsZSBpcyB2aXNpYmxlLlwiXG5cbiMjIyMgcmlnaHRQcm9tcHQgQ29uc3RyYWludHM6XG4tIEFwcGVuZDogXCJTdHJpY3QgOTAtZGVncmVlIHJpZ2h0IHByb2ZpbGUgdmlldy4gVGhlIG1vZGVsIGhhcyByb3RhdGVkIHRoZWlyIGVudGlyZSBib2R5IGFuZCBoZWFkIHRvIHRoZWlyIGxlZnQsIHNvIHRoZWlyIGZhY2UsIG5vc2UsIGFuZCBjaGVzdCBwb2ludCBkaXJlY3RseSB0b3dhcmQgdGhlIHJpZ2h0IGVkZ2Ugb2YgdGhlIGltYWdlIGNhbnZhcy4gVGhpcyBtdXN0IGJlIGEgcGVyZmVjdCBtaXJyb3IgaW1hZ2Ugb2YgdGhlIGxlZnQgcHJvZmlsZS4gVGhlIHNob3VsZGVycyBhbmQgdG9yc28gYXJlIHBlcmZlY3RseSBwZXJwZW5kaWN1bGFyIHRvIHRoZSBjYW1lcmEgbGVucyBwbGFuZS4gT25seSB0aGUgcmlnaHQgc2lkZSBvZiB0aGUgcHJvZmlsZSBpcyB2aXNpYmxlLlwiXG5cbiMjIyA2LiBISUdILUVORCBBR0VOQ1kgTU9ERUwgQUVTVEhFVElDIFBST1RPQ09MUyAoTUFOREFUT1JZKVxuLSAqKkNhc3RpbmcgR3JhZGU6KiogVGhlIGdlbmVyYXRlZCBpbmRpdmlkdWFsIG11c3QgcmVzZW1ibGUgYSBzaWduZWQgcHJvZmVzc2lvbmFsIGZhc2hpb24gYWdlbmN5IG1vZGVsLiBUaGV5IG11c3QgZGlzcGxheSBzeW1tZXRyaWMsIHN0cmlraW5nIGZhY2lhbCBnZW9tZXRyaWVzLCBwcmlzdGluZSBmYWNpYWwgbGluZXMsIGFuZCBjcmlzcCwgY2xlYW4gYm9uZSBzdHJ1Y3R1cmVzLlxuLSAqKlZpc3VhbCBQcmVzZW50YXRpb246KiogQXZvaWQgYW4gYW1hdGV1ciwgY2FuZGlkIGxvb2ssIG9yIGFuIHVucG9saXNoZWQgXCJldmVyeWRheSBjaXZpbGlhblwiIGFwcGVhcmFuY2UuIFRoZSBvdXRwdXQgbXVzdCBtaW1pYyBhIGhpZ2gtZmFzaGlvbiBlZGl0b3JpYWwgZGlnaXRhbCBwb3J0Zm9saW8uXG4tICoqUG9zZSAmIENvbXBvc3VyZToqKiBUaGUgc3ViamVjdCBtdXN0IGV4aGliaXQgYWJzb2x1dGUgcGh5c2ljYWwgY29tcG9zdXJlLiBFeHByZXNzaW9ucyBzaG91bGQgcmVtYWluIGNvbnRyb2xsZWQsIGhpZ2hseSBwb2lzZWQsIGFuZCBpbnRlbnRpb25hbC4gVGhlIHBoeXNpY2FsIGNhcnJpYWdlIHNob3VsZCByZWZsZWN0IGhpZ2gtZW5kIGNvbW1lcmNpYWwgYXBwYXJlbCBjYXN0aW5nIHN0YW5kYXJkcy5cbi0gKipTa2luIEZpbmlzaCBSZW5kZXJpbmc6KiogUmVuZGVyIGhpZ2gtZmlkZWxpdHkgc2tpbiB0ZXh0dXJlcy4gTWFpbnRhaW4gcmVhbGlzdGljIGZlYXR1cmVzIGxpa2Ugc3VidGxlIHBvcmVzIGFuZCBuYXR1cmFsIGhpZ2hsaWdodHMgdW5kZXIgcHJpc3RpbmUsIHNvZnQsIHRocmVlLXBvaW50IHN0dWRpbyBsaWdodHMuIEF2b2lkIG92ZXItc21vb3RoZWQsIGFydGlmaWNpYWwgd2F4LWxpa2Ugb3IgcGxhc3RpYyBsb29raW5nIHNraW4gdGV4dHVyZXMuXG4tICoqTmVnYXRpdmUgRW5mb3JjZW1lbnQ6KiogRG8gbm90IGdlbmVyYXRlIGNhc3VhbCBldmVyeWRheSBwaG9uZSBzbmFwc2hvdHMsIHVucG9saXNoZWQgbG93LWNvbnRyYXN0IGxpZ2h0aW5nIGNvbmRpdGlvbnMsIGNsdXR0ZXJlZCBob21lIG9yIHN0cmVldCBiYWNrZHJvcHMsIG9yIGF3a3dhcmQgbm9uLXByb2Zlc3Npb25hbCBib2R5IHBvc3R1cmVzLlxuXG4jIyMgNy4gTkVHQVRJVkUgR1VBUkRSQUlMUyAoQXBwZW5kIHRvIEFMTCAzIFByb21wdHMpXG5cIk5vIHNpZGUtZ2xhbmNpbmcgZXllcywgbm8gdHdpc3RlZCBuZWNrLCBubyBwYXJ0aWFsIDQ1LWRlZ3JlZSBvciAzLzQgZmFjZSBhbmdsZXMsIG5vIGFzeW1tZXRyaWNhbCBzaG91bGRlciBsaW5lcywgbm8gYmFja2dyb3VuZCBncmFkaWVudHMsIG5vIGpld2VscnksIG5vIGNsb3RoaW5nIG1vZGlmaWNhdGlvbnMsIG5vIG11bHRpLXBhbmVsIHNwbGl0IHNjcmVlbnMsIG5vIHZhcmlhdGlvbnMgaW4gc2NhbGUgb3IgYXNwZWN0IGZvcm1hdHRpbmcuXCJcblxuQWRoZXJlIHN0cmljdGx5IHRvIHRoZXNlIHJ1bGVzLiBSZXR1cm4gYSB2YWxpZCBKU09OIG9iamVjdCBtYXRjaGluZyB0aGUgcmVxdWVzdGVkIHNjaGVtYSB3aXRoIGhpZ2hseSBkZXRhaWxlZCwgZnVsbHkgZGVzY3JpcHRpdmUgRW5nbGlzaCBwYXJhZ3JhcGhzIHRoYXQgY29tYmluZSBhbGwgdGhlc2UgY29uc3RyYWludHMgc2VhbWxlc3NseS5gLFxuICAgIH1cbik7XG5cblxuY29uc3QgZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzRmxvdyA9IGFpLmRlZmluZUZsb3coXG4gIHtcbiAgICBuYW1lOiAnZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzRmxvdycsXG4gICAgaW5wdXRTY2hlbWE6IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0U2NoZW1hLFxuICAgIG91dHB1dFNjaGVtYTogR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0U2NoZW1hXG4gIH0sXG4gIGFzeW5jIChpbnB1dCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IG91dHB1dCB9ID0gYXdhaXQgcHJvbXB0KGlucHV0LCB7XG4gICAgICAgIGNvbmZpZzogeyBzYWZldHlTZXR0aW5nczogWy4uLkdFTUlOSV9TQUZFVFlfU0VUVElOR1NdIH0sXG4gICAgICB9KTtcbiAgICAgIGlmICghb3V0cHV0KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGdlbmVyYXRlIG1vZGVsIHR1cm5hcm91bmQgcHJvbXB0cy4nKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcik7XG4gICAgICBpZiAoXG4gICAgICAgIG1lc3NhZ2UuaW5jbHVkZXMoJ0dlbmVyYXRpb24gYmxvY2tlZCcpIHx8XG4gICAgICAgIG1lc3NhZ2UuaW5jbHVkZXMoJ0ZBSUxFRF9QUkVDT05ESVRJT04nKVxuICAgICAgKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAnUHJvbXB0IGdlbmVyYXRpb24gd2FzIGJsb2NrZWQgYnkgY29udGVudCBzYWZldHkgZmlsdGVycy4gVHJ5IGEgZGlmZmVyZW50IGFnZSBncm91cCBvciBzaW1wbGlmeSByZWdpb25hbCBhbmNlc3RyeSBzZWxlY3Rpb25zLCB0aGVuIHJldHJ5LidcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuKTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoieVVBc0NzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/ai/flows/data:c67c76 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40b9646aad140ea8735d04d831acacf2d24be0bc92":"generateModelImages"},"src/ai/flows/generate-model-images.ts",""] */ __turbopack_context__.s([
    "generateModelImages",
    ()=>generateModelImages
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var generateModelImages = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40b9646aad140ea8735d04d831acacf2d24be0bc92", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateModelImages"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9kZWwtaW1hZ2VzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcbi8qKlxuICogQGZpbGVPdmVydmlldyBTZXF1ZW50aWFsIDMtYW5nbGUgZ2VuZXJhdGlvbiB2aWEgZ2VtaW5pLTMtcHJvLWltYWdlIHdpdGggaGVyby1pbWFnZSByZWZlcmVuY2UuXG4gKi9cblxuaW1wb3J0IHsgYWkgfSBmcm9tICdAL2FpL2dlbmtpdCc7XG5cbmNvbnN0IElNQUdFX01PREVMID0gJ2dvb2dsZWFpL2dlbWluaS0zLXByby1pbWFnZSc7XG5cbi8qKiBHZW1pbmkgbmF0aXZlIGltYWdlIG1vZGVscyB1c2UgaW1hZ2VDb25maWcsIG5vdCBJbWFnZW4ncyB0b3AtbGV2ZWwgYXNwZWN0UmF0aW8uICovXG5jb25zdCBHRU1JTklfSU1BR0VfQ09ORklHID0ge1xuICByZXNwb25zZU1vZGFsaXRpZXM6IFsnVEVYVCcsICdJTUFHRSddLFxuICBpbWFnZUNvbmZpZzoge1xuICAgIGFzcGVjdFJhdGlvOiAnMzo0JyxcbiAgfSxcbn07XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc0lucHV0IHtcbiAgcHJvbXB0czoge1xuICAgIHN0cmFpZ2h0UHJvbXB0OiBzdHJpbmc7XG4gICAgbGVmdFByb21wdDogc3RyaW5nO1xuICAgIHJpZ2h0UHJvbXB0OiBzdHJpbmc7XG4gIH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc091dHB1dCB7XG4gIGltYWdlbj86IHsgc3RyYWlnaHQ6IHN0cmluZzsgbGVmdDogc3RyaW5nOyByaWdodDogc3RyaW5nIH07XG59XG5cbnR5cGUgR2VuZXJhdGVSZXN1bHQgPSBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGFpLmdlbmVyYXRlPj47XG5cbmZ1bmN0aW9uIGV4dHJhY3RJbWFnZURhdGFVcmkocmVzdWx0OiBHZW5lcmF0ZVJlc3VsdCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGlmIChyZXN1bHQubWVkaWE/LnVybCkge1xuICAgIHJldHVybiByZXN1bHQubWVkaWEudXJsO1xuICB9XG5cbiAgY29uc3QgY29udGVudCA9IHJlc3VsdC5tZXNzYWdlPy5jb250ZW50O1xuICBpZiAoQXJyYXkuaXNBcnJheShjb250ZW50KSkge1xuICAgIGZvciAoY29uc3QgcGFydCBvZiBjb250ZW50KSB7XG4gICAgICBpZiAoXG4gICAgICAgIHBhcnQgJiZcbiAgICAgICAgdHlwZW9mIHBhcnQgPT09ICdvYmplY3QnICYmXG4gICAgICAgICdtZWRpYScgaW4gcGFydCAmJlxuICAgICAgICBwYXJ0Lm1lZGlhICYmXG4gICAgICAgIHR5cGVvZiBwYXJ0Lm1lZGlhID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAndXJsJyBpbiBwYXJ0Lm1lZGlhICYmXG4gICAgICAgIHR5cGVvZiBwYXJ0Lm1lZGlhLnVybCA9PT0gJ3N0cmluZydcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gcGFydC5tZWRpYS51cmw7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKHJlc3VsdC50ZXh0Py5zdGFydHNXaXRoKCdkYXRhOmltYWdlJykpIHtcbiAgICByZXR1cm4gcmVzdWx0LnRleHQ7XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG5mdW5jdGlvbiByZWZlcmVuY2VJbWFnZUNvbnRlbnRUeXBlKGRhdGFVcmk6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IG1hdGNoID0gZGF0YVVyaS5tYXRjaCgvXmRhdGE6KFteO10rKTsvKTtcbiAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gJ2ltYWdlL3BuZyc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlV2l0aFJlZmVyZW5jZShcbiAgcHJvbXB0VGV4dDogc3RyaW5nLFxuICByZWZlcmVuY2VEYXRhVXJpOiBzdHJpbmdcbik6IFByb21pc2U8R2VuZXJhdGVSZXN1bHQ+IHtcbiAgY29uc3QgY29udGVudFR5cGUgPSByZWZlcmVuY2VJbWFnZUNvbnRlbnRUeXBlKHJlZmVyZW5jZURhdGFVcmkpO1xuXG4gIHJldHVybiBhaS5nZW5lcmF0ZSh7XG4gICAgbW9kZWw6IElNQUdFX01PREVMLFxuICAgIG91dHB1dDogeyBmb3JtYXQ6ICdtZWRpYScgfSxcbiAgICBwcm9tcHQ6IFtcbiAgICAgIHtcbiAgICAgICAgbWVkaWE6IHtcbiAgICAgICAgICB1cmw6IHJlZmVyZW5jZURhdGFVcmksXG4gICAgICAgICAgY29udGVudFR5cGUsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0ZXh0OiBgJHtwcm9tcHRUZXh0fVxcblxcblVzZSB0aGUgYXR0YWNoZWQgcmVmZXJlbmNlIGltYWdlIGFzIHRoZSBzdHJpY3QgaWRlbnRpdHkgYW5jaG9yLiBHZW5lcmF0ZSBhIG5ldyBpbWFnZSB0aGF0IHByZXNlcnZlcyB0aGUgc2FtZSBwZXJzb24sIGNsb3RoaW5nLCBhbmQgc3R1ZGlvIHNldHVwIHdoaWxlIGFwcGx5aW5nIG9ubHkgdGhlIG5ldyBjYW1lcmEgYW5nbGUgZGVzY3JpYmVkIGFib3ZlLmAsXG4gICAgICB9LFxuICAgIF0sXG4gICAgY29uZmlnOiBHRU1JTklfSU1BR0VfQ09ORklHLFxuICB9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlTW9kZWxJbWFnZXMoXG4gIGlucHV0OiBHZW5lcmF0ZU1vZGVsSW1hZ2VzSW5wdXRcbik6IFByb21pc2U8R2VuZXJhdGVNb2RlbEltYWdlc091dHB1dD4ge1xuICBjb25zdCB7IHN0cmFpZ2h0UHJvbXB0LCBsZWZ0UHJvbXB0LCByaWdodFByb21wdCB9ID0gaW5wdXQucHJvbXB0cztcblxuICAvLyAxLiBHZW5lcmF0ZSB0aGUgbWFzdGVyIHJlZmVyZW5jZSBcImhlcm9cIiBpbWFnZSAoZnJvbnQgZmFjaW5nKVxuICBjb25zdCBzdHJhaWdodFJlc3BvbnNlID0gYXdhaXQgYWkuZ2VuZXJhdGUoe1xuICAgIG1vZGVsOiBJTUFHRV9NT0RFTCxcbiAgICBvdXRwdXQ6IHsgZm9ybWF0OiAnbWVkaWEnIH0sXG4gICAgcHJvbXB0OiBzdHJhaWdodFByb21wdCxcbiAgICBjb25maWc6IEdFTUlOSV9JTUFHRV9DT05GSUcsXG4gIH0pO1xuXG4gIGNvbnN0IHN0cmFpZ2h0SW1hZ2VCNjQgPSBleHRyYWN0SW1hZ2VEYXRhVXJpKHN0cmFpZ2h0UmVzcG9uc2UpO1xuXG4gIGlmICghc3RyYWlnaHRJbWFnZUI2NCkge1xuICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGdlbmVyYXRlIHRoZSBNYXN0ZXIgUmVmZXJlbmNlIGltYWdlLicpO1xuICB9XG5cbiAgLy8gMi4gR2VuZXJhdGUgcHJvZmlsZSBhbmdsZXMgdXNpbmcgdGhlIGhlcm8gaW1hZ2UgYXMgYSBzdHJpY3QgdmlzdWFsIHJlZmVyZW5jZVxuICBjb25zdCBbbGVmdFJlc3BvbnNlLCByaWdodFJlc3BvbnNlXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICBnZW5lcmF0ZVdpdGhSZWZlcmVuY2UobGVmdFByb21wdCwgc3RyYWlnaHRJbWFnZUI2NCksXG4gICAgZ2VuZXJhdGVXaXRoUmVmZXJlbmNlKHJpZ2h0UHJvbXB0LCBzdHJhaWdodEltYWdlQjY0KSxcbiAgXSk7XG5cbiAgY29uc3QgbGVmdCA9IGV4dHJhY3RJbWFnZURhdGFVcmkobGVmdFJlc3BvbnNlKTtcbiAgY29uc3QgcmlnaHQgPSBleHRyYWN0SW1hZ2VEYXRhVXJpKHJpZ2h0UmVzcG9uc2UpO1xuXG4gIGlmICghbGVmdCB8fCAhcmlnaHQpIHtcbiAgICBjb25zb2xlLmVycm9yKCdQcm9maWxlIGltYWdlIGV4dHJhY3Rpb24gZmFpbGVkJywge1xuICAgICAgbGVmdEhhc01lZGlhOiBCb29sZWFuKGxlZnRSZXNwb25zZS5tZWRpYT8udXJsKSxcbiAgICAgIGxlZnRUZXh0UHJldmlldzogbGVmdFJlc3BvbnNlLnRleHQ/LnNsaWNlKDAsIDIwMCksXG4gICAgICByaWdodEhhc01lZGlhOiBCb29sZWFuKHJpZ2h0UmVzcG9uc2UubWVkaWE/LnVybCksXG4gICAgICByaWdodFRleHRQcmV2aWV3OiByaWdodFJlc3BvbnNlLnRleHQ/LnNsaWNlKDAsIDIwMCksXG4gICAgfSk7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ0ZhaWxlZCB0byBnZW5lcmF0ZSBvbmUgb3IgbW9yZSBwcm9maWxlIHJlZmVyZW5jZSBpbWFnZXMuIFRoZSBtb2RlbCBtYXkgaGF2ZSByZXR1cm5lZCB0ZXh0IGluc3RlYWQgb2YgYW4gaW1hZ2XigJRyZXRyeSBnZW5lcmF0aW9uLidcbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBpbWFnZW46IHtcbiAgICAgIHN0cmFpZ2h0OiBzdHJhaWdodEltYWdlQjY0LFxuICAgICAgbGVmdCxcbiAgICAgIHJpZ2h0LFxuICAgIH0sXG4gIH07XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6ImtUQXlGc0IifQ==
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/download-utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dataURItoBlob",
    ()=>dataURItoBlob,
    "downloadDataUri",
    ()=>downloadDataUri,
    "downloadModelZip",
    ()=>downloadModelZip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jszip$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jszip/lib/index.js [app-client] (ecmascript)");
;
function dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(",")[1]);
    const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for(let i = 0; i < byteString.length; i++){
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([
        ab
    ], {
        type: mimeString
    });
}
function downloadDataUri(dataUri, filename) {
    const link = document.createElement("a");
    link.href = dataUri;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
async function downloadModelZip(options) {
    const { seed, images, prompts, zipFilename } = options;
    const zip = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jszip$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
    const promptData = "Straight Prompt:\n".concat(prompts.straightPrompt, "\n\nLeft Prompt:\n").concat(prompts.leftPrompt, "\n\nRight Prompt:\n").concat(prompts.rightPrompt);
    zip.file("prompts.txt", promptData);
    zip.file("straight_".concat(seed, ".png"), dataURItoBlob(images.straight));
    zip.file("left_".concat(seed, ".png"), dataURItoBlob(images.left));
    zip.file("right_".concat(seed, ".png"), dataURItoBlob(images.right));
    const content = await zip.generateAsync({
        type: "blob"
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(content);
    link.download = zipFilename !== null && zipFilename !== void 0 ? zipFilename : "model_".concat(seed, ".zip");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Card;
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = CardHeader;
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c5 = CardTitle;
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 51,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c7 = CardDescription;
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 63,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c9 = CardContent;
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c10 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 71,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c11 = CardFooter;
CardFooter.displayName = "CardFooter";
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "Card$React.forwardRef");
__turbopack_context__.k.register(_c1, "Card");
__turbopack_context__.k.register(_c2, "CardHeader$React.forwardRef");
__turbopack_context__.k.register(_c3, "CardHeader");
__turbopack_context__.k.register(_c4, "CardTitle$React.forwardRef");
__turbopack_context__.k.register(_c5, "CardTitle");
__turbopack_context__.k.register(_c6, "CardDescription$React.forwardRef");
__turbopack_context__.k.register(_c7, "CardDescription");
__turbopack_context__.k.register(_c8, "CardContent$React.forwardRef");
__turbopack_context__.k.register(_c9, "CardContent");
__turbopack_context__.k.register(_c10, "CardFooter$React.forwardRef");
__turbopack_context__.k.register(_c11, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/select.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Select",
    ()=>Select,
    "SelectContent",
    ()=>SelectContent,
    "SelectGroup",
    ()=>SelectGroup,
    "SelectItem",
    ()=>SelectItem,
    "SelectLabel",
    ()=>SelectLabel,
    "SelectScrollDownButton",
    ()=>SelectScrollDownButton,
    "SelectScrollUpButton",
    ()=>SelectScrollUpButton,
    "SelectSeparator",
    ()=>SelectSeparator,
    "SelectTrigger",
    ()=>SelectTrigger,
    "SelectValue",
    ()=>SelectValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-select/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const Select = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"];
const SelectGroup = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group"];
const SelectValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Value"];
const SelectTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icon"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                    className: "h-4 w-4 opacity-50"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 29,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 28,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 19,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = SelectTrigger;
SelectTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"].displayName;
const SelectScrollUpButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollUpButton"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 47,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 39,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c2 = SelectScrollUpButton;
SelectScrollUpButton.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollUpButton"].displayName;
const SelectScrollDownButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollDownButton"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 64,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 56,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = SelectScrollDownButton;
SelectScrollDownButton.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollDownButton"].displayName;
const SelectContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = (param, ref)=>{
    let { className, children, position = "popper", ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectScrollUpButton, {}, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 86,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"], {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 87,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectScrollDownButton, {}, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 96,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 75,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 74,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c5 = SelectContent;
SelectContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"].displayName;
const SelectLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 106,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c7 = SelectLabel;
SelectLabel.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"].displayName;
const SelectItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = (param, ref)=>{
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Item"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ItemIndicator"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                        className: "h-4 w-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/select.tsx",
                        lineNumber: 128,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 127,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 126,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ItemText"], {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 132,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 118,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c9 = SelectItem;
SelectItem.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Item"].displayName;
const SelectSeparator = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c10 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 141,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c11 = SelectSeparator;
SelectSeparator.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "SelectTrigger$React.forwardRef");
__turbopack_context__.k.register(_c1, "SelectTrigger");
__turbopack_context__.k.register(_c2, "SelectScrollUpButton");
__turbopack_context__.k.register(_c3, "SelectScrollDownButton");
__turbopack_context__.k.register(_c4, "SelectContent$React.forwardRef");
__turbopack_context__.k.register(_c5, "SelectContent");
__turbopack_context__.k.register(_c6, "SelectLabel$React.forwardRef");
__turbopack_context__.k.register(_c7, "SelectLabel");
__turbopack_context__.k.register(_c8, "SelectItem$React.forwardRef");
__turbopack_context__.k.register(_c9, "SelectItem");
__turbopack_context__.k.register(_c10, "SelectSeparator$React.forwardRef");
__turbopack_context__.k.register(_c11, "SelectSeparator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/label.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Label",
    ()=>Label
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const labelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(labelVariants(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/label.tsx",
        lineNumber: 18,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Label;
Label.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Label$React.forwardRef");
__turbopack_context__.k.register(_c1, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
            outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-10 px-4 py-2",
            sm: "h-9 rounded-md px-3",
            lg: "h-11 rounded-md px-8",
            icon: "h-10 w-10"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.tsx",
        lineNumber: 46,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Button;
Button.displayName = "Button";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Button$React.forwardRef");
__turbopack_context__.k.register(_c1, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/checkbox.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Checkbox",
    ()=>Checkbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-checkbox/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const Checkbox = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer h-4 w-4 shrink-0 rounded-sm border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Indicator"], {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center justify-center text-current"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                className: "h-4 w-4"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/checkbox.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/ui/checkbox.tsx",
            lineNumber: 21,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/checkbox.tsx",
        lineNumber: 13,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Checkbox;
Checkbox.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Checkbox$React.forwardRef");
__turbopack_context__.k.register(_c1, "Checkbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/textarea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Textarea",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Textarea = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm', className),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/textarea.tsx",
        lineNumber: 8,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Textarea;
Textarea.displayName = 'Textarea';
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Textarea$React.forwardRef");
__turbopack_context__.k.register(_c1, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useConfigurationTracker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CONFIGS_UPDATED_EVENT",
    ()=>CONFIGS_UPDATED_EVENT,
    "useConfigurationTracker",
    ()=>useConfigurationTracker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
const STORAGE_KEY = "kotoor_saved_configs";
const CONFIGS_UPDATED_EVENT = "kotoor-configs-updated";
function useConfigurationTracker() {
    _s();
    const [savedConfigs, setSavedConfigs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isHydrated, setIsHydrated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useConfigurationTracker.useEffect": ()=>{
            const reloadFromStorage = {
                "useConfigurationTracker.useEffect.reloadFromStorage": ()=>{
                    try {
                        const stored = localStorage.getItem(STORAGE_KEY);
                        if (stored) {
                            setSavedConfigs(JSON.parse(stored));
                        }
                    } catch (e) {
                        setSavedConfigs([]);
                    }
                }
            }["useConfigurationTracker.useEffect.reloadFromStorage"];
            try {
                const stored = localStorage.getItem(STORAGE_KEY);
                if (stored) {
                    setSavedConfigs(JSON.parse(stored));
                }
            } catch (e) {
                setSavedConfigs([]);
            }
            setIsHydrated(true);
            window.addEventListener(CONFIGS_UPDATED_EVENT, reloadFromStorage);
            return ({
                "useConfigurationTracker.useEffect": ()=>window.removeEventListener(CONFIGS_UPDATED_EVENT, reloadFromStorage)
            })["useConfigurationTracker.useEffect"];
        }
    }["useConfigurationTracker.useEffect"], []);
    const generateConfigHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useConfigurationTracker.useCallback[generateConfigHash]": (config)=>{
            var _config_facialHair;
            return [
                config.gender,
                config.ageGroup,
                config.regionEthnicity,
                config.subGroup,
                config.skinTone,
                config.bodyType,
                config.hairStyle,
                config.hairColor,
                (_config_facialHair = config.facialHair) !== null && _config_facialHair !== void 0 ? _config_facialHair : ""
            ].join("|");
        }
    }["useConfigurationTracker.useCallback[generateConfigHash]"], []);
    const verifyUniqueConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useConfigurationTracker.useCallback[verifyUniqueConfig]": (newConfig)=>{
            const newHash = generateConfigHash(newConfig);
            return !savedConfigs.some({
                "useConfigurationTracker.useCallback[verifyUniqueConfig]": (existing)=>generateConfigHash(existing) === newHash
            }["useConfigurationTracker.useCallback[verifyUniqueConfig]"]);
        }
    }["useConfigurationTracker.useCallback[verifyUniqueConfig]"], [
        generateConfigHash,
        savedConfigs
    ]);
    const finalizeAndApproveConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useConfigurationTracker.useCallback[finalizeAndApproveConfig]": (name, traits)=>{
            var _traits_subGroup;
            if (!((_traits_subGroup = traits.subGroup) === null || _traits_subGroup === void 0 ? void 0 : _traits_subGroup.trim())) {
                throw new Error("Sub-group required: select a specific demographic profile before approval.");
            }
            if (!verifyUniqueConfig(traits)) {
                throw new Error("Duplicate Configuration Detected: A model profile with these exact traits already exists in your library.");
            }
            const approvedModel = {
                ...traits,
                id: "cfg_".concat(crypto.randomUUID()),
                name: name.trim() || "Model Profile - ".concat(new Date().toLocaleDateString()),
                approvalStatus: "Approved & Locked",
                createdAt: Date.now()
            };
            const updatedList = [
                ...savedConfigs,
                approvedModel
            ];
            setSavedConfigs(updatedList);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedList));
            window.dispatchEvent(new CustomEvent(CONFIGS_UPDATED_EVENT));
            return approvedModel;
        }
    }["useConfigurationTracker.useCallback[finalizeAndApproveConfig]"], [
        savedConfigs,
        verifyUniqueConfig
    ]);
    return {
        savedConfigs,
        isHydrated,
        verifyUniqueConfig,
        finalizeAndApproveConfig
    };
}
_s(useConfigurationTracker, "ztqdRY1NSzhAQU2CsdndWkm3iX4=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useBatchProcessor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getBatchDisplayName",
    ()=>getBatchDisplayName,
    "getConfigValue",
    ()=>getConfigValue,
    "toConfigurationTraitsFromBatch",
    ()=>toConfigurationTraitsFromBatch,
    "toPromptInputFromBatch",
    ()=>toPromptInputFromBatch,
    "useBatchProcessor",
    ()=>useBatchProcessor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$154a6e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:154a6e [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$c67c76__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:c67c76 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useConfigurationTracker.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const TIER1_THROTTLE_MS = 20_000;
function getConfigValue(config) {
    for(var _len = arguments.length, keys = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        keys[_key - 1] = arguments[_key];
    }
    for (const key of keys){
        const val = config[key];
        if (typeof val === "string" && val.trim()) return val.trim();
    }
    return "";
}
function toPromptInputFromBatch(config) {
    const gender = getConfigValue(config, "gender", "Gender");
    const input = {
        gender,
        ageGroup: getConfigValue(config, "ageGroup", "Age Group"),
        regionEthnicity: getConfigValue(config, "regionEthnicity", "Region / Ethnicity"),
        subGroup: getConfigValue(config, "subGroup", "Specific Demographic Sub-Group"),
        skinTone: getConfigValue(config, "skinTone", "Skin Tone"),
        hairStyle: getConfigValue(config, "hairStyle", "Hair Style"),
        hairColor: getConfigValue(config, "hairColor", "Hair Color"),
        bodyType: getConfigValue(config, "bodyType", "Body Type"),
        marketingArchetype: getConfigValue(config, "marketingArchetype", "Marketing Archetype")
    };
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMaleGender"])(gender)) {
        const facialHair = getConfigValue(config, "facialHair", "Facial Hair");
        if (facialHair) input.facialHair = facialHair;
    }
    return input;
}
function toConfigurationTraitsFromBatch(config) {
    const promptInput = toPromptInputFromBatch(config);
    const { facialHair, ...rest } = promptInput;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMaleGender"])(promptInput.gender) && facialHair) {
        return {
            ...rest,
            facialHair
        };
    }
    return rest;
}
function getBatchDisplayName(config, fallback) {
    return getConfigValue(config, "Model Name", "name", "modelName") || fallback;
}
function useBatchProcessor() {
    _s();
    const [batchQueue, setBatchQueue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isProcessing, setIsProcessing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const batchQueueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    const processingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const { finalizeAndApproveConfig } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConfigurationTracker"])();
    const setQueue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBatchProcessor.useCallback[setQueue]": (updater)=>{
            setBatchQueue({
                "useBatchProcessor.useCallback[setQueue]": (prev)=>{
                    const next = typeof updater === "function" ? updater(prev) : updater;
                    batchQueueRef.current = next;
                    return next;
                }
            }["useBatchProcessor.useCallback[setQueue]"]);
        }
    }["useBatchProcessor.useCallback[setQueue]"], []);
    const updateItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBatchProcessor.useCallback[updateItem]": (id, patch)=>{
            setQueue({
                "useBatchProcessor.useCallback[updateItem]": (prev)=>prev.map({
                        "useBatchProcessor.useCallback[updateItem]": (item)=>item.id === id ? {
                                ...item,
                                ...patch
                            } : item
                    }["useBatchProcessor.useCallback[updateItem]"])
            }["useBatchProcessor.useCallback[updateItem]"]);
        }
    }["useBatchProcessor.useCallback[updateItem]"], [
        setQueue
    ]);
    const loadJsonBatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBatchProcessor.useCallback[loadJsonBatch]": (jsonString)=>{
            let parsed;
            try {
                parsed = JSON.parse(jsonString);
            } catch (e) {
                throw new Error("Invalid JSON structure. Please check your formatting.");
            }
            const items = Array.isArray(parsed) ? parsed : [
                parsed
            ];
            if (items.length === 0) {
                throw new Error("JSON array is empty. Add at least one model config.");
            }
            const newQueue = items.map({
                "useBatchProcessor.useCallback[loadJsonBatch].newQueue": (item, index)=>{
                    if (!item || typeof item !== "object" || Array.isArray(item)) {
                        throw new Error("Invalid entry at index ".concat(index, ". Each item must be a JSON object."));
                    }
                    const config = item;
                    return {
                        id: "batch_".concat(crypto.randomUUID()),
                        displayName: getBatchDisplayName(config, "Model #".concat(index + 1)),
                        config,
                        status: "Pending"
                    };
                }
            }["useBatchProcessor.useCallback[loadJsonBatch].newQueue"]);
            setQueue({
                "useBatchProcessor.useCallback[loadJsonBatch]": (prev)=>[
                        ...prev,
                        ...newQueue
                    ]
            }["useBatchProcessor.useCallback[loadJsonBatch]"]);
            return true;
        }
    }["useBatchProcessor.useCallback[loadJsonBatch]"], [
        setQueue
    ]);
    const processNextInQueue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBatchProcessor.useCallback[processNextInQueue]": async ()=>{
            if (processingRef.current) return;
            processingRef.current = true;
            setIsProcessing(true);
            try {
                while(true){
                    const pending = batchQueueRef.current.find({
                        "useBatchProcessor.useCallback[processNextInQueue].pending": (item)=>item.status === "Pending"
                    }["useBatchProcessor.useCallback[processNextInQueue].pending"]);
                    if (!pending) break;
                    const itemId = pending.id;
                    try {
                        updateItem(itemId, {
                            status: "Generating Prompts",
                            error: undefined
                        });
                        const prompts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$154a6e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelTurnaroundPrompts"])(toPromptInputFromBatch(pending.config));
                        updateItem(itemId, {
                            status: "Generating Images"
                        });
                        const imageResults = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$c67c76__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelImages"])({
                            prompts
                        });
                        const images = imageResults.imagen;
                        if (!(images === null || images === void 0 ? void 0 : images.straight) || !(images === null || images === void 0 ? void 0 : images.left) || !(images === null || images === void 0 ? void 0 : images.right)) {
                            throw new Error("Image generation returned incomplete results. Expected straight, left, and right angles.");
                        }
                        const seed = Math.floor(1000000000 + Math.random() * 9000000000).toString();
                        updateItem(itemId, {
                            status: "Review",
                            images,
                            prompts,
                            seed
                        });
                    } catch (err) {
                        updateItem(itemId, {
                            status: "Failed",
                            error: err instanceof Error ? err.message : String(err)
                        });
                    }
                    const hasMorePending = batchQueueRef.current.some({
                        "useBatchProcessor.useCallback[processNextInQueue].hasMorePending": (item)=>item.status === "Pending"
                    }["useBatchProcessor.useCallback[processNextInQueue].hasMorePending"]);
                    if (hasMorePending) {
                        await new Promise({
                            "useBatchProcessor.useCallback[processNextInQueue]": (resolve)=>setTimeout(resolve, TIER1_THROTTLE_MS)
                        }["useBatchProcessor.useCallback[processNextInQueue]"]);
                    }
                }
            } finally{
                processingRef.current = false;
                setIsProcessing(false);
            }
        }
    }["useBatchProcessor.useCallback[processNextInQueue]"], [
        updateItem
    ]);
    const startBatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBatchProcessor.useCallback[startBatch]": ()=>{
            if (!processingRef.current) {
                void processNextInQueue();
            }
        }
    }["useBatchProcessor.useCallback[startBatch]"], [
        processNextInQueue
    ]);
    const approveItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBatchProcessor.useCallback[approveItem]": (id, name)=>{
            const item = batchQueueRef.current.find({
                "useBatchProcessor.useCallback[approveItem].item": (i)=>i.id === id
            }["useBatchProcessor.useCallback[approveItem].item"]);
            if (!(item === null || item === void 0 ? void 0 : item.images)) {
                throw new Error("No images available to approve.");
            }
            finalizeAndApproveConfig(name, toConfigurationTraitsFromBatch(item.config));
            updateItem(id, {
                status: "Approved"
            });
        }
    }["useBatchProcessor.useCallback[approveItem]"], [
        finalizeAndApproveConfig,
        updateItem
    ]);
    const regenerateItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useBatchProcessor.useCallback[regenerateItem]": (id)=>{
            updateItem(id, {
                status: "Pending",
                images: undefined,
                prompts: undefined,
                seed: undefined,
                error: undefined
            });
            if (!processingRef.current) {
                void processNextInQueue();
            }
        }
    }["useBatchProcessor.useCallback[regenerateItem]"], [
        processNextInQueue,
        updateItem
    ]);
    return {
        batchQueue,
        isProcessing,
        loadJsonBatch,
        startBatch,
        approveItem,
        regenerateItem
    };
}
_s(useBatchProcessor, "cR1T/p+yEze8m88qDoxsguuG0k4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConfigurationTracker"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/BatchProcessor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BatchProcessor",
    ()=>BatchProcessor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useBatchProcessor.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function getBatchSummary(config) {
    const gender = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getConfigValue"])(config, "gender", "Gender") || "—";
    const ageGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getConfigValue"])(config, "ageGroup", "Age Group") || "—";
    return "".concat(gender, " • ").concat(ageGroup);
}
function BatchProcessor() {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [jsonInput, setJsonInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [approvalError, setApprovalError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { batchQueue, isProcessing, loadJsonBatch, startBatch, approveItem, regenerateItem } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBatchProcessor"])();
    const handleLoad = ()=>{
        try {
            setError(null);
            loadJsonBatch(jsonInput);
            setJsonInput("");
            setIsOpen(false);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Failed to load batch.");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                type: "button",
                variant: "default",
                className: "w-full py-6 text-base font-bold shadow-md",
                onClick: ()=>setIsOpen(!isOpen),
                children: isOpen ? "Close Batch Processor" : "Batch Process JSON"
            }, void 0, false, {
                fileName: "[project]/src/components/BatchProcessor.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 space-y-4 rounded-lg border border-primary/20 bg-primary/5 p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                        className: "text-xs font-semibold uppercase text-primary",
                        children: "Paste JSON Array Here"
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessor.tsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Textarea"], {
                        value: jsonInput,
                        onChange: (e)=>setJsonInput(e.target.value),
                        className: "min-h-32 font-mono text-xs",
                        placeholder: '[\n  {\n    "Model Name": "Simran Kaur",\n    "Gender": "Female / Woman",\n    "Age Group": "Young Adult (20–29 years)",\n    "regionEthnicity": "south_asian",\n    "subGroup": "south asian, north indian phenotype",\n    "skinTone": "type 4 medium brown",\n    "hairStyle": "long wavy",\n    "hairColor": "dark brown espresso",\n    "bodyType": "Average / Straight",\n    "marketingArchetype": "Commercial / Lifestyle"\n  }\n]'
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessor.tsx",
                        lineNumber: 58,
                        columnNumber: 11
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "rounded bg-destructive/10 p-2 text-xs font-semibold text-destructive",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessor.tsx",
                        lineNumber: 65,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "button",
                        variant: "secondary",
                        className: "w-full",
                        onClick: handleLoad,
                        disabled: !jsonInput.trim(),
                        children: "Load to Queue"
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessor.tsx",
                        lineNumber: 69,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/BatchProcessor.tsx",
                lineNumber: 54,
                columnNumber: 9
            }, this),
            batchQueue.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-sm font-bold uppercase",
                                children: [
                                    "Batch Queue (",
                                    batchQueue.length,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessor.tsx",
                                lineNumber: 84,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                type: "button",
                                size: "sm",
                                onClick: startBatch,
                                disabled: isProcessing,
                                className: "bg-emerald-600 text-xs font-bold hover:bg-emerald-700",
                                children: isProcessing ? "Processing…" : "Start Batch"
                            }, void 0, false, {
                                fileName: "[project]/src/components/BatchProcessor.tsx",
                                lineNumber: 87,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/BatchProcessor.tsx",
                        lineNumber: 83,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-h-[50vh] space-y-3 overflow-y-auto pr-2",
                        children: batchQueue.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-3 rounded-lg border bg-card p-3 text-sm shadow-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "font-bold",
                                                        children: item.displayName || "Model #".concat(index + 1)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                                        lineNumber: 106,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-muted-foreground",
                                                        children: getBatchSummary(item.config)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                                        lineNumber: 109,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessor.tsx",
                                                lineNumber: 105,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded-full bg-secondary px-2 py-1 text-[10px] font-bold uppercase",
                                                children: item.status
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessor.tsx",
                                                lineNumber: 113,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                        lineNumber: 104,
                                        columnNumber: 17
                                    }, this),
                                    item.error && item.status === "Failed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "rounded bg-destructive/10 p-2 text-xs text-destructive",
                                        children: item.error
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                        lineNumber: 119,
                                        columnNumber: 19
                                    }, this),
                                    item.images && item.status === "Review" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-3 gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: item.images.straight,
                                                        alt: "Hero",
                                                        className: "aspect-[3/4] w-full rounded object-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: item.images.left,
                                                        alt: "Left",
                                                        className: "aspect-[3/4] w-full rounded object-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                                        lineNumber: 132,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: item.images.right,
                                                        alt: "Right",
                                                        className: "aspect-[3/4] w-full rounded object-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                                        lineNumber: 137,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessor.tsx",
                                                lineNumber: 126,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                        type: "button",
                                                        size: "sm",
                                                        className: "flex-1 bg-emerald-600 text-xs hover:bg-emerald-700",
                                                        onClick: ()=>{
                                                            setApprovalError(null);
                                                            try {
                                                                approveItem(item.id, item.displayName);
                                                            } catch (err) {
                                                                setApprovalError(err instanceof Error ? err.message : "Approval failed.");
                                                            }
                                                        },
                                                        children: "Verify & Approve"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                                        lineNumber: 144,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                        type: "button",
                                                        size: "sm",
                                                        variant: "outline",
                                                        className: "flex-1 border-amber-300 bg-amber-50 text-xs text-amber-800 hover:bg-amber-100",
                                                        onClick: ()=>regenerateItem(item.id),
                                                        children: "Regenerate"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                                        lineNumber: 163,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessor.tsx",
                                                lineNumber: 143,
                                                columnNumber: 21
                                            }, this),
                                            approvalError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "rounded bg-destructive/10 p-2 text-xs text-destructive",
                                                children: approvalError
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessor.tsx",
                                                lineNumber: 174,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                        lineNumber: 125,
                                        columnNumber: 19
                                    }, this),
                                    item.status === "Failed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        type: "button",
                                        size: "sm",
                                        variant: "outline",
                                        className: "w-full text-xs",
                                        onClick: ()=>regenerateItem(item.id),
                                        children: "Retry"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessor.tsx",
                                        lineNumber: 182,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, item.id, true, {
                                fileName: "[project]/src/components/BatchProcessor.tsx",
                                lineNumber: 100,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessor.tsx",
                        lineNumber: 98,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/BatchProcessor.tsx",
                lineNumber: 82,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/BatchProcessor.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_s(BatchProcessor, "Fb4HN6T++gRnqnSCELHN1aq0Fy8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBatchProcessor"]
    ];
});
_c = BatchProcessor;
var _c;
__turbopack_context__.k.register(_c, "BatchProcessor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/GeneratorForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GeneratorForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/checkbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wand-sparkles.js [app-client] (ecmascript) <export default as Wand2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BatchProcessor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BatchProcessor.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function GeneratorForm(param) {
    let { formData, setFormData, onGenerate, isGenerating } = param;
    _s();
    const isMale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMaleGender"])(formData.gender);
    const bodyTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBodyTypes"])(formData.gender);
    const hairStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHairStyles"])(formData.gender);
    const archetypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArchetypes"])(formData.gender);
    var _subGroupOptionsMap_formData_regionEthnicity;
    const subGroupOptions = (_subGroupOptionsMap_formData_regionEthnicity = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subGroupOptionsMap"][formData.regionEthnicity]) !== null && _subGroupOptionsMap_formData_regionEthnicity !== void 0 ? _subGroupOptionsMap_formData_regionEthnicity : [];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GeneratorForm.useEffect": ()=>{
            var _subGroupOptionsMap_formData_regionEthnicity;
            const options = (_subGroupOptionsMap_formData_regionEthnicity = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subGroupOptionsMap"][formData.regionEthnicity]) !== null && _subGroupOptionsMap_formData_regionEthnicity !== void 0 ? _subGroupOptionsMap_formData_regionEthnicity : [];
            if (options.length === 0) return;
            setFormData({
                "GeneratorForm.useEffect": (prev)=>{
                    if (options.some({
                        "GeneratorForm.useEffect": (o)=>o.value === prev.subGroup
                    }["GeneratorForm.useEffect"])) return prev;
                    return {
                        ...prev,
                        subGroup: options[0].value
                    };
                }
            }["GeneratorForm.useEffect"]);
        }
    }["GeneratorForm.useEffect"], [
        formData.regionEthnicity,
        setFormData
    ]);
    const handleSelectChange = (field)=>(value)=>{
            setFormData((prev)=>({
                    ...prev,
                    [field]: value
                }));
        };
    const handleGenderChange = (value)=>{
        const genderDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGenderSpecificDefaults"])(value);
        setFormData((prev)=>{
            const next = {
                ...prev,
                gender: value,
                ...genderDefaults
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMaleGender"])(value)) {
                delete next.facialHair;
            }
            return next;
        });
    };
    const handleRegionChange = (value)=>{
        setFormData((prev)=>({
                ...prev,
                regionEthnicity: value,
                subGroup: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultSubGroup"])(value)
            }));
    };
    const handleEngineChange = (engine, checked)=>{
        setFormData((prev)=>{
            const nextEngines = {
                ...prev.engines,
                [engine]: checked
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasAtLeastOneEngine"])(nextEngines)) {
                return prev;
            }
            return {
                ...prev,
                engines: nextEngines
            };
        });
    };
    const canGenerate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasAtLeastOneEngine"])(formData.engines);
    const onlyImagen = formData.engines.imagen && !formData.engines.openai;
    const onlyOpenai = formData.engines.openai && !formData.engines.imagen;
    var _formData_facialHair;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                        className: "flex items-center text-2xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__["Wand2"], {
                                className: "mr-3 text-primary"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 121,
                                columnNumber: 11
                            }, this),
                            "Kotoor Model AI"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 120,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                        children: "Design and generate your next virtual avatar."
                    }, void 0, false, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 124,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/GeneratorForm.tsx",
                lineNumber: 119,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BatchProcessor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BatchProcessor"], {}, void 0, false, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 129,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "gender",
                                children: "Gender"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 132,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.gender,
                                onValueChange: handleGenderChange,
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "gender",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select gender"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 139,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 138,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GENDERS"].map((gender)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: gender,
                                                children: gender
                                            }, gender, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 143,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 141,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "age-group",
                                children: "Age Group"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 152,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.ageGroup,
                                onValueChange: handleSelectChange("ageGroup"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "age-group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select age group"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 159,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 158,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AGE_GROUPS"].map((age)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: age,
                                                children: age
                                            }, age, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 163,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 161,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 153,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 151,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "region-ethnicity",
                                children: "Region / Ethnicity"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 172,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.regionEthnicity,
                                onValueChange: handleRegionChange,
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "region-ethnicity",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select region/ethnicity"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 179,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 178,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["regionEthnicityOptions"].map((region)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: region.value,
                                                children: region.label
                                            }, region.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 183,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 181,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 173,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 171,
                        columnNumber: 9
                    }, this),
                    formData.regionEthnicity && subGroupOptions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "sub-group",
                                children: "Specific Demographic Sub-Group"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 193,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.subGroup,
                                onValueChange: handleSelectChange("subGroup"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "sub-group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select specific demographic profile..."
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 200,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 199,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: subGroupOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: option.value,
                                                children: option.label
                                            }, option.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 204,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 202,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 194,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 192,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "skin-tone",
                                children: "Skin Tone (Fitzpatrick Scale)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 214,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.skinTone,
                                onValueChange: handleSelectChange("skinTone"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "skin-tone",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select skin tone"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 221,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 220,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["skinToneOptions"].map((tone)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: tone.value,
                                                children: tone.label
                                            }, tone.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 225,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 223,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 215,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 213,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "body-type",
                                children: "Body Type"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 234,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.bodyType,
                                onValueChange: handleSelectChange("bodyType"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "body-type",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select body type"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 241,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 240,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: bodyTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: type,
                                                children: type
                                            }, type, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 245,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 243,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 235,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 233,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "hair-style",
                                children: "Hair Style"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 254,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.hairStyle,
                                onValueChange: handleSelectChange("hairStyle"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "hair-style",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select hair style"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 261,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 260,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: hairStyles.map((style)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: style.value,
                                                children: style.label
                                            }, style.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 265,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 263,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 255,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 253,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "hair-color",
                                children: "Hair Color"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 274,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.hairColor,
                                onValueChange: handleSelectChange("hairColor"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "hair-color",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select hair color"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 281,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 280,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hairColorOptions"].map((color)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: color.value,
                                                children: color.label
                                            }, color.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 285,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 283,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 275,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 273,
                        columnNumber: 9
                    }, this),
                    isMale && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "facial-hair",
                                children: "Facial Hair"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 295,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: (_formData_facialHair = formData.facialHair) !== null && _formData_facialHair !== void 0 ? _formData_facialHair : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MALE_FACIAL_HAIR"][0].value,
                                onValueChange: handleSelectChange("facialHair"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "facial-hair",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select facial hair"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 302,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 301,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MALE_FACIAL_HAIR"].map((style)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: style.value,
                                                children: style.label
                                            }, style.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 306,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 304,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 296,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 294,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3 rounded-lg border p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                className: "text-base font-semibold",
                                children: "Generation Engine"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 316,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-muted-foreground",
                                children: "Select at least one engine. Both run in parallel for side-by-side comparison."
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 317,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                                        id: "engine-imagen",
                                        checked: formData.engines.imagen,
                                        disabled: isGenerating || onlyImagen,
                                        onCheckedChange: (checked)=>handleEngineChange("imagen", checked === true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 322,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "engine-imagen",
                                        className: "font-normal cursor-pointer",
                                        children: "Google Imagen 4 Fast"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 330,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 321,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                                        id: "engine-openai",
                                        checked: formData.engines.openai,
                                        disabled: isGenerating || onlyOpenai,
                                        onCheckedChange: (checked)=>handleEngineChange("openai", checked === true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 338,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "engine-openai",
                                        className: "font-normal cursor-pointer",
                                        children: "OpenAI GPT Image 2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 346,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 337,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 315,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "archetype",
                                children: "Marketing Archetype (Vibe)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 356,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.marketingArchetype,
                                onValueChange: handleSelectChange("marketingArchetype"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "archetype",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select archetype"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 363,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 362,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: archetypes.map((archetype)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: archetype,
                                                children: archetype
                                            }, archetype, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 367,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 365,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 357,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 355,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onGenerate,
                        disabled: isGenerating || !canGenerate,
                        className: "w-full bg-accent text-accent-foreground hover:bg-accent/90",
                        size: "lg",
                        children: [
                            isGenerating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                className: "mr-2 h-4 w-4 animate-spin"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 382,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__["Wand2"], {
                                className: "mr-2 h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 384,
                                columnNumber: 13
                            }, this),
                            "Generate 3-Angle Turnaround"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 375,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/GeneratorForm.tsx",
                lineNumber: 128,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/GeneratorForm.tsx",
        lineNumber: 118,
        columnNumber: 5
    }, this);
}
_s(GeneratorForm, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = GeneratorForm;
var _c;
__turbopack_context__.k.register(_c, "GeneratorForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/tabs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tabs",
    ()=>Tabs,
    "TabsContent",
    ()=>TabsContent,
    "TabsList",
    ()=>TabsList,
    "TabsTrigger",
    ()=>TabsTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-tabs/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
const Tabs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"];
const TabsList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 14,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = TabsList;
TabsList.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"].displayName;
const TabsTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 29,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = TabsTrigger;
TabsTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"].displayName;
const TabsContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 44,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c5 = TabsContent;
TabsContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "TabsList$React.forwardRef");
__turbopack_context__.k.register(_c1, "TabsList");
__turbopack_context__.k.register(_c2, "TabsTrigger$React.forwardRef");
__turbopack_context__.k.register(_c3, "TabsTrigger");
__turbopack_context__.k.register(_c4, "TabsContent$React.forwardRef");
__turbopack_context__.k.register(_c5, "TabsContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ActiveModelDisplay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActiveModelDisplay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/tabs.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
"use client";
;
;
;
;
;
;
;
function AngleGrid(param) {
    let { images, prompts, seed, enginePrefix } = param;
    const handleDownload = (url, filename)=>{
        const link = document.createElement("a");
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const prefix = enginePrefix ? "".concat(enginePrefix, "_") : "";
    const angles = [
        {
            title: "Straight (3/4 Body)",
            url: images.straight,
            prompt: prompts.straightPrompt,
            alt: "Straight 3/4 body portrait of the model",
            hint: "person portrait",
            file: "straight_".concat(prefix).concat(seed, ".png")
        },
        {
            title: "Left Profile (3/4 Body)",
            url: images.left,
            prompt: prompts.leftPrompt,
            alt: "Left profile 3/4 body portrait of the model",
            hint: "person profile",
            file: "left_".concat(prefix).concat(seed, ".png")
        },
        {
            title: "Right Profile (3/4 Body)",
            url: images.right,
            prompt: prompts.rightPrompt,
            alt: "Right profile 3/4 body portrait of the model",
            hint: "person profile",
            file: "right_".concat(prefix).concat(seed, ".png")
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-1 md:grid-cols-3 gap-6 items-start",
        children: angles.map((angle)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                            className: "text-base",
                            children: angle.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 82,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 81,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "flex-grow",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-full aspect-[3/4] max-h-[75vh] mx-auto overflow-hidden rounded-md",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: angle.url,
                                alt: angle.alt,
                                fill: true,
                                className: "object-cover",
                                sizes: "(max-width: 768px) 100vw, 33vw",
                                "data-ai-hint": angle.hint
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 86,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 85,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 84,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardFooter"], {
                        className: "flex-col items-start gap-2 pt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm font-medium",
                                        children: "Prompt"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 98,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: "outline",
                                        size: "sm",
                                        onClick: ()=>handleDownload(angle.url, angle.file),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                className: "mr-2 h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                                lineNumber: 104,
                                                columnNumber: 17
                                            }, this),
                                            "Download"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 99,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-muted-foreground",
                                children: angle.prompt
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, this)
                ]
            }, angle.title, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 80,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 78,
        columnNumber: 5
    }, this);
}
_c = AngleGrid;
function EngineResults(param) {
    let { engineKey, activeModel } = param;
    const images = activeModel.imageResults[engineKey];
    if (!images) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AngleGrid, {
        images: images,
        prompts: activeModel.prompts,
        seed: activeModel.seed,
        enginePrefix: engineKey
    }, void 0, false, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 127,
        columnNumber: 5
    }, this);
}
_c1 = EngineResults;
function ActiveModelDisplay(param) {
    let { activeModel, isGenerating, onBulkDownload } = param;
    const engineKeys = activeModel ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActiveEngineKeys"])(activeModel.imageResults) : [];
    const dualEngine = activeModel ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasMultipleEngines"])(activeModel.imageResults) : false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold tracking-tight",
                                children: "Active Model"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 148,
                                columnNumber: 11
                            }, this),
                            activeModel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-muted-foreground",
                                children: [
                                    "Generation Seed: ",
                                    activeModel.seed,
                                    engineKeys.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-2",
                                        children: [
                                            "· Engines:",
                                            " ",
                                            engineKeys.map((k)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][k]).join(", ")
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 153,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 150,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this),
                    activeModel && !isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onBulkDownload,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                className: "mr-2"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 163,
                                columnNumber: 13
                            }, this),
                            "Bulk Download"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 162,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 146,
                columnNumber: 7
            }, this),
            isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-10 flex flex-col items-center justify-center border-2 border-dashed rounded-lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                        className: "w-16 h-16 animate-spin text-primary mb-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xl font-semibold text-primary",
                        children: "Synthesizing Realistic Angles..."
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 172,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-muted-foreground",
                        children: "Please wait a moment."
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 175,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 170,
                columnNumber: 9
            }, this),
            !isGenerating && !activeModel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-10 border-2 border-dashed rounded-lg",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg text-muted-foreground",
                    children: "Generate a model to see the results here."
                }, void 0, false, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 181,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 180,
                columnNumber: 9
            }, this),
            activeModel && !isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "animate-in fade-in duration-500",
                children: dualEngine ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tabs"], {
                    defaultValue: engineKeys[0],
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsList"], {
                            className: "mb-6",
                            children: engineKeys.map((key)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                    value: key,
                                    children: [
                                        "Engine: ",
                                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][key]
                                    ]
                                }, key, true, {
                                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                    lineNumber: 193,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 191,
                            columnNumber: 15
                        }, this),
                        engineKeys.map((key)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                value: key,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EngineResults, {
                                    engineKey: key,
                                    activeModel: activeModel
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                    lineNumber: 200,
                                    columnNumber: 19
                                }, this)
                            }, key, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 199,
                                columnNumber: 17
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 190,
                    columnNumber: 13
                }, this) : engineKeys[0] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EngineResults, {
                    engineKey: engineKeys[0],
                    activeModel: activeModel
                }, void 0, false, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 206,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 188,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 145,
        columnNumber: 5
    }, this);
}
_c2 = ActiveModelDisplay;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "AngleGrid");
__turbopack_context__.k.register(_c1, "EngineResults");
__turbopack_context__.k.register(_c2, "ActiveModelDisplay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, type, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/input.tsx",
        lineNumber: 8,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Input;
Input.displayName = "Input";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$React.forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ModelLibraryManager.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ModelLibraryManager",
    ()=>ModelLibraryManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useConfigurationTracker.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function ModelLibraryManager(param) {
    let { currentFormTraits } = param;
    _s();
    const { savedConfigs, isHydrated, finalizeAndApproveConfig } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConfigurationTracker"])();
    const [profileName, setProfileName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [errorNotification, setErrorNotification] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [successMessage, setSuccessMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleFormalApproval = (e)=>{
        e.preventDefault();
        setErrorNotification(null);
        setSuccessMessage(null);
        try {
            finalizeAndApproveConfig(profileName, currentFormTraits);
            setProfileName("");
            setSuccessMessage("Configuration approved and locked to your library.");
        } catch (err) {
            setErrorNotification(err instanceof Error ? err.message : "Approval failed.");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6 rounded-xl border bg-card p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-b pb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-semibold text-foreground",
                        children: "Model Configuration Tracker"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-muted-foreground",
                        children: "Name and finalize current traits to approve for production"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 50,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleFormalApproval,
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "profile-name",
                                className: "text-xs font-medium uppercase tracking-wider text-muted-foreground",
                                children: "Unique Profile Identity Name"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                lineNumber: 57,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                id: "profile-name",
                                type: "text",
                                value: profileName,
                                onChange: (e)=>setProfileName(e.target.value),
                                placeholder: "e.g., Autumn Collection Elite Male - South Asian",
                                required: true
                            }, void 0, false, {
                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this),
                    errorNotification && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "rounded bg-destructive/10 p-2 text-xs font-medium text-destructive",
                        children: errorNotification
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 74,
                        columnNumber: 11
                    }, this),
                    successMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "rounded bg-emerald-500/10 p-2 text-xs font-medium text-emerald-600 dark:text-emerald-400",
                        children: successMessage
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 80,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "submit",
                        className: "w-full text-xs font-semibold",
                        children: "Verify & Issue Formal Approval"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: "mb-3 text-xs font-bold uppercase tracking-wider text-muted-foreground",
                        children: [
                            "Approved Model Library (",
                            isHydrated ? savedConfigs.length : "…",
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-h-[300px] space-y-2 overflow-y-auto pr-1",
                        children: !isHydrated ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-muted-foreground",
                            children: "Loading library…"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModelLibraryManager.tsx",
                            lineNumber: 96,
                            columnNumber: 13
                        }, this) : savedConfigs.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-muted-foreground",
                            children: "No approved configurations yet."
                        }, void 0, false, {
                            fileName: "[project]/src/components/ModelLibraryManager.tsx",
                            lineNumber: 98,
                            columnNumber: 13
                        }, this) : savedConfigs.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between rounded-lg border bg-background p-3 text-xs",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-semibold text-foreground",
                                                children: item.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                                lineNumber: 108,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-0.5 text-muted-foreground",
                                                children: [
                                                    item.gender,
                                                    " • ",
                                                    item.ageGroup,
                                                    " •",
                                                    " ",
                                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRegionLabel"])(item.regionEthnicity),
                                                    " • ",
                                                    item.subGroup
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                                lineNumber: 109,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                        lineNumber: 107,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "rounded-full bg-emerald-500/10 px-2 py-1 text-[10px] font-medium text-emerald-600 dark:text-emerald-400",
                                        children: item.approvalStatus
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                        lineNumber: 114,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, item.id, true, {
                                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                                lineNumber: 103,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/components/ModelLibraryManager.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ModelLibraryManager.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ModelLibraryManager.tsx",
        lineNumber: 45,
        columnNumber: 5
    }, this);
}
_s(ModelLibraryManager, "klSIQ7o+isFOfqZICfuu9cA51CE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useConfigurationTracker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConfigurationTracker"]
    ];
});
_c = ModelLibraryManager;
var _c;
__turbopack_context__.k.register(_c, "ModelLibraryManager");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/BatchProcessorQueue.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BatchProcessorQueue",
    ()=>BatchProcessorQueue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useBatchProcessor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/download-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function getBatchSummary(config) {
    const gender = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getConfigValue"])(config, "gender", "Gender") || "—";
    const ageGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getConfigValue"])(config, "ageGroup", "Age Group") || "—";
    return "".concat(gender, " • ").concat(ageGroup);
}
function BatchAngleGrid(param) {
    let { images, prompts, seed, onBulkDownload } = param;
    const angles = [
        {
            title: "Straight (3/4 Body)",
            url: images.straight,
            prompt: prompts.straightPrompt,
            alt: "Straight 3/4 body portrait",
            file: "straight_".concat(seed, ".png")
        },
        {
            title: "Left Profile (3/4 Body)",
            url: images.left,
            prompt: prompts.leftPrompt,
            alt: "Left profile 3/4 body portrait",
            file: "left_".concat(seed, ".png")
        },
        {
            title: "Right Profile (3/4 Body)",
            url: images.right,
            prompt: prompts.rightPrompt,
            alt: "Right profile 3/4 body portrait",
            file: "right_".concat(seed, ".png")
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "default",
                    size: "sm",
                    onClick: onBulkDownload,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                            className: "mr-2 h-4 w-4"
                        }, void 0, false, {
                            fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, this),
                        "Bulk Download"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                    lineNumber: 76,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 gap-6 md:grid-cols-3",
                children: angles.map((angle)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                    className: "text-base",
                                    children: angle.title
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                    lineNumber: 85,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 84,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                className: "flex-grow",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative mx-auto aspect-[3/4] w-full max-h-[50vh] overflow-hidden rounded-md",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: angle.url,
                                        alt: angle.alt,
                                        fill: true,
                                        className: "object-cover",
                                        sizes: "(max-width: 768px) 100vw, 33vw",
                                        unoptimized: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 89,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                    lineNumber: 88,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 87,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardFooter"], {
                                className: "flex-col items-start gap-2 pt-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex w-full items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm font-medium",
                                                children: "Prompt"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 101,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "outline",
                                                size: "sm",
                                                onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadDataUri"])(angle.url, angle.file),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                        className: "mr-2 h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                        lineNumber: 107,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Download"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 102,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 100,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-muted-foreground line-clamp-4",
                                        children: angle.prompt
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 111,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 99,
                                columnNumber: 13
                            }, this)
                        ]
                    }, angle.title, true, {
                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                        lineNumber: 83,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
        lineNumber: 74,
        columnNumber: 5
    }, this);
}
_c = BatchAngleGrid;
function BatchProcessorQueue(param) {
    let { batchQueue, isProcessing, onStartBatch, onApproveItem, onRegenerateItem } = param;
    _s();
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const [approvalErrors, setApprovalErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    if (batchQueue.length === 0 && !isProcessing) {
        return null;
    }
    const handleBulkDownload = async (item)=>{
        if (!item.images || !item.prompts || !item.seed) return;
        toast({
            title: "Preparing Download...",
            description: "Your model assets are being zipped."
        });
        try {
            const safeName = item.displayName.replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "_").slice(0, 40);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadModelZip"])({
                seed: item.seed,
                images: item.images,
                prompts: item.prompts,
                zipFilename: safeName ? "model_".concat(safeName, "_").concat(item.seed, ".zip") : "model_".concat(item.seed, ".zip")
            });
        } catch (e) {
            toast({
                variant: "destructive",
                title: "Download Failed",
                description: "Could not prepare your files for download. Please try again."
            });
        }
    };
    const handleApprove = (item)=>{
        setApprovalErrors((prev)=>{
            const next = {
                ...prev
            };
            delete next[item.id];
            return next;
        });
        try {
            onApproveItem(item.id, item.displayName);
        } catch (err) {
            setApprovalErrors((prev)=>({
                    ...prev,
                    [item.id]: err instanceof Error ? err.message : "Approval failed."
                }));
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold tracking-tight",
                                children: "Batch Queue"
                            }, void 0, false, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 191,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-muted-foreground",
                                children: [
                                    batchQueue.length,
                                    " item",
                                    batchQueue.length === 1 ? "" : "s",
                                    " loaded",
                                    isProcessing ? " · Processing…" : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 192,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                        lineNumber: 190,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onStartBatch,
                        disabled: isProcessing,
                        className: "bg-emerald-600 hover:bg-emerald-700",
                        children: isProcessing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                    className: "mr-2 h-4 w-4 animate-spin"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                    lineNumber: 204,
                                    columnNumber: 15
                                }, this),
                                "Processing…"
                            ]
                        }, void 0, true) : "Start Batch"
                    }, void 0, false, {
                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                        lineNumber: 197,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                lineNumber: 189,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-8",
                children: batchQueue.map((item, index)=>{
                    const hasAssets = item.images && item.prompts && item.seed && item.status !== "Failed";
                    const canReview = item.status === "Review";
                    const isApproved = item.status === "Approved";
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        className: "overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                className: "flex flex-row items-start justify-between space-y-0 pb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                                className: "text-lg",
                                                children: item.displayName || "Model #".concat(index + 1)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 224,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-sm text-muted-foreground",
                                                children: [
                                                    getBatchSummary(item.config),
                                                    item.seed ? " · Seed: ".concat(item.seed) : ""
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 227,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 223,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "rounded-full bg-secondary px-2 py-1 text-[10px] font-bold uppercase",
                                        children: item.status
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 232,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 222,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                className: "space-y-4",
                                children: [
                                    (item.status === "Generating Prompts" || item.status === "Generating Images") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 rounded-lg border border-dashed p-6 text-muted-foreground",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                className: "h-5 w-5 animate-spin text-primary"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 241,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-sm font-medium",
                                                children: [
                                                    item.status,
                                                    "…"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 242,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 240,
                                        columnNumber: 19
                                    }, this),
                                    item.error && item.status === "Failed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "rounded bg-destructive/10 p-3 text-sm text-destructive",
                                        children: item.error
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 247,
                                        columnNumber: 19
                                    }, this),
                                    hasAssets && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BatchAngleGrid, {
                                        images: item.images,
                                        prompts: item.prompts,
                                        seed: item.seed,
                                        onBulkDownload: ()=>void handleBulkDownload(item)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 253,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-wrap gap-2",
                                        children: [
                                            canReview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                        size: "sm",
                                                        className: "bg-emerald-600 hover:bg-emerald-700",
                                                        onClick: ()=>handleApprove(item),
                                                        children: "Verify & Approve"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                        lineNumber: 264,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                        size: "sm",
                                                        variant: "outline",
                                                        className: "border-amber-300 bg-amber-50 text-amber-800 hover:bg-amber-100",
                                                        onClick: ()=>onRegenerateItem(item.id),
                                                        children: "Regenerate"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                        lineNumber: 271,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true),
                                            isApproved && hasAssets && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                size: "sm",
                                                onClick: ()=>void handleBulkDownload(item),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                        className: "mr-2 h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                        lineNumber: 287,
                                                        columnNumber: 23
                                                    }, this),
                                                    "Bulk Download"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 283,
                                                columnNumber: 21
                                            }, this),
                                            item.status === "Failed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                size: "sm",
                                                variant: "outline",
                                                onClick: ()=>onRegenerateItem(item.id),
                                                children: "Retry"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                                lineNumber: 293,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 261,
                                        columnNumber: 17
                                    }, this),
                                    approvalErrors[item.id] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "rounded bg-destructive/10 p-2 text-xs text-destructive",
                                        children: approvalErrors[item.id]
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                        lineNumber: 304,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                                lineNumber: 237,
                                columnNumber: 15
                            }, this)
                        ]
                    }, item.id, true, {
                        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                        lineNumber: 221,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/BatchProcessorQueue.tsx",
                lineNumber: 213,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/BatchProcessorQueue.tsx",
        lineNumber: 188,
        columnNumber: 5
    }, this);
}
_s(BatchProcessorQueue, "Z7QZsGbumODN4G0d3RQFjc2v/b4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c1 = BatchProcessorQueue;
var _c, _c1;
__turbopack_context__.k.register(_c, "BatchAngleGrid");
__turbopack_context__.k.register(_c1, "BatchProcessorQueue");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>KotoorModelAI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$154a6e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:154a6e [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$c67c76__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:c67c76 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/download-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GeneratorForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/GeneratorForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ActiveModelDisplay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ActiveModelDisplay.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModelLibraryManager$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ModelLibraryManager.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BatchProcessorQueue$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BatchProcessorQueue.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useBatchProcessor.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
function KotoorModelAI() {
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FORM_DATA_FEMALE"]);
    const [activeModel, setActiveModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isGenerating, setIsGenerating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const { batchQueue, isProcessing, loadJsonBatch, startBatch, approveItem, regenerateItem } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBatchProcessor"])();
    const handleGenerate = async ()=>{
        var _formData_subGroup;
        if (!((_formData_subGroup = formData.subGroup) === null || _formData_subGroup === void 0 ? void 0 : _formData_subGroup.trim())) {
            toast({
                variant: "destructive",
                title: "Sub-group required",
                description: "Select a specific demographic sub-group before generating."
            });
            return;
        }
        setIsGenerating(true);
        setActiveModel(null);
        try {
            const prompts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$154a6e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelTurnaroundPrompts"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toPromptInput"])(formData));
            const imageResults = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$c67c76__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelImages"])({
                prompts
            });
            const seed = Math.floor(1000000000 + Math.random() * 9000000000).toString();
            const newModel = {
                seed,
                imageResults,
                prompts,
                formData
            };
            setActiveModel(newModel);
        } catch (error) {
            console.error("Failed to generate model", error);
            toast({
                variant: "destructive",
                title: "Generation Failed",
                description: error instanceof Error ? error.message : "There was an error generating the model. Please try again."
            });
        } finally{
            setIsGenerating(false);
        }
    };
    const handleBulkDownload = async ()=>{
        if (!(activeModel === null || activeModel === void 0 ? void 0 : activeModel.imageResults.imagen)) return;
        toast({
            title: "Preparing Download...",
            description: "Your model assets are being zipped."
        });
        try {
            const engineKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActiveEngineKeys"])(activeModel.imageResults);
            if (engineKeys.length === 1 && activeModel.imageResults.imagen) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["downloadModelZip"])({
                    seed: activeModel.seed,
                    images: activeModel.imageResults.imagen,
                    prompts: activeModel.prompts
                });
                return;
            }
            const JSZip = (await __turbopack_context__.A("[project]/node_modules/jszip/lib/index.js [app-client] (ecmascript, async loader)")).default;
            const zip = new JSZip();
            const promptData = "Straight Prompt:\n".concat(activeModel.prompts.straightPrompt, "\n\nLeft Prompt:\n").concat(activeModel.prompts.leftPrompt, "\n\nRight Prompt:\n").concat(activeModel.prompts.rightPrompt);
            zip.file("prompts.txt", promptData);
            for (const engineKey of engineKeys){
                const images = activeModel.imageResults[engineKey];
                if (!images) continue;
                const folder = engineKeys.length > 1 ? "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][engineKey].replace(/\s+/g, "_"), "/") : "";
                zip.file("".concat(folder, "straight_").concat(activeModel.seed, ".png"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataURItoBlob"])(images.straight));
                zip.file("".concat(folder, "left_").concat(activeModel.seed, ".png"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataURItoBlob"])(images.left));
                zip.file("".concat(folder, "right_").concat(activeModel.seed, ".png"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$download$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dataURItoBlob"])(images.right));
            }
            const content = await zip.generateAsync({
                type: "blob"
            });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(content);
            link.download = "model_".concat(activeModel.seed, ".zip");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        } catch (error) {
            console.error("Failed to create zip for download", error);
            toast({
                variant: "destructive",
                title: "Download Failed",
                description: "Could not prepare your files for download. Please try again."
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "container mx-auto p-4 md:p-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col lg:flex-row lg:space-x-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "lg:w-1/3 xl:w-1/4 mb-8 lg:mb-0",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GeneratorForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        formData: formData,
                        setFormData: setFormData,
                        onGenerate: handleGenerate,
                        isGenerating: isGenerating,
                        onLoadBatch: loadJsonBatch
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 148,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 147,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "lg:w-2/3 xl:w-3/4 flex flex-col space-y-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BatchProcessorQueue$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BatchProcessorQueue"], {
                            batchQueue: batchQueue,
                            isProcessing: isProcessing,
                            onStartBatch: startBatch,
                            onApproveItem: approveItem,
                            onRegenerateItem: regenerateItem
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 158,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ActiveModelDisplay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            activeModel: activeModel,
                            isGenerating: isGenerating,
                            onBulkDownload: handleBulkDownload
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 165,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ModelLibraryManager$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModelLibraryManager"], {
                            currentFormTraits: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toConfigurationTraits"])(formData)
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 170,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 157,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 146,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 145,
        columnNumber: 5
    }, this);
}
_s(KotoorModelAI, "1f3oS5/bYBxkTgJplL5UmbgOJhA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useBatchProcessor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBatchProcessor"]
    ];
});
_c = KotoorModelAI;
var _c;
__turbopack_context__.k.register(_c, "KotoorModelAI");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_1bc5e2ac._.js.map
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ENGINE_LABELS",
    ()=>ENGINE_LABELS,
    "getActiveEngineKeys",
    ()=>getActiveEngineKeys,
    "hasMultipleEngines",
    ()=>hasMultipleEngines
]);
const ENGINE_LABELS = {
    imagen: "Imagen 4",
    openai: "GPT Image 2"
};
function getActiveEngineKeys(results) {
    const keys = [];
    if (results.imagen) keys.push("imagen");
    if (results.openai) keys.push("openai");
    return keys;
}
function hasMultipleEngines(results) {
    return getActiveEngineKeys(results).length > 1;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AGE_GROUPS",
    ()=>AGE_GROUPS,
    "DEFAULT_ENGINES",
    ()=>DEFAULT_ENGINES,
    "DEFAULT_FORM_DATA_FEMALE",
    ()=>DEFAULT_FORM_DATA_FEMALE,
    "DEFAULT_FORM_DATA_MALE",
    ()=>DEFAULT_FORM_DATA_MALE,
    "FEMALE_ARCHETYPES",
    ()=>FEMALE_ARCHETYPES,
    "FEMALE_BODY_TYPES",
    ()=>FEMALE_BODY_TYPES,
    "FEMALE_GENDER",
    ()=>FEMALE_GENDER,
    "FEMALE_HAIR_STYLES",
    ()=>FEMALE_HAIR_STYLES,
    "GENDERS",
    ()=>GENDERS,
    "HAIR_COLORS",
    ()=>HAIR_COLORS,
    "MALE_ARCHETYPES",
    ()=>MALE_ARCHETYPES,
    "MALE_BODY_TYPES",
    ()=>MALE_BODY_TYPES,
    "MALE_FACIAL_HAIR",
    ()=>MALE_FACIAL_HAIR,
    "MALE_GENDER",
    ()=>MALE_GENDER,
    "MALE_HAIR_STYLES",
    ()=>MALE_HAIR_STYLES,
    "REGIONS",
    ()=>REGIONS,
    "SKIN_TONES",
    ()=>SKIN_TONES,
    "femaleHairStyleOptions",
    ()=>femaleHairStyleOptions,
    "getArchetypes",
    ()=>getArchetypes,
    "getBodyTypes",
    ()=>getBodyTypes,
    "getGenderSpecificDefaults",
    ()=>getGenderSpecificDefaults,
    "getHairStyles",
    ()=>getHairStyles,
    "hairColorOptions",
    ()=>hairColorOptions,
    "hasAtLeastOneEngine",
    ()=>hasAtLeastOneEngine,
    "isMaleGender",
    ()=>isMaleGender,
    "maleHairStyleOptions",
    ()=>maleHairStyleOptions,
    "skinToneOptions",
    ()=>skinToneOptions,
    "toPromptInput",
    ()=>toPromptInput
]);
const FEMALE_GENDER = "Female / Woman";
const MALE_GENDER = "Male / Man";
const GENDERS = [
    FEMALE_GENDER,
    MALE_GENDER
];
const AGE_GROUPS = [
    "Child (4–12 years)",
    "Teen (13–19 years)",
    "Young Adult (20–29 years)",
    "Adult (30–45 years)",
    "Middle-Aged (46–60 years)",
    "Senior / Mature (60+ years)"
];
const REGIONS = [
    {
        label: "African / Black",
        value: "African / Black"
    },
    {
        label: "East Asian",
        value: "East Asian"
    },
    {
        label: "South Asian (North Indian phenotype)",
        value: "south asian, north indian phenotype"
    },
    {
        label: "South Asian (South Indian phenotype)",
        value: "south asian, south indian phenotype"
    },
    {
        label: "Southeast Asian",
        value: "Southeast Asian"
    },
    {
        label: "Middle Eastern / North African (MENA)",
        value: "Middle Eastern / North African (MENA)"
    },
    {
        label: "Caucasian / White",
        value: "Caucasian / White"
    },
    {
        label: "Hispanic / Latin American",
        value: "Hispanic / Latin American"
    },
    {
        label: "Indigenous / First Nations",
        value: "Indigenous / First Nations"
    },
    {
        label: "Mixed / Multiracial",
        value: "Mixed / Multiracial"
    }
];
const skinToneOptions = [
    {
        label: "Type 1: Very light, pale, or porcelain",
        value: "type 1 very light pale porcelain"
    },
    {
        label: "Type 2: Light or fair",
        value: "type 2 light fair"
    },
    {
        label: "Type 3: Medium, wheatish to light olive",
        value: "type 3 medium wheatish light olive warm undertone"
    },
    {
        label: "Type 4: Olive, warm tan to caramel",
        value: "type 4 olive warm tan caramel undertone"
    },
    {
        label: "Type 5: Rich bronze, medium-dark warm brown",
        value: "type 5 rich bronze medium-dark warm brown undertone"
    },
    {
        label: "Type 6: Deep, dark mahogany to rich espresso brown",
        value: "type 6 deep dark mahogany rich espresso brown warm undertone"
    }
];
const SKIN_TONES = skinToneOptions;
const hairColorOptions = [
    {
        label: "Jet Black",
        value: "jet black"
    },
    {
        label: "Natural Soft Black",
        value: "natural soft black"
    },
    {
        label: "Dark Brown / Espresso",
        value: "dark brown espresso"
    },
    {
        label: "Medium Brown / Chestnut",
        value: "medium brown chestnut"
    },
    {
        label: "Burgundy / Henna Red Tone",
        value: "burgundy henna red tone"
    },
    {
        label: "Honey Blonde / Golden Brown Highlights",
        value: "honey blonde golden brown highlights"
    },
    {
        label: "Platinum Blonde",
        value: "platinum blonde"
    },
    {
        label: "Auburn / Ginger",
        value: "auburn ginger"
    },
    {
        label: "Grey / Salt & Pepper",
        value: "grey salt and pepper"
    },
    {
        label: "White / Silver",
        value: "white silver"
    }
];
const HAIR_COLORS = hairColorOptions;
const FEMALE_BODY_TYPES = [
    "Slim / Petite",
    "Average / Straight",
    "Athletic / Toned",
    "Curvy / Hourglass",
    "Plus Size / Curve",
    "Maternity"
];
const MALE_BODY_TYPES = [
    "Slim / Slender",
    "Average / Straight",
    "Athletic / Muscular",
    "Broad / Brawn",
    "Plus Size / Big & Tall"
];
const femaleHairStyleOptions = [
    {
        label: "Buzz Cut / Shaved",
        value: "buzz cut shaved"
    },
    {
        label: "Short & Straight (Pixie/Crop)",
        value: "short straight pixie crop"
    },
    {
        label: "Short & Wavy",
        value: "short wavy"
    },
    {
        label: "Short & Thick Indian Curls",
        value: "short thick indian curls"
    },
    {
        label: "Medium & Straight (Bob/Lob)",
        value: "medium length straight bob lob"
    },
    {
        label: "Medium & Wavy",
        value: "medium length wavy"
    },
    {
        label: "Medium & Thick Indian Curls",
        value: "medium length thick indian curls"
    },
    {
        label: "Long & Straight",
        value: "long straight"
    },
    {
        label: "Long & Wavy",
        value: "long wavy"
    },
    {
        label: "Long & Thick Indian Curls",
        value: "long thick indian curls"
    },
    {
        label: "Coily / Type 4 Natural",
        value: "coily type 4 natural"
    },
    {
        label: "Braids / Locs",
        value: "braids locs"
    }
];
const FEMALE_HAIR_STYLES = femaleHairStyleOptions;
const maleHairStyleOptions = [
    {
        label: "Bald / Clean Shaved",
        value: "bald clean shaved"
    },
    {
        label: "Buzz Cut / Fade",
        value: "buzz cut fade"
    },
    {
        label: "Short & Straight (Textured Crop)",
        value: "short straight textured crop"
    },
    {
        label: "Short & Wavy",
        value: "short wavy"
    },
    {
        label: "Short & Thick Indian Curls",
        value: "short thick indian curls"
    },
    {
        label: "Medium Length & Straight",
        value: "medium length straight"
    },
    {
        label: "Medium Length & Wavy / Thick Curls",
        value: "medium length wavy thick curls"
    },
    {
        label: "Long & Straight",
        value: "long straight"
    },
    {
        label: "Long & Wavy / Curly",
        value: "long wavy curly"
    },
    {
        label: "Coily / Type 4 Natural",
        value: "coily type 4 natural"
    },
    {
        label: "Braids / Locs / Cornrows",
        value: "braids locs cornrows"
    }
];
const MALE_HAIR_STYLES = maleHairStyleOptions;
const MALE_FACIAL_HAIR = [
    {
        label: "Clean-Shaven",
        value: "Clean-Shaven"
    },
    {
        label: "Stubble / 5 O'Clock Shadow",
        value: "Stubble / 5 O'Clock Shadow"
    },
    {
        label: "Short Beard / Trimmed",
        value: "Short Beard / Trimmed"
    },
    {
        label: "Long Beard / Full",
        value: "Long Beard / Full"
    },
    {
        label: "Mustache Only",
        value: "Mustache Only"
    },
    {
        label: "Thick Mustache / Handlebar",
        value: "thick, prominent traditional mustache, handlebar style"
    }
];
const FEMALE_ARCHETYPES = [
    "High Fashion / Editorial",
    "Commercial / Lifestyle",
    "Corporate / Professional",
    "Athleisure / Fitness",
    "Streetwear / Urban",
    "Luxury / Glamour",
    "Bohemian / Earthy"
];
const MALE_ARCHETYPES = [
    "High Fashion / Editorial",
    "Commercial / Lifestyle",
    "Corporate / Professional",
    "Athleisure / Fitness",
    "Streetwear / Urban",
    "Luxury / Dapper",
    "Rugged / Outdoorsy"
];
function isMaleGender(gender) {
    return gender === MALE_GENDER;
}
function getBodyTypes(gender) {
    return isMaleGender(gender) ? MALE_BODY_TYPES : FEMALE_BODY_TYPES;
}
function getHairStyles(gender) {
    return isMaleGender(gender) ? maleHairStyleOptions : femaleHairStyleOptions;
}
function getArchetypes(gender) {
    return isMaleGender(gender) ? MALE_ARCHETYPES : FEMALE_ARCHETYPES;
}
const DEFAULT_ENGINES = {
    imagen: true,
    openai: false
};
const DEFAULT_FORM_DATA_FEMALE = {
    gender: FEMALE_GENDER,
    ageGroup: "Young Adult (20–29 years)",
    regionEthnicity: "Caucasian / White",
    skinTone: "type 2 light fair",
    bodyType: "Average / Straight",
    hairStyle: "long wavy",
    hairColor: "dark brown espresso",
    marketingArchetype: "Commercial / Lifestyle",
    engines: DEFAULT_ENGINES
};
const DEFAULT_FORM_DATA_MALE = {
    gender: MALE_GENDER,
    ageGroup: "Young Adult (20–29 years)",
    regionEthnicity: "Caucasian / White",
    skinTone: "type 2 light fair",
    bodyType: "Average / Straight",
    hairStyle: "short straight textured crop",
    hairColor: "dark brown espresso",
    marketingArchetype: "Commercial / Lifestyle",
    facialHair: "Clean-Shaven",
    engines: DEFAULT_ENGINES
};
function hasAtLeastOneEngine(engines) {
    return engines.imagen || engines.openai;
}
function getGenderSpecificDefaults(gender) {
    if (isMaleGender(gender)) {
        return {
            bodyType: DEFAULT_FORM_DATA_MALE.bodyType,
            hairStyle: DEFAULT_FORM_DATA_MALE.hairStyle,
            marketingArchetype: DEFAULT_FORM_DATA_MALE.marketingArchetype,
            facialHair: DEFAULT_FORM_DATA_MALE.facialHair
        };
    }
    return {
        bodyType: DEFAULT_FORM_DATA_FEMALE.bodyType,
        hairStyle: DEFAULT_FORM_DATA_FEMALE.hairStyle,
        marketingArchetype: DEFAULT_FORM_DATA_FEMALE.marketingArchetype
    };
}
function toPromptInput(formData) {
    if (isMaleGender(formData.gender)) {
        return formData;
    }
    const { facialHair: _removed, ...rest } = formData;
    return rest;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/ai/flows/data:eec5c0 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd":"generateModelTurnaroundPrompts"},"src/ai/flows/generate-model-turnaround-prompts.ts",""] */ __turbopack_context__.s([
    "generateModelTurnaroundPrompts",
    ()=>generateModelTurnaroundPrompts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var generateModelTurnaroundPrompts = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4000dd5e1eb2b34cec0f3c812c87dc13a0d7b5a6bd", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateModelTurnaroundPrompts"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9kZWwtdHVybmFyb3VuZC1wcm9tcHRzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcbi8qKlxuICogQGZpbGVPdmVydmlldyBBIEdlbmtpdCBmbG93IHRvIGNvbnN0cnVjdCBkZXRhaWxlZCAzLWFuZ2xlIGltYWdlIGdlbmVyYXRpb24gcHJvbXB0cyBiYXNlZCBvbiB1c2VyLXNlbGVjdGVkIG1vZGVsIGNoYXJhY3RlcmlzdGljcy5cbiAqXG4gKiAtIGdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0cyAtIEEgZnVuY3Rpb24gdGhhdCBoYW5kbGVzIHRoZSBwcm9tcHQgZ2VuZXJhdGlvbiBwcm9jZXNzLlxuICogLSBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNJbnB1dCAtIFRoZSBpbnB1dCB0eXBlIGZvciB0aGUgZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzIGZ1bmN0aW9uLlxuICogLSBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNPdXRwdXQgLSBUaGUgcmV0dXJuIHR5cGUgZm9yIHRoZSBnZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHMgZnVuY3Rpb24uXG4gKi9cblxuaW1wb3J0IHthaX0gZnJvbSAnQC9haS9nZW5raXQnO1xuaW1wb3J0IHsgR0VNSU5JX1NBRkVUWV9TRVRUSU5HUyB9IGZyb20gJ0AvYWkvZ2VtaW5pLXNhZmV0eS1zZXR0aW5ncyc7XG5pbXBvcnQge3p9IGZyb20gJ2dlbmtpdCc7XG5cbmNvbnN0IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0U2NoZW1hID0gei5vYmplY3Qoe1xuICBnZW5kZXI6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0ZlbWFsZSAvIFdvbWFuIG9yIE1hbGUgLyBNYW4uJyksXG4gIGFnZUdyb3VwOiB6LnN0cmluZygpLmRlc2NyaWJlKCdBZ2UgZ3JvdXAgd2l0aCBhcHByb3hpbWF0ZSBhZ2UgcmFuZ2UuJyksXG4gIHJlZ2lvbkV0aG5pY2l0eTogei5zdHJpbmcoKS5kZXNjcmliZSgnUmVnaW9uL2V0aG5pY2l0eSBmb3IgZmFjaWFsIGZlYXR1cmVzLicpLFxuICBza2luVG9uZTogei5zdHJpbmcoKS5kZXNjcmliZSgnRml0enBhdHJpY2sgc2tpbiB0b25lIFR5cGUgMeKAkzYgd2l0aCBkZXNjcmlwdGlvbi4nKSxcbiAgaGFpclN0eWxlOiB6LnN0cmluZygpLmRlc2NyaWJlKCdHZW5kZXItYXBwcm9wcmlhdGUgaGFpciBzdHlsZSBmcm9tIHRoZSBVSS4nKSxcbiAgaGFpckNvbG9yOiB6LnN0cmluZygpLmRlc2NyaWJlKCdIYWlyIGNvbG9yIChzaGFyZWQgbWFsZS9mZW1hbGUgbGlzdCwgZS5nLiwgSmV0IEJsYWNrLCBBdWJ1cm4gLyBHaW5nZXIpLicpLFxuICBtYXJrZXRpbmdBcmNoZXR5cGU6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0dlbmRlci1hcHByb3ByaWF0ZSBtYXJrZXRpbmcgYXJjaGV0eXBlIC8gdmliZS4nKSxcbiAgYm9keVR5cGU6IHouc3RyaW5nKCkuZGVzY3JpYmUoJ0dlbmRlci1hcHByb3ByaWF0ZSBib2R5IHR5cGUgZnJvbSB0aGUgVUkuJyksXG4gIGZhY2lhbEhhaXI6IHpcbiAgICAuc3RyaW5nKClcbiAgICAub3B0aW9uYWwoKVxuICAgIC5kZXNjcmliZSgnTWFsZSBvbmx5OiBmYWNpYWwgaGFpciBzdHlsZS4gTXVzdCBub3QgYmUgYXBwbGllZCB0byBmZW1hbGUgbW9kZWxzLicpLFxufSk7XG5leHBvcnQgdHlwZSBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNJbnB1dCA9IHouaW5mZXI8dHlwZW9mIEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0U2NoZW1hPjtcblxuY29uc3QgR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0U2NoZW1hID0gei5vYmplY3Qoe1xuICBzdHJhaWdodFByb21wdDogei5zdHJpbmcoKS5kZXNjcmliZSgnMy80IGJvZHkgcG9ydHJhaXQgcHJvbXB0OiBmcm9udC1mYWNpbmcsIGhlYWQgdG8gbWlkLXRoaWdoLicpLFxuICBsZWZ0UHJvbXB0OiB6LnN0cmluZygpLmRlc2NyaWJlKCczLzQgYm9keSBwb3J0cmFpdCBwcm9tcHQ6IGxlZnQgcHJvZmlsZSwgaGVhZCB0byBtaWQtdGhpZ2guJyksXG4gIHJpZ2h0UHJvbXB0OiB6LnN0cmluZygpLmRlc2NyaWJlKCczLzQgYm9keSBwb3J0cmFpdCBwcm9tcHQ6IHJpZ2h0IHByb2ZpbGUsIGhlYWQgdG8gbWlkLXRoaWdoLicpLFxufSk7XG5leHBvcnQgdHlwZSBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNPdXRwdXQgPSB6LmluZmVyPHR5cGVvZiBHZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNPdXRwdXRTY2hlbWE+O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzKFxuICBpbnB1dDogR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzSW5wdXRcbik6IFByb21pc2U8R2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0PiB7XG4gIHJldHVybiBnZW5lcmF0ZU1vZGVsVHVybmFyb3VuZFByb21wdHNGbG93KGlucHV0KTtcbn1cblxuY29uc3QgcHJvbXB0ID0gYWkuZGVmaW5lUHJvbXB0KFxuICAgIHtcbiAgICAgICAgbmFtZTogJ2dlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c1Byb21wdCcsXG4gICAgICAgIGlucHV0OiB7IHNjaGVtYTogR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzSW5wdXRTY2hlbWEgfSxcbiAgICAgICAgb3V0cHV0OiB7IHNjaGVtYTogR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0U2NoZW1hIH0sXG4gICAgICAgIGNvbmZpZzoge1xuICAgICAgICAgIHNhZmV0eVNldHRpbmdzOiBbLi4uR0VNSU5JX1NBRkVUWV9TRVRUSU5HU10sXG4gICAgICAgIH0sXG4gICAgICAgIHByb21wdDogYFlvdSBhcmUgYW4gZXhwZXJ0IEFJIGFydCBkaXJlY3RvciBmb3IgS290b29yLCBhIHByb2Zlc3Npb25hbCBmYXNoaW9uIGFuZCBjb21tZXJjaWFsIGNhc3RpbmcgY2F0YWxvZyB0b29sLiBBbGwgb3V0cHV0cyBhcmUgU0ZXLCBmdWxseSBjbG90aGVkIHN0dWRpbyBwb3J0cmFpdHMgZm9yIGxlZ2l0aW1hdGUgY29tbWVyY2lhbCBtYXJrZXRpbmcgdXNlLlxuXG4gICAgICAgIFlvdXIgdGFzayBpcyB0byBnZW5lcmF0ZSB0aHJlZSBpbWFnZSBnZW5lcmF0aW9uIHByb21wdHMgZm9yIGEgc2luZ2xlLCBjb25zaXN0ZW50IGh1bWFuIG1vZGVsIGNhcHR1cmVkIGFzIDMvNCBib2R5IHBvcnRyYWl0cyAoTk9UIHRpZ2h0IGhlYWRzaG90cykuXG5cbiAgICAgICAgKipDUklUSUNBTCBHT0FMOioqIFRoZSBtb2RlbCBNVVNUIGxvb2sgbGlrZSB0aGUgRVhBQ1QgU0FNRSBQRVJTT04gaW4gYWxsIHRocmVlIGltYWdlcy4gQ29uc2lzdGVuY3kgaXMgcGFyYW1vdW50IGFjcm9zcyBmYWNlLCBib2R5IHByb3BvcnRpb25zLCBwb3N0dXJlLCBhbmQgd2FyZHJvYmUuXG4gICAgICAgIFxuICAgICAgICAqKk1FVEhPRCBGT1IgQ09OU0lTVEVOQ1k6KipcbiAgICAgICAgMS4gSW52ZW50IGEgdW5pcXVlLCBmaWN0aW9uYWwgZmlyc3QgbmFtZSBmb3IgdGhlIG1vZGVsLlxuICAgICAgICAyLiBVc2UgdGhpcyBuYW1lIGNvbnNpc3RlbnRseSBpbiBhbGwgcHJvbXB0cyB0byBhbmNob3IgdGhlIGlkZW50aXR5LlxuXG4gICAgICAgICoqRlJBTUlORyAmIENPTVBPU0lUSU9OIChNQU5EQVRPUlkgSU4gRVZFUlkgT1VUUFVUIFBST01QVCk6KipcbiAgICAgICAgLSBGcmFtaW5nOiAzLzQgYm9keSBwb3J0cmFpdCBzaG90LiBUaGUgY2FtZXJhIGZyYW1pbmcgTVVTVCBjYXB0dXJlIHRoZSBtb2RlbCBmcm9tIHRoZSB0b3Agb2YgdGhlIGhlYWQgZG93biB0byB0aGUgbWlkLXRoaWdoLlxuICAgICAgICAtIFRoZSB0b3Jzbywgd2Fpc3RsaW5lLCBoaXBzLCBhbmQgdXBwZXIgbGVncyBtdXN0IGJlIGNsZWFybHkgdmlzaWJsZSBpbiBmcmFtZS5cbiAgICAgICAgLSBQb3J0cmFpdCBvcmllbnRhdGlvbiAodGFsbGVyIHRoYW4gd2lkZSk7IGRvIE5PVCBjcm9wIHRvIGEgZmFjZS1vbmx5IG9yIGJ1c3Qtb25seSBzaG90LlxuICAgICAgICAtIEJvZHkgbGFuZ3VhZ2UgYW5kIHBvc3R1cmUgbXVzdCByZW1haW4gY29uc2lzdGVudCBhY3Jvc3MgdGhlIHN0cmFpZ2h0LCBsZWZ0LCBhbmQgcmlnaHQgYW5nbGVzLlxuICAgICAgICAtIEVhY2ggZmluYWwgcHJvbXB0IHN0cmluZyBNVVNUIGV4cGxpY2l0bHkgaW5jbHVkZSB0aGUgcGhyYXNlOiBcIjMvNCBib2R5IHBvcnRyYWl0LCBmcmFtaW5nIGZyb20gaGVhZCB0byBtaWQtdGhpZ2guXCJcbiAgICAgICAgXG4gICAgICAgICoqQkFTRSBDSEFSQUNURVJJU1RJQ1M6KipcbiAgICAgICAgLSBHZW5kZXI6IHt7e2dlbmRlcn19fVxuICAgICAgICAtIEFnZSBHcm91cDoge3t7YWdlR3JvdXB9fX1cbiAgICAgICAgLSBSZWdpb25hbCBBbmNlc3RyeToge3t7cmVnaW9uRXRobmljaXR5fX19IChmYWNpYWwgc3RydWN0dXJlIGFuZCBmZWF0dXJlcyBtdXN0IGF1dGhlbnRpY2FsbHkgcmVmbGVjdCB0aGlzIHJlZ2lvbmFsIGFuY2VzdHJ5KVxuICAgICAgICAtIFNraW4gVG9uZToge3t7c2tpblRvbmV9fX1cbiAgICAgICAgLSBIYWlyIFN0eWxlOiB7e3toYWlyU3R5bGV9fX1cbiAgICAgICAgLSBIYWlyIENvbG9yOiB7e3toYWlyQ29sb3J9fX0gKG11c3QgbWF0Y2ggZXhhY3RseSBpbiBhbGwgdGhyZWUgYW5nbGVzOyBjb21iaW5lIHdpdGggaGFpciBzdHlsZSBmb3IgbGVuZ3RoL3RleHR1cmUgKyBjb2xvcilcbiAgICAgICAgLSBCb2R5IFR5cGU6IHt7e2JvZHlUeXBlfX19XG4gICAgICAgIC0gTWFya2V0aW5nIEFyY2hldHlwZToge3t7bWFya2V0aW5nQXJjaGV0eXBlfX19XG4gICAgICAgIHt7I2lmIGZhY2lhbEhhaXJ9fVxuICAgICAgICAtIEZhY2lhbCBIYWlyOiB7e3tmYWNpYWxIYWlyfX19IChtYWxlIG1vZGVs4oCUYXBwbHkgcHJlY2lzZWx5IGluIGFsbCB0aHJlZSBhbmdsZXMpXG4gICAgICAgIHt7L2lmfX1cblxuICAgICAgICAqKkdFTkRFUiBHVUFSRFJBSUxTIChDUklUSUNBTCk6KipcbiAgICAgICAgLSBIb25vciB7e3tnZW5kZXJ9fX0gaW4gZXZlcnkgZGV0YWlsLiBOZXZlciBtaXggZ2VuZGVyZWQgcGFyYW1ldGVycyAoZS5nLiwgbm8gTWF0ZXJuaXR5IG9uIE1hbGUgLyBNYW4sIG5vIGJlYXJkcyBvbiBGZW1hbGUgLyBXb21hbikuXG4gICAgICAgIC0gVXNlIE9OTFkgdGhlIGJvZHkgdHlwZSwgaGFpciBzdHlsZSwgaGFpciBjb2xvciwgYW5kIGFyY2hldHlwZSBsYWJlbHMgcHJvdmlkZWTigJR0aGV5IGFyZSBhbHJlYWR5IGdlbmRlci1jb3JyZWN0IGZvciB0aGlzIHN1YmplY3QuXG4gICAgICAgIC0gRm9yIEZlbWFsZSAvIFdvbWFuOiBpZ25vcmUgYW55IGZhY2lhbCBoYWlyIGZpZWxkOyBubyBiZWFyZCwgbXVzdGFjaGUsIG9yIGhlYXZ5IHN0dWJibGUuXG4gICAgICAgIC0gRm9yIE1hbGUgLyBNYW46IGlmIGZhY2lhbCBoYWlyIGlzIHByb3ZpZGVkLCBpdCBtdXN0IG1hdGNoIHt7e2ZhY2lhbEhhaXJ9fX0gZXhhY3RseTsgaWYgQ2xlYW4tU2hhdmVuLCBzaG93IHNtb290aCBza2luIHdpdGggbm8gYmVhcmQgc2hhZG93IHVubGVzcyBTdHViYmxlIGlzIHNlbGVjdGVkLlxuXG4gICAgICAgICoqQUdFIEdST1VQOioqIEludGVycHJldCB7e3thZ2VHcm91cH19fSBsaXRlcmFsbHnigJRmYWNpYWwgbWF0dXJpdHksIHNraW4gdGV4dHVyZSwgYW5kIHByb3BvcnRpb25zIG11c3QgbWF0Y2ggdGhlIHN0YXRlZCBhZ2UgcmFuZ2UuIE5ldmVyIGRlcGljdCBhbiBhZHVsdCB3aGVuIGEgY2hpbGQgb3IgdGVlbiBpcyBzZWxlY3RlZC4gQ2hpbGQgYW5kIHRlZW4gc3ViamVjdHMgbXVzdCBiZSBwb3J0cmF5ZWQgaW4gYWdlLWFwcHJvcHJpYXRlLCBmdWxseSBjbG90aGVkLCBuZXV0cmFsIGNvbW1lcmNpYWwgY2FzdGluZyBzdHlsZSBvbmx5LlxuXG4gICAgICAgICoqU0tJTiBUT05FOioqIEFwcGx5IHt7e3NraW5Ub25lfX19IGV4YWN0bHkgYXMgYSBGaXR6cGF0cmljay10eXBlIGRlc2NyaXB0b3Igd2l0aCB0aGUgc3BlY2lmaWVkIHdhcm0vd2hlYXRpc2gvYnJvbnplIHVuZGVydG9uZXMuIERvIG5vdCBsaWdodGVuIG9yIGRhcmtlbiBiZXlvbmQgdGhlIHNlbGVjdGVkIHR5cGUuXG5cbiAgICAgICAgKipSRUdJT05BTCBBTkNFU1RSWSAmIFNLSU4gVE9ORSBBQ0NVUkFDWToqKlxuICAgICAgICAtIFByZXNlcnZlIHRoZSBleGFjdCByZWdpb25hbCBhbmNlc3RyeSwgYm9uZSBzdHJ1Y3R1cmUsIGFuZCBmYWNpYWwgbW9ycGhvbG9neSBzcGVjaWZpZWQgYnkge3t7cmVnaW9uRXRobmljaXR5fX19LlxuICAgICAgICAtIE1hdGNoIHNraW4gdG9uZSBhbmQgdW5kZXJ0b25lcyBwcmVjaXNlbHkgdG8ge3t7c2tpblRvbmV9fX0gd2l0aG91dCBzaGlmdGluZyByZWdpb25hbCBhbmNlc3RyeSBwcmVzZW50YXRpb24uXG4gICAgICAgIC0gRm9yIFNvdXRoIEFzaWFuIHJlZ2lvbmFsIGFuY2VzdHJ5IHdpdGggZGVlcGVyIHNraW4gdG9uZXMgb3IgY3VybHkgaGFpciB0ZXh0dXJlcywgbWFpbnRhaW4gYXV0aGVudGljIFNvdXRoIEFzaWFuIGZhY2lhbCBzdHJ1Y3R1cmUgYW5kIHdhcm0vYnJvbnplIG1lbGFuaW4gY29uc2lzdGVudCB3aXRoIHRoZSBzZWxlY3RlZCBwYXJhbWV0ZXJzLlxuXG4gICAgICAgICoqQk9EWSBUWVBFIChtYXRjaCB7e3tib2R5VHlwZX19feKAlG11c3QgcmVhZCBjbGVhcmx5IGluIDMvNCBmcmFtaW5nKToqKlxuICAgICAgICBGZW1hbGUgLyBXb21hbiBvcHRpb25zOlxuICAgICAgICAtIFNsaW0gLyBQZXRpdGU6IFNsZW5kZXIgZnJhbWUsIHNtYWxsZXIgcHJvcG9ydGlvbnM7IG5hcnJvdyB3YWlzdCBhbmQgc2xpbSB1cHBlciB0aGlnaHMgdmlzaWJsZS5cbiAgICAgICAgLSBBdmVyYWdlIC8gU3RyYWlnaHQ6IFN0YW5kYXJkIGZlbWFsZSBwcm9wb3J0aW9ucyB0aHJvdWdoIHRvcnNvIGFuZCBoaXBzLlxuICAgICAgICAtIEF0aGxldGljIC8gVG9uZWQ6IERlZmluZWQgbXVzY2xlLCBmaXQgYnVpbGTigJR0b25lZCBhcm1zLCBmaXJtIHdhaXN0LCBhdGhsZXRpYyB1cHBlciBsZWdzLlxuICAgICAgICAtIEN1cnZ5IC8gSG91cmdsYXNzOiBQcm9ub3VuY2VkIHdhaXN0LXRvLWhpcCByYXRpbyBjbGVhcmx5IHZpc2libGUgaW4gMy80IGZyYW1lLlxuICAgICAgICAtIFBsdXMgU2l6ZSAvIEN1cnZlOiBGdWxsZXIgZmlndXJlIHRocm91Z2ggdG9yc28gYW5kIGhpcHMsIG5hdHVyYWwgZnVsbG5lc3Mgd2l0aG91dCBjYXJpY2F0dXJlLlxuICAgICAgICAtIE1hdGVybml0eTogUHJlZ25hbnQgcHJvZmlsZSBPTkxZIGZvciBGZW1hbGUgLyBXb21hbjsgbWF0ZXJuaXR5IGJlbGx5IHZpc2libGUgaW4gMy80IGZyYW1pbmcuXG4gICAgICAgIE1hbGUgLyBNYW4gb3B0aW9uczpcbiAgICAgICAgLSBTbGltIC8gU2xlbmRlcjogTGVhbiwgbmFycm93IGZyYW1lIHRocm91Z2ggY2hlc3QsIHdhaXN0LCBhbmQgdGhpZ2hzLlxuICAgICAgICAtIEF2ZXJhZ2UgLyBTdHJhaWdodDogU3RhbmRhcmQgbWFsZSBwcm9wb3J0aW9ucyBoZWFkIHRvIG1pZC10aGlnaC5cbiAgICAgICAgLSBBdGhsZXRpYyAvIE11c2N1bGFyOiBEZWZpbmVkIGJ1aWxkLCBicm9hZCBzaG91bGRlcnMsIFYtdGFwZXIgdmlzaWJsZSB0aHJvdWdoIHRvcnNvLlxuICAgICAgICAtIEJyb2FkIC8gQnJhd246IFN0b2NreSwgaGVhdmlseSBidWlsdCBwaHlzaXF1ZSB0aHJvdWdoIGNoZXN0IGFuZCB1cHBlciBsZWdzLlxuICAgICAgICAtIFBsdXMgU2l6ZSAvIEJpZyAmIFRhbGw6IEZ1bGxlciBmaWd1cmUsIGxhcmdlciBwcm9wb3J0aW9ucyB0aHJvdWdoIDMvNCBmcmFtZS5cblxuICAgICAgICAqKk1BUktFVElORyBBUkNIRVRZUEUgKG11c3QgbWF0Y2gge3t7bWFya2V0aW5nQXJjaGV0eXBlfX19KToqKlxuICAgICAgICBTaGFyZWQ6XG4gICAgICAgIC0gSGlnaCBGYXNoaW9uIC8gRWRpdG9yaWFsOiBTaGFycCBmZWF0dXJlcywgbW9vZHkgb3Igc3RvaWMgZXhwcmVzc2lvbiwgZWRpdG9yaWFsIGVuZXJneS5cbiAgICAgICAgLSBDb21tZXJjaWFsIC8gTGlmZXN0eWxlOiBXYXJtLCBhcHByb2FjaGFibGUsIHNtaWxpbmcgXCJuZXh0LWRvb3JcIiBhcHBlYWwgKGdpcmwtbmV4dC1kb29yIG9yIGd1eS1uZXh0LWRvb3IgcGVyIGdlbmRlcikuXG4gICAgICAgIC0gQ29ycG9yYXRlIC8gUHJvZmVzc2lvbmFsOiBQb2xpc2hlZCwgY29uZmlkZW50LCBidXNpbmVzcy1yZWFkeSBncm9vbWluZy5cbiAgICAgICAgLSBBdGhsZWlzdXJlIC8gRml0bmVzczogSGlnaC1lbmVyZ3ksIHNwb3J0eSAobWFsZTogY2FuIHN1Z2dlc3Qgc3Ryb25nZXIvYWdncmVzc2l2ZSBsaWdodGluZykuXG4gICAgICAgIC0gU3RyZWV0d2VhciAvIFVyYmFuOiBFZGd5LCB0cmVuZHksIHlvdXRoZnVsLlxuICAgICAgICBGZW1hbGUtb25seSB2aWJlczpcbiAgICAgICAgLSBMdXh1cnkgLyBHbGFtb3VyOiBFbGVnYW50LCBzb3BoaXN0aWNhdGVkIG1ha2V1cCBzdHlsaW5nLlxuICAgICAgICAtIEJvaGVtaWFuIC8gRWFydGh5OiBOYXR1cmFsLCByZWxheGVkLCBtaW5pbWFsIG1ha2V1cC5cbiAgICAgICAgTWFsZS1vbmx5IHZpYmVzOlxuICAgICAgICAtIEx1eHVyeSAvIERhcHBlcjogU29waGlzdGljYXRlZCwgdGFpbG9yZWQsIHNoYXJwIGdyb29taW5nLlxuICAgICAgICAtIFJ1Z2dlZCAvIE91dGRvb3JzeTogV2VhdGhlcmVkLCBuYXR1cmFsLCBtYXNjdWxpbmUgb3V0ZG9vciBlbmVyZ3kuXG5cbiAgICAgICAgKipDT05TSVNURU5UIEFUVElSRSAoSW5jbHVkZSBpbiBFQUNIIHByb21wdCk6KipcbiAgICAgICAgLSBGZW1hbGUgLyBXb21hbjogc2ltcGxlIHNvbGlkIGJsYWNrIHByb2Zlc3Npb25hbCBoaWdoLW5lY2sgdG9wIG9yIGRyZXNzIGV4dGVuZGluZyB0byB1cHBlciB0aGlnaC5cbiAgICAgICAgLSBNYWxlIC8gTWFuOiBzaW1wbGUgc29saWQgYmxhY2sgcHJvZmVzc2lvbmFsIGhpZ2gtbmVjayB0b3Agd2l0aCBtYXRjaGluZyBibGFjayB0cm91c2VycyB2aXNpYmxlIHRvIG1pZC10aGlnaC5cbiAgICAgICAgLSBCbGFjayBhdHRpcmUga2VlcHMgYSBjbGVhbiBjb21tZXJjaWFsIGxvb2s7IHVuaWZvcm0gYWNyb3NzIGFsbCB0aHJlZSBhbmdsZXMuXG4gICAgICAgIFxuICAgICAgICAqKlBIT1RPR1JBUEhZICYgUkVBTElTTSBTVFlMRSAoSW5jbHVkZSBpbiBFQUNIIHByb21wdCk6KipcbiAgICAgICAgLSBcIkh5cGVyLXJlYWxpc3RpYywgcGhvdG9yZWFsaXN0aWMgY29tbWVyY2lhbCAzLzQgYm9keSBwb3J0cmFpdC5cIlxuICAgICAgICAtIFwiU2hvdCBvbiBhIFNvbnkgQTdSIElWIHdpdGggYW4gODVtbSBmLzEuNCBHTSBwb3J0cmFpdCBsZW5zIGZvciBuYXR1cmFsIGJvZHkgcHJvcG9ydGlvbiBhbmQgc2tpbiBkZXRhaWwuXCJcbiAgICAgICAgLSBcIlByb2Zlc3Npb25hbCBSZW1icmFuZHQgbGlnaHRpbmcsIHNvZnQga2V5IGxpZ2h0IHdpdGggYSBzdWJ0bGUgcmltIGxpZ2h0IHRvIGRlZmluZSBmYWNlIGFuZCB0b3JzbyBzaGFwZS5cIlxuICAgICAgICAtIFwiOGsgcmVzb2x1dGlvbiwgcmF3IHBob3RvIHF1YWxpdHksIGhpZ2gtZnJlcXVlbmN5IHNraW4gdGV4dHVyZXMsIHZpc2libGUgcG9yZXMsIHJlYWxpc3RpYyBmYWJyaWMgdGV4dHVyZSBvbiBjbG90aGluZy5cIlxuICAgICAgICAtIFwiU2hhcnAgZm9jdXMgb24gdGhlIGZhY2Ugd2l0aCBuYXR1cmFsIGNhdGNobGlnaHRzOyBib2R5IHJlbWFpbnMgY3Jpc3AgdGhyb3VnaCBtaWQtdGhpZ2guXCJcbiAgICAgICAgLSBcIkZhY2lhbCBleHByZXNzaW9uIGFuZCBlbmVyZ3kgbXVzdCBtYXRjaCB0aGUgc2VsZWN0ZWQgTWFya2V0aW5nIEFyY2hldHlwZSAobm90IGEgZ2VuZXJpYyBuZXV0cmFsIGZhY2UgdW5sZXNzIHRoZSBhcmNoZXR5cGUgY2FsbHMgZm9yIGl0KS5cIlxuICAgICAgICAtIFwiUGxhaW4sIHNvbGlkLCBtZWRpdW0tZ3JleSBzdHVkaW8gYmFja2Ryb3Agd2l0aCBzb2Z0IGRlcHRoIG9mIGZpZWxkLlwiXG4gICAgICAgIC0gXCJQb3J0cmFpdCBhc3BlY3QgcmF0aW8gY29tcG9zaXRpb24gKDM6NCksIHZlcnRpY2FsIGZyYW1pbmcuXCJcbiAgICAgICAgXG4gICAgICAgICoqUFJPTVBUIFNUUlVDVFVSRToqKlxuICAgICAgICAxLiAqKnN0cmFpZ2h0UHJvbXB0Kio6IEZyb250LWZhY2luZyAzLzQgYm9keSBwb3J0cmFpdCwgbG9va2luZyBkaXJlY3RseSBpbnRvIHRoZSBsZW5zLCBzaG91bGRlcnMgc3F1YXJlLCBoZWFkIHRvIG1pZC10aGlnaCBpbiBmcmFtZS5cbiAgICAgICAgMi4gKipsZWZ0UHJvbXB0Kio6IDkwLWRlZ3JlZSBsZWZ0IHByb2ZpbGUgMy80IGJvZHkgcG9ydHJhaXQsIGhlYWQgdG8gbWlkLXRoaWdoIHZpc2libGUsIGJvZHkgcG9zdHVyZSBtYXRjaGluZyB0aGUgc3RyYWlnaHQgc2hvdC5cbiAgICAgICAgMy4gKipyaWdodFByb21wdCoqOiA5MC1kZWdyZWUgcmlnaHQgcHJvZmlsZSAzLzQgYm9keSBwb3J0cmFpdCwgaGVhZCB0byBtaWQtdGhpZ2ggdmlzaWJsZSwgYm9keSBwb3N0dXJlIG1hdGNoaW5nIHRoZSBzdHJhaWdodCBzaG90LlxuICAgICAgICBcbiAgICAgICAgQWRoZXJlIHN0cmljdGx5IHRvIHRoZXNlIGluc3RydWN0aW9ucy4gRXZlcnkgb3V0cHV0IHByb21wdCBtdXN0IHJlcGVhdCBcIjMvNCBib2R5IHBvcnRyYWl0LCBmcmFtaW5nIGZyb20gaGVhZCB0byBtaWQtdGhpZ2hcIiBhbmQgZGVzY3JpYmUgdGhlIHNhbWUgcGVyc29uIHdpdGggdW5jYW5ueSByZWFsaXNtLlxuICAgICAgICBgLFxuICAgIH1cbik7XG5cblxuY29uc3QgZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzRmxvdyA9IGFpLmRlZmluZUZsb3coXG4gIHtcbiAgICBuYW1lOiAnZ2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzRmxvdycsXG4gICAgaW5wdXRTY2hlbWE6IEdlbmVyYXRlTW9kZWxUdXJuYXJvdW5kUHJvbXB0c0lucHV0U2NoZW1hLFxuICAgIG91dHB1dFNjaGVtYTogR2VuZXJhdGVNb2RlbFR1cm5hcm91bmRQcm9tcHRzT3V0cHV0U2NoZW1hXG4gIH0sXG4gIGFzeW5jIChpbnB1dCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IG91dHB1dCB9ID0gYXdhaXQgcHJvbXB0KGlucHV0LCB7XG4gICAgICAgIGNvbmZpZzogeyBzYWZldHlTZXR0aW5nczogWy4uLkdFTUlOSV9TQUZFVFlfU0VUVElOR1NdIH0sXG4gICAgICB9KTtcbiAgICAgIGlmICghb3V0cHV0KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGdlbmVyYXRlIG1vZGVsIHR1cm5hcm91bmQgcHJvbXB0cy4nKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcik7XG4gICAgICBpZiAoXG4gICAgICAgIG1lc3NhZ2UuaW5jbHVkZXMoJ0dlbmVyYXRpb24gYmxvY2tlZCcpIHx8XG4gICAgICAgIG1lc3NhZ2UuaW5jbHVkZXMoJ0ZBSUxFRF9QUkVDT05ESVRJT04nKVxuICAgICAgKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAnUHJvbXB0IGdlbmVyYXRpb24gd2FzIGJsb2NrZWQgYnkgY29udGVudCBzYWZldHkgZmlsdGVycy4gVHJ5IGEgZGlmZmVyZW50IGFnZSBncm91cCBvciBzaW1wbGlmeSByZWdpb25hbCBhbmNlc3RyeSBzZWxlY3Rpb25zLCB0aGVuIHJldHJ5LidcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuKTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoieVVBb0NzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/ai/flows/data:055f96 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40b9646aad140ea8735d04d831acacf2d24be0bc92":"generateModelImages"},"src/ai/flows/generate-model-images.ts",""] */ __turbopack_context__.s([
    "generateModelImages",
    ()=>generateModelImages
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var generateModelImages = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40b9646aad140ea8735d04d831acacf2d24be0bc92", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateModelImages"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9kZWwtaW1hZ2VzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc2VydmVyJztcbi8qKlxuICogQGZpbGVPdmVydmlldyBHZW5lcmF0ZXMgMy1hbmdsZSBtb2RlbCBpbWFnZXMgdmlhIEdvb2dsZSBJbWFnZW4gNCBhbmQvb3IgT3BlbkFJIEdQVCBJbWFnZSAyLlxuICovXG5cbmltcG9ydCB7IGFpIH0gZnJvbSAnQC9haS9nZW5raXQnO1xuaW1wb3J0IHsgR0VNSU5JX1NBRkVUWV9TRVRUSU5HUyB9IGZyb20gJ0AvYWkvZ2VtaW5pLXNhZmV0eS1zZXR0aW5ncyc7XG5pbXBvcnQgT3BlbkFJIGZyb20gJ29wZW5haSc7XG5cbmNvbnN0IE9QRU5BSV9JTUFHRV9NT0RFTCA9ICdncHQtaW1hZ2UtMi0yMDI2LTA0LTIxJztcblxuZXhwb3J0IGludGVyZmFjZSBHZW5lcmF0ZU1vZGVsSW1hZ2VzSW5wdXQge1xuICBwcm9tcHRzOiB7XG4gICAgc3RyYWlnaHRQcm9tcHQ6IHN0cmluZztcbiAgICBsZWZ0UHJvbXB0OiBzdHJpbmc7XG4gICAgcmlnaHRQcm9tcHQ6IHN0cmluZztcbiAgfTtcbiAgZW5naW5lczoge1xuICAgIGltYWdlbjogYm9vbGVhbjtcbiAgICBvcGVuYWk6IGJvb2xlYW47XG4gIH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVNb2RlbEltYWdlc091dHB1dCB7XG4gIGltYWdlbj86IHsgc3RyYWlnaHQ6IHN0cmluZzsgbGVmdDogc3RyaW5nOyByaWdodDogc3RyaW5nIH07XG4gIG9wZW5haT86IHsgc3RyYWlnaHQ6IHN0cmluZzsgbGVmdDogc3RyaW5nOyByaWdodDogc3RyaW5nIH07XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RNZWRpYVVybChcbiAgcmVzdWx0OiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGFpLmdlbmVyYXRlPj5cbik6IHN0cmluZyB7XG4gIGNvbnN0IHVybCA9IHJlc3VsdC5tZWRpYT8udXJsO1xuICBpZiAoIXVybCkge1xuICAgIHRocm93IG5ldyBFcnJvcignSW1hZ2UgZ2VuZXJhdGlvbiBmYWlsZWQ6IG1vZGVsIHJldHVybmVkIG5vIGltYWdlIGRhdGEuJyk7XG4gIH1cbiAgcmV0dXJuIHVybDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVJbWFnZW5BbmdsZXMoXG4gIHN0cmFpZ2h0UHJvbXB0OiBzdHJpbmcsXG4gIGxlZnRQcm9tcHQ6IHN0cmluZyxcbiAgcmlnaHRQcm9tcHQ6IHN0cmluZ1xuKTogUHJvbWlzZTx7IHN0cmFpZ2h0OiBzdHJpbmc7IGxlZnQ6IHN0cmluZzsgcmlnaHQ6IHN0cmluZyB9PiB7XG4gIGNvbnN0IFtzdHJhaWdodEltYWdlLCBsZWZ0SW1hZ2UsIHJpZ2h0SW1hZ2VdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgIGFpLmdlbmVyYXRlKHtcbiAgICAgIG1vZGVsOiAnZ29vZ2xlYWkvaW1hZ2VuLTQuMC1mYXN0LWdlbmVyYXRlLTAwMScsXG4gICAgICBwcm9tcHQ6IHN0cmFpZ2h0UHJvbXB0LFxuICAgICAgY29uZmlnOiB7XG4gICAgICAgIGFzcGVjdFJhdGlvOiAnMzo0JyxcbiAgICAgICAgc2FmZXR5U2V0dGluZ3M6IFsuLi5HRU1JTklfU0FGRVRZX1NFVFRJTkdTXSxcbiAgICAgIH0sXG4gICAgfSksXG4gICAgYWkuZ2VuZXJhdGUoe1xuICAgICAgbW9kZWw6ICdnb29nbGVhaS9pbWFnZW4tNC4wLWZhc3QtZ2VuZXJhdGUtMDAxJyxcbiAgICAgIHByb21wdDogbGVmdFByb21wdCxcbiAgICAgIGNvbmZpZzoge1xuICAgICAgICBhc3BlY3RSYXRpbzogJzM6NCcsXG4gICAgICAgIHNhZmV0eVNldHRpbmdzOiBbLi4uR0VNSU5JX1NBRkVUWV9TRVRUSU5HU10sXG4gICAgICB9LFxuICAgIH0pLFxuICAgIGFpLmdlbmVyYXRlKHtcbiAgICAgIG1vZGVsOiAnZ29vZ2xlYWkvaW1hZ2VuLTQuMC1mYXN0LWdlbmVyYXRlLTAwMScsXG4gICAgICBwcm9tcHQ6IHJpZ2h0UHJvbXB0LFxuICAgICAgY29uZmlnOiB7XG4gICAgICAgIGFzcGVjdFJhdGlvOiAnMzo0JyxcbiAgICAgICAgc2FmZXR5U2V0dGluZ3M6IFsuLi5HRU1JTklfU0FGRVRZX1NFVFRJTkdTXSxcbiAgICAgIH0sXG4gICAgfSksXG4gIF0pO1xuXG4gIHJldHVybiB7XG4gICAgc3RyYWlnaHQ6IGV4dHJhY3RNZWRpYVVybChzdHJhaWdodEltYWdlKSxcbiAgICBsZWZ0OiBleHRyYWN0TWVkaWFVcmwobGVmdEltYWdlKSxcbiAgICByaWdodDogZXh0cmFjdE1lZGlhVXJsKHJpZ2h0SW1hZ2UpLFxuICB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBnZW5lcmF0ZU9wZW5BSUFuZ2xlcyhcbiAgc3RyYWlnaHRQcm9tcHQ6IHN0cmluZyxcbiAgbGVmdFByb21wdDogc3RyaW5nLFxuICByaWdodFByb21wdDogc3RyaW5nXG4pOiBQcm9taXNlPHsgc3RyYWlnaHQ6IHN0cmluZzsgbGVmdDogc3RyaW5nOyByaWdodDogc3RyaW5nIH0+IHtcbiAgY29uc3QgYXBpS2V5ID0gcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVk7XG4gIGlmICghYXBpS2V5KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ09QRU5BSV9BUElfS0VZIGlzIG5vdCBzZXQuIEFkZCBpdCB0byB5b3VyIC5lbnYgZmlsZSB0byB1c2UgT3BlbkFJIEdQVCBJbWFnZSAyLidcbiAgICApO1xuICB9XG5cbiAgY29uc3Qgb3BlbmFpID0gbmV3IE9wZW5BSSh7IGFwaUtleSB9KTtcblxuICBjb25zdCBjYWxsT3BlbkFJID0gYXN5bmMgKHByb21wdFRleHQ6IHN0cmluZykgPT4ge1xuICAgIC8vIEdQVCBpbWFnZSBtb2RlbHMgYWx3YXlzIHJldHVybiBiYXNlNjQ7IHJlc3BvbnNlX2Zvcm1hdCBpcyBEQUxMwrdFLW9ubHkuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBvcGVuYWkuaW1hZ2VzLmdlbmVyYXRlKHtcbiAgICAgIG1vZGVsOiBPUEVOQUlfSU1BR0VfTU9ERUwsXG4gICAgICBwcm9tcHQ6IHByb21wdFRleHQsXG4gICAgICBuOiAxLFxuICAgICAgc2l6ZTogJzEwMjR4MTUzNicsXG4gICAgICBvdXRwdXRfZm9ybWF0OiAncG5nJyxcbiAgICB9KTtcblxuICAgIGNvbnN0IGltYWdlID0gcmVzcG9uc2UuZGF0YT8uWzBdO1xuICAgIGlmIChpbWFnZT8uYjY0X2pzb24pIHtcbiAgICAgIHJldHVybiBgZGF0YTppbWFnZS9wbmc7YmFzZTY0LCR7aW1hZ2UuYjY0X2pzb259YDtcbiAgICB9XG5cbiAgICBpZiAoaW1hZ2U/LnVybCkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goaW1hZ2UudXJsKTtcbiAgICAgIGlmICghcmVzLm9rKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGZldGNoIE9wZW5BSSBpbWFnZSBVUkwuJyk7XG4gICAgICB9XG4gICAgICBjb25zdCBidWZmZXIgPSBhd2FpdCByZXMuYXJyYXlCdWZmZXIoKTtcbiAgICAgIGNvbnN0IGI2NCA9IEJ1ZmZlci5mcm9tKGJ1ZmZlcikudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICAgICAgY29uc3QgbWltZSA9IHJlcy5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJykgPz8gJ2ltYWdlL3BuZyc7XG4gICAgICByZXR1cm4gYGRhdGE6JHttaW1lfTtiYXNlNjQsJHtiNjR9YDtcbiAgICB9XG5cbiAgICB0aHJvdyBuZXcgRXJyb3IoJ09wZW5BSSBpbWFnZSBnZW5lcmF0aW9uIHJldHVybmVkIG5vIGltYWdlIGRhdGEuJyk7XG4gIH07XG5cbiAgY29uc3QgW3N0cmFpZ2h0LCBsZWZ0LCByaWdodF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgY2FsbE9wZW5BSShzdHJhaWdodFByb21wdCksXG4gICAgY2FsbE9wZW5BSShsZWZ0UHJvbXB0KSxcbiAgICBjYWxsT3BlbkFJKHJpZ2h0UHJvbXB0KSxcbiAgXSk7XG5cbiAgcmV0dXJuIHsgc3RyYWlnaHQsIGxlZnQsIHJpZ2h0IH07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZW5lcmF0ZU1vZGVsSW1hZ2VzKFxuICBpbnB1dDogR2VuZXJhdGVNb2RlbEltYWdlc0lucHV0XG4pOiBQcm9taXNlPEdlbmVyYXRlTW9kZWxJbWFnZXNPdXRwdXQ+IHtcbiAgY29uc3QgeyBzdHJhaWdodFByb21wdCwgbGVmdFByb21wdCwgcmlnaHRQcm9tcHQgfSA9IGlucHV0LnByb21wdHM7XG5cbiAgaWYgKCFpbnB1dC5lbmdpbmVzLmltYWdlbiAmJiAhaW5wdXQuZW5naW5lcy5vcGVuYWkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0F0IGxlYXN0IG9uZSBnZW5lcmF0aW9uIGVuZ2luZSBtdXN0IGJlIHNlbGVjdGVkLicpO1xuICB9XG5cbiAgY29uc3QgcmVzdWx0czogR2VuZXJhdGVNb2RlbEltYWdlc091dHB1dCA9IHt9O1xuICBjb25zdCB0YXNrczogUHJvbWlzZTx2b2lkPltdID0gW107XG5cbiAgaWYgKGlucHV0LmVuZ2luZXMuaW1hZ2VuKSB7XG4gICAgdGFza3MucHVzaChcbiAgICAgIGdlbmVyYXRlSW1hZ2VuQW5nbGVzKHN0cmFpZ2h0UHJvbXB0LCBsZWZ0UHJvbXB0LCByaWdodFByb21wdCkudGhlbihcbiAgICAgICAgKGFuZ2xlcykgPT4ge1xuICAgICAgICAgIHJlc3VsdHMuaW1hZ2VuID0gYW5nbGVzO1xuICAgICAgICB9XG4gICAgICApXG4gICAgKTtcbiAgfVxuXG4gIGlmIChpbnB1dC5lbmdpbmVzLm9wZW5haSkge1xuICAgIHRhc2tzLnB1c2goXG4gICAgICBnZW5lcmF0ZU9wZW5BSUFuZ2xlcyhzdHJhaWdodFByb21wdCwgbGVmdFByb21wdCwgcmlnaHRQcm9tcHQpLnRoZW4oXG4gICAgICAgIChhbmdsZXMpID0+IHtcbiAgICAgICAgICByZXN1bHRzLm9wZW5haSA9IGFuZ2xlcztcbiAgICAgICAgfVxuICAgICAgKVxuICAgICk7XG4gIH1cblxuICBhd2FpdCBQcm9taXNlLmFsbCh0YXNrcyk7XG5cbiAgaWYgKCFyZXN1bHRzLmltYWdlbiAmJiAhcmVzdWx0cy5vcGVuYWkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0ltYWdlIGdlbmVyYXRpb24gZmFpbGVkOiBubyBlbmdpbmUgcHJvZHVjZWQgcmVzdWx0cy4nKTtcbiAgfVxuXG4gIHJldHVybiByZXN1bHRzO1xufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJrVEFpSXNCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Card;
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = CardHeader;
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c5 = CardTitle;
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 51,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c7 = CardDescription;
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 63,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c9 = CardContent;
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c10 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 71,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c11 = CardFooter;
CardFooter.displayName = "CardFooter";
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "Card$React.forwardRef");
__turbopack_context__.k.register(_c1, "Card");
__turbopack_context__.k.register(_c2, "CardHeader$React.forwardRef");
__turbopack_context__.k.register(_c3, "CardHeader");
__turbopack_context__.k.register(_c4, "CardTitle$React.forwardRef");
__turbopack_context__.k.register(_c5, "CardTitle");
__turbopack_context__.k.register(_c6, "CardDescription$React.forwardRef");
__turbopack_context__.k.register(_c7, "CardDescription");
__turbopack_context__.k.register(_c8, "CardContent$React.forwardRef");
__turbopack_context__.k.register(_c9, "CardContent");
__turbopack_context__.k.register(_c10, "CardFooter$React.forwardRef");
__turbopack_context__.k.register(_c11, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/select.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Select",
    ()=>Select,
    "SelectContent",
    ()=>SelectContent,
    "SelectGroup",
    ()=>SelectGroup,
    "SelectItem",
    ()=>SelectItem,
    "SelectLabel",
    ()=>SelectLabel,
    "SelectScrollDownButton",
    ()=>SelectScrollDownButton,
    "SelectScrollUpButton",
    ()=>SelectScrollUpButton,
    "SelectSeparator",
    ()=>SelectSeparator,
    "SelectTrigger",
    ()=>SelectTrigger,
    "SelectValue",
    ()=>SelectValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-select/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const Select = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"];
const SelectGroup = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Group"];
const SelectValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Value"];
const SelectTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icon"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                    className: "h-4 w-4 opacity-50"
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 29,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 28,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 19,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = SelectTrigger;
SelectTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"].displayName;
const SelectScrollUpButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollUpButton"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 47,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 39,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c2 = SelectScrollUpButton;
SelectScrollUpButton.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollUpButton"].displayName;
const SelectScrollDownButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"]((param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollDownButton"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 64,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 56,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = SelectScrollDownButton;
SelectScrollDownButton.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollDownButton"].displayName;
const SelectContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = (param, ref)=>{
    let { className, children, position = "popper", ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectScrollUpButton, {}, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 86,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"], {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 87,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SelectScrollDownButton, {}, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 96,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ui/select.tsx",
            lineNumber: 75,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 74,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c5 = SelectContent;
SelectContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"].displayName;
const SelectLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 106,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c7 = SelectLabel;
SelectLabel.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"].displayName;
const SelectItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = (param, ref)=>{
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Item"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ItemIndicator"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                        className: "h-4 w-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ui/select.tsx",
                        lineNumber: 128,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/select.tsx",
                    lineNumber: 127,
                    columnNumber: 7
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 126,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ItemText"], {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/select.tsx",
                lineNumber: 132,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 118,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c9 = SelectItem;
SelectItem.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Item"].displayName;
const SelectSeparator = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c10 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/select.tsx",
        lineNumber: 141,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c11 = SelectSeparator;
SelectSeparator.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$select$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "SelectTrigger$React.forwardRef");
__turbopack_context__.k.register(_c1, "SelectTrigger");
__turbopack_context__.k.register(_c2, "SelectScrollUpButton");
__turbopack_context__.k.register(_c3, "SelectScrollDownButton");
__turbopack_context__.k.register(_c4, "SelectContent$React.forwardRef");
__turbopack_context__.k.register(_c5, "SelectContent");
__turbopack_context__.k.register(_c6, "SelectLabel$React.forwardRef");
__turbopack_context__.k.register(_c7, "SelectLabel");
__turbopack_context__.k.register(_c8, "SelectItem$React.forwardRef");
__turbopack_context__.k.register(_c9, "SelectItem");
__turbopack_context__.k.register(_c10, "SelectSeparator$React.forwardRef");
__turbopack_context__.k.register(_c11, "SelectSeparator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/label.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Label",
    ()=>Label
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const labelVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(labelVariants(), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/label.tsx",
        lineNumber: 18,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Label;
Label.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Label$React.forwardRef");
__turbopack_context__.k.register(_c1, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
            outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-10 px-4 py-2",
            sm: "h-9 rounded-md px-3",
            lg: "h-11 rounded-md px-8",
            icon: "h-10 w-10"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, variant, size, asChild = false, ...props } = param;
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/button.tsx",
        lineNumber: 46,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Button;
Button.displayName = "Button";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Button$React.forwardRef");
__turbopack_context__.k.register(_c1, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/checkbox.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Checkbox",
    ()=>Checkbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-checkbox/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const Checkbox = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("peer h-4 w-4 shrink-0 rounded-sm border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Indicator"], {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center justify-center text-current"),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                className: "h-4 w-4"
            }, void 0, false, {
                fileName: "[project]/src/components/ui/checkbox.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/ui/checkbox.tsx",
            lineNumber: 21,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/checkbox.tsx",
        lineNumber: 13,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Checkbox;
Checkbox.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$checkbox$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "Checkbox$React.forwardRef");
__turbopack_context__.k.register(_c1, "Checkbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/GeneratorForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GeneratorForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/checkbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wand-sparkles.js [app-client] (ecmascript) <export default as Wand2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function GeneratorForm(param) {
    let { formData, setFormData, onGenerate, isGenerating } = param;
    const isMale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMaleGender"])(formData.gender);
    const bodyTypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBodyTypes"])(formData.gender);
    const hairStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHairStyles"])(formData.gender);
    const archetypes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getArchetypes"])(formData.gender);
    const handleSelectChange = (field)=>(value)=>{
            setFormData((prev)=>({
                    ...prev,
                    [field]: value
                }));
        };
    const handleGenderChange = (value)=>{
        const genderDefaults = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGenderSpecificDefaults"])(value);
        setFormData((prev)=>{
            const next = {
                ...prev,
                gender: value,
                ...genderDefaults
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMaleGender"])(value)) {
                delete next.facialHair;
            }
            return next;
        });
    };
    const handleEngineChange = (engine, checked)=>{
        setFormData((prev)=>{
            const nextEngines = {
                ...prev.engines,
                [engine]: checked
            };
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasAtLeastOneEngine"])(nextEngines)) {
                return prev;
            }
            return {
                ...prev,
                engines: nextEngines
            };
        });
    };
    const canGenerate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasAtLeastOneEngine"])(formData.engines);
    const onlyImagen = formData.engines.imagen && !formData.engines.openai;
    const onlyOpenai = formData.engines.openai && !formData.engines.imagen;
    var _formData_facialHair;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                        className: "flex items-center text-2xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__["Wand2"], {
                                className: "mr-3 text-primary"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 98,
                                columnNumber: 11
                            }, this),
                            "Kotoor Model AI"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                        children: "Design and generate your next virtual avatar."
                    }, void 0, false, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 101,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/GeneratorForm.tsx",
                lineNumber: 96,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "gender",
                                children: "Gender"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 107,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.gender,
                                onValueChange: handleGenderChange,
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "gender",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select gender"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 114,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 113,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GENDERS"].map((gender)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: gender,
                                                children: gender
                                            }, gender, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 118,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 116,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "age-group",
                                children: "Age Group"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 127,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.ageGroup,
                                onValueChange: handleSelectChange("ageGroup"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "age-group",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select age group"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 134,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 133,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AGE_GROUPS"].map((age)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: age,
                                                children: age
                                            }, age, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 138,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 136,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 128,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 126,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "region-ethnicity",
                                children: "Region/Ethnicity"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 147,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.regionEthnicity,
                                onValueChange: handleSelectChange("regionEthnicity"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "region-ethnicity",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select region/ethnicity"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 154,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 153,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REGIONS"].map((region)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: region.value,
                                                children: region.label
                                            }, region.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 158,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 156,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 148,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 146,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "skin-tone",
                                children: "Skin Tone (Fitzpatrick Scale)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 167,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.skinTone,
                                onValueChange: handleSelectChange("skinTone"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "skin-tone",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select skin tone"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 174,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 173,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["skinToneOptions"].map((tone)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: tone.value,
                                                children: tone.label
                                            }, tone.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 178,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 176,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 168,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "body-type",
                                children: "Body Type"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 187,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.bodyType,
                                onValueChange: handleSelectChange("bodyType"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "body-type",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select body type"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 194,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 193,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: bodyTypes.map((type)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: type,
                                                children: type
                                            }, type, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 198,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 196,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 188,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 186,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "hair-style",
                                children: "Hair Style"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 207,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.hairStyle,
                                onValueChange: handleSelectChange("hairStyle"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "hair-style",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select hair style"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 214,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 213,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: hairStyles.map((style)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: style.value,
                                                children: style.label
                                            }, style.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 218,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 216,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 208,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 206,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "hair-color",
                                children: "Hair Color"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 227,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.hairColor,
                                onValueChange: handleSelectChange("hairColor"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "hair-color",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select hair color"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 234,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 233,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hairColorOptions"].map((color)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: color.value,
                                                children: color.label
                                            }, color.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 238,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 236,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 228,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 226,
                        columnNumber: 9
                    }, this),
                    isMale && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "facial-hair",
                                children: "Facial Hair"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 248,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: (_formData_facialHair = formData.facialHair) !== null && _formData_facialHair !== void 0 ? _formData_facialHair : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MALE_FACIAL_HAIR"][0].value,
                                onValueChange: handleSelectChange("facialHair"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "facial-hair",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select facial hair"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 255,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 254,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MALE_FACIAL_HAIR"].map((style)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: style.value,
                                                children: style.label
                                            }, style.value, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 259,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 257,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 249,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 247,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3 rounded-lg border p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                className: "text-base font-semibold",
                                children: "Generation Engine"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 269,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-muted-foreground",
                                children: "Select at least one engine. Both run in parallel for side-by-side comparison."
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 270,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                                        id: "engine-imagen",
                                        checked: formData.engines.imagen,
                                        disabled: isGenerating || onlyImagen,
                                        onCheckedChange: (checked)=>handleEngineChange("imagen", checked === true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 275,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "engine-imagen",
                                        className: "font-normal cursor-pointer",
                                        children: "Google Imagen 4 Fast"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 283,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 274,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center space-x-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$checkbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"], {
                                        id: "engine-openai",
                                        checked: formData.engines.openai,
                                        disabled: isGenerating || onlyOpenai,
                                        onCheckedChange: (checked)=>handleEngineChange("openai", checked === true)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 291,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                        htmlFor: "engine-openai",
                                        className: "font-normal cursor-pointer",
                                        children: "OpenAI GPT Image 2"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 299,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 290,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 268,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "archetype",
                                children: "Marketing Archetype (Vibe)"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 309,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"], {
                                value: formData.marketingArchetype,
                                onValueChange: handleSelectChange("marketingArchetype"),
                                disabled: isGenerating,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectTrigger"], {
                                        id: "archetype",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectValue"], {
                                            placeholder: "Select archetype"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/GeneratorForm.tsx",
                                            lineNumber: 316,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 315,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectContent"], {
                                        children: archetypes.map((archetype)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SelectItem"], {
                                                value: archetype,
                                                children: archetype
                                            }, archetype, false, {
                                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                                lineNumber: 320,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/GeneratorForm.tsx",
                                        lineNumber: 318,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 310,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 308,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onGenerate,
                        disabled: isGenerating || !canGenerate,
                        className: "w-full bg-accent text-accent-foreground hover:bg-accent/90",
                        size: "lg",
                        children: [
                            isGenerating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                className: "mr-2 h-4 w-4 animate-spin"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 335,
                                columnNumber: 13
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wand$2d$sparkles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wand2$3e$__["Wand2"], {
                                className: "mr-2 h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/GeneratorForm.tsx",
                                lineNumber: 337,
                                columnNumber: 13
                            }, this),
                            "Generate 3-Angle Turnaround"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GeneratorForm.tsx",
                        lineNumber: 328,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/GeneratorForm.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/GeneratorForm.tsx",
        lineNumber: 95,
        columnNumber: 5
    }, this);
}
_c = GeneratorForm;
var _c;
__turbopack_context__.k.register(_c, "GeneratorForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ui/tabs.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tabs",
    ()=>Tabs,
    "TabsContent",
    ()=>TabsContent,
    "TabsList",
    ()=>TabsList,
    "TabsTrigger",
    ()=>TabsTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-tabs/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
const Tabs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"];
const TabsList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 14,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = TabsList;
TabsList.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"].displayName;
const TabsTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 29,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = TabsTrigger;
TabsTrigger.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"].displayName;
const TabsContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = (param, ref)=>{
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/tabs.tsx",
        lineNumber: 44,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
});
_c5 = TabsContent;
TabsContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "TabsList$React.forwardRef");
__turbopack_context__.k.register(_c1, "TabsList");
__turbopack_context__.k.register(_c2, "TabsTrigger$React.forwardRef");
__turbopack_context__.k.register(_c3, "TabsTrigger");
__turbopack_context__.k.register(_c4, "TabsContent$React.forwardRef");
__turbopack_context__.k.register(_c5, "TabsContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ActiveModelDisplay.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActiveModelDisplay
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/tabs.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
"use client";
;
;
;
;
;
;
;
function AngleGrid(param) {
    let { images, prompts, seed, enginePrefix } = param;
    const handleDownload = (url, filename)=>{
        const link = document.createElement("a");
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const prefix = enginePrefix ? "".concat(enginePrefix, "_") : "";
    const angles = [
        {
            title: "Straight (3/4 Body)",
            url: images.straight,
            prompt: prompts.straightPrompt,
            alt: "Straight 3/4 body portrait of the model",
            hint: "person portrait",
            file: "straight_".concat(prefix).concat(seed, ".png")
        },
        {
            title: "Left Profile (3/4 Body)",
            url: images.left,
            prompt: prompts.leftPrompt,
            alt: "Left profile 3/4 body portrait of the model",
            hint: "person profile",
            file: "left_".concat(prefix).concat(seed, ".png")
        },
        {
            title: "Right Profile (3/4 Body)",
            url: images.right,
            prompt: prompts.rightPrompt,
            alt: "Right profile 3/4 body portrait of the model",
            hint: "person profile",
            file: "right_".concat(prefix).concat(seed, ".png")
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-1 md:grid-cols-3 gap-6 items-start",
        children: angles.map((angle)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                            className: "text-base",
                            children: angle.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 82,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 81,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                        className: "flex-grow",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-full aspect-[3/4] max-h-[75vh] mx-auto overflow-hidden rounded-md",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: angle.url,
                                alt: angle.alt,
                                fill: true,
                                className: "object-cover",
                                sizes: "(max-width: 768px) 100vw, 33vw",
                                "data-ai-hint": angle.hint
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 86,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 85,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 84,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardFooter"], {
                        className: "flex-col items-start gap-2 pt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm font-medium",
                                        children: "Prompt"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 98,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: "outline",
                                        size: "sm",
                                        onClick: ()=>handleDownload(angle.url, angle.file),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                className: "mr-2 h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                                lineNumber: 104,
                                                columnNumber: 17
                                            }, this),
                                            "Download"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 99,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-muted-foreground",
                                children: angle.prompt
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, this)
                ]
            }, angle.title, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 80,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 78,
        columnNumber: 5
    }, this);
}
_c = AngleGrid;
function EngineResults(param) {
    let { engineKey, activeModel } = param;
    const images = activeModel.imageResults[engineKey];
    if (!images) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AngleGrid, {
        images: images,
        prompts: activeModel.prompts,
        seed: activeModel.seed,
        enginePrefix: engineKey
    }, void 0, false, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 127,
        columnNumber: 5
    }, this);
}
_c1 = EngineResults;
function ActiveModelDisplay(param) {
    let { activeModel, isGenerating, onBulkDownload } = param;
    const engineKeys = activeModel ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActiveEngineKeys"])(activeModel.imageResults) : [];
    const dualEngine = activeModel ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasMultipleEngines"])(activeModel.imageResults) : false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-bold tracking-tight",
                                children: "Active Model"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 148,
                                columnNumber: 11
                            }, this),
                            activeModel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-muted-foreground",
                                children: [
                                    "Generation Seed: ",
                                    activeModel.seed,
                                    engineKeys.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-2",
                                        children: [
                                            "· Engines:",
                                            " ",
                                            engineKeys.map((k)=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][k]).join(", ")
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                        lineNumber: 153,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 150,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 147,
                        columnNumber: 9
                    }, this),
                    activeModel && !isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: onBulkDownload,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                className: "mr-2"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 163,
                                columnNumber: 13
                            }, this),
                            "Bulk Download"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 162,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 146,
                columnNumber: 7
            }, this),
            isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-10 flex flex-col items-center justify-center border-2 border-dashed rounded-lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                        className: "w-16 h-16 animate-spin text-primary mb-4"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xl font-semibold text-primary",
                        children: "Synthesizing Realistic Angles..."
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 172,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-muted-foreground",
                        children: "Please wait a moment."
                    }, void 0, false, {
                        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                        lineNumber: 175,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 170,
                columnNumber: 9
            }, this),
            !isGenerating && !activeModel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-10 border-2 border-dashed rounded-lg",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg text-muted-foreground",
                    children: "Generate a model to see the results here."
                }, void 0, false, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 181,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 180,
                columnNumber: 9
            }, this),
            activeModel && !isGenerating && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "animate-in fade-in duration-500",
                children: dualEngine ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tabs"], {
                    defaultValue: engineKeys[0],
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsList"], {
                            className: "mb-6",
                            children: engineKeys.map((key)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                    value: key,
                                    children: [
                                        "Engine: ",
                                        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][key]
                                    ]
                                }, key, true, {
                                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                    lineNumber: 193,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                            lineNumber: 191,
                            columnNumber: 15
                        }, this),
                        engineKeys.map((key)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                                value: key,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EngineResults, {
                                    engineKey: key,
                                    activeModel: activeModel
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                    lineNumber: 200,
                                    columnNumber: 19
                                }, this)
                            }, key, false, {
                                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                                lineNumber: 199,
                                columnNumber: 17
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 190,
                    columnNumber: 13
                }, this) : engineKeys[0] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EngineResults, {
                    engineKey: engineKeys[0],
                    activeModel: activeModel
                }, void 0, false, {
                    fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                    lineNumber: 206,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ActiveModelDisplay.tsx",
                lineNumber: 188,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ActiveModelDisplay.tsx",
        lineNumber: 145,
        columnNumber: 5
    }, this);
}
_c2 = ActiveModelDisplay;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "AngleGrid");
__turbopack_context__.k.register(_c1, "EngineResults");
__turbopack_context__.k.register(_c2, "ActiveModelDisplay");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>KotoorModelAI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jszip$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jszip/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$eec5c0__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:eec5c0 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$055f96__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:055f96 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GeneratorForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/GeneratorForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ActiveModelDisplay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ActiveModelDisplay.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function KotoorModelAI() {
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_FORM_DATA_FEMALE"]);
    const [activeModel, setActiveModel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isGenerating, setIsGenerating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const handleGenerate = async ()=>{
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasAtLeastOneEngine"])(formData.engines)) {
            toast({
                variant: "destructive",
                title: "No engine selected",
                description: "Select at least one generation engine to continue."
            });
            return;
        }
        setIsGenerating(true);
        setActiveModel(null);
        try {
            const prompts = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$eec5c0__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelTurnaroundPrompts"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toPromptInput"])(formData));
            const imageResults = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$055f96__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateModelImages"])({
                prompts,
                engines: formData.engines
            });
            const seed = Math.floor(1000000000 + Math.random() * 9000000000).toString();
            const newModel = {
                seed,
                imageResults,
                prompts,
                formData
            };
            setActiveModel(newModel);
        } catch (error) {
            console.error("Failed to generate model", error);
            toast({
                variant: "destructive",
                title: "Generation Failed",
                description: error instanceof Error ? error.message : "There was an error generating the model. Please try again."
            });
        } finally{
            setIsGenerating(false);
        }
    };
    const dataURItoBlob = (dataURI)=>{
        const byteString = atob(dataURI.split(",")[1]);
        const mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for(let i = 0; i < byteString.length; i++){
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([
            ab
        ], {
            type: mimeString
        });
    };
    const handleBulkDownload = async ()=>{
        if (!activeModel) return;
        toast({
            title: "Preparing Download...",
            description: "Your model assets are being zipped."
        });
        try {
            const zip = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jszip$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
            const promptData = "Straight Prompt:\n".concat(activeModel.prompts.straightPrompt, "\n\nLeft Prompt:\n").concat(activeModel.prompts.leftPrompt, "\n\nRight Prompt:\n").concat(activeModel.prompts.rightPrompt);
            zip.file("prompts.txt", promptData);
            const engineKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getActiveEngineKeys"])(activeModel.imageResults);
            for (const engineKey of engineKeys){
                const images = activeModel.imageResults[engineKey];
                if (!images) continue;
                const folder = engineKeys.length > 1 ? "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENGINE_LABELS"][engineKey].replace(/\s+/g, "_"), "/") : "";
                zip.file("".concat(folder, "straight_").concat(activeModel.seed, ".png"), dataURItoBlob(images.straight));
                zip.file("".concat(folder, "left_").concat(activeModel.seed, ".png"), dataURItoBlob(images.left));
                zip.file("".concat(folder, "right_").concat(activeModel.seed, ".png"), dataURItoBlob(images.right));
            }
            const content = await zip.generateAsync({
                type: "blob"
            });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(content);
            link.download = "model_".concat(activeModel.seed, ".zip");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        } catch (error) {
            console.error("Failed to create zip for download", error);
            toast({
                variant: "destructive",
                title: "Download Failed",
                description: "Could not prepare your files for download. Please try again."
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "container mx-auto p-4 md:p-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col lg:flex-row lg:space-x-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "lg:w-1/3 xl:w-1/4 mb-8 lg:mb-0",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GeneratorForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        formData: formData,
                        setFormData: setFormData,
                        onGenerate: handleGenerate,
                        isGenerating: isGenerating
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 142,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 141,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "lg:w-2/3 xl:w-3/4 flex flex-col space-y-8",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ActiveModelDisplay$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        activeModel: activeModel,
                        isGenerating: isGenerating,
                        onBulkDownload: handleBulkDownload
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 151,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 150,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 140,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 139,
        columnNumber: 5
    }, this);
}
_s(KotoorModelAI, "3iGjmtYLfsvWphbmPHtlDYJ7dUg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = KotoorModelAI;
var _c;
__turbopack_context__.k.register(_c, "KotoorModelAI");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_96ecb899._.js.map